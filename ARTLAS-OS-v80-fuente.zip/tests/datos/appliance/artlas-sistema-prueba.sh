#!/bin/sh
# Ayudante de sistema FALSO para las pruebas del modo appliance (no toca el equipo).
LOG="${ARTLAS_PRUEBA_LOG:-/tmp/artlas-sistema-prueba.log}"; EST="$LOG.flatpak"
echo "$*" >> "$LOG"
case "$1" in
  wifi-listar) printf 'Casa\t80\tWPA2\t*\nVecino\t40\t--\t\n' ;;
  wifi-actual) echo "Casa" ;;
  wifi-conectar) echo "conectado a $2" ;;
  volumen-actual) echo 55 ;;
  volumen|zona) echo ok ;;
  instalar) sleep 1; [ "$2" = flatpak ] && echo "$3" >> "$EST"; echo "instalado $2 $3" ;;
  instalar-deb) sleep 1; echo "instalado $2" ;;
  desinstalar) grep -v "^$3\$" "$EST" > "$EST.t" 2>/dev/null; mv "$EST.t" "$EST"; echo ok ;;
  flatpak-lista) cat "$EST" 2>/dev/null || true ;;
  pantalla-listar) echo '[{"name":"Virtual-1","enabled":true,"scale":1,"modes":[{"width":1024,"height":768,"refresh":60,"current":true,"preferred":false},{"width":1920,"height":1080,"refresh":60,"current":false,"preferred":true},{"width":1366,"height":768,"refresh":60,"current":false,"preferred":false}]}]' ;;
  pantalla-aplicar) echo ok ;;
  apagar|reiniciar) echo ok ;;
  *) echo "subcomando desconocido" >&2; exit 2 ;;
esac
