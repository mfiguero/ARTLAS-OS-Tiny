# AR.T.L.A.S. RAG FALSO para las pruebas: responde en RAG_PORT y se cierra solo a los 120 s.
import os, threading, http.server
p = int(os.environ.get("RAG_PORT", "8760"))
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        b = b"<html><body><h1>RAG de prueba</h1></body></html>"; self.send_response(200); self.send_header("Content-Type", "text/html"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
srv = http.server.ThreadingHTTPServer(("127.0.0.1", p), H); threading.Timer(120, srv.shutdown).start(); srv.serve_forever()
