-- AR.T.L.A.S. · Registro de errores de producción
-- Ejecutar UNA vez en Supabase → SQL Editor → New query → Run.
-- Guarda solo: versión, tipo, mensaje del error, origen, sección y navegador.
-- Nunca conversaciones, documentos ni claves.

create table if not exists public.atlas_errors (
  id          bigserial primary key,
  created_at  timestamptz not null default now(),
  ver   text,
  kind  text,
  msg   text,
  stack text,
  src   text,
  path  text,
  ua    text,
  sess  text
);

alter table public.atlas_errors enable row level security;

-- ¿Es el administrador? (el mail queda solo en el servidor, no en el código público)
create or replace function public.atlas_is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select coalesce(lower(auth.jwt() ->> 'email'), '') = 'mfiguero@gmail.com';
$$;
grant execute on function public.atlas_is_admin() to anon, authenticated;

-- Cualquier visitante puede REGISTRAR un error (solo insertar, con tamaños acotados)
drop policy if exists "atlas_errors_insert" on public.atlas_errors;
create policy "atlas_errors_insert" on public.atlas_errors
  for insert to anon, authenticated
  with check (
    char_length(coalesce(msg,''))   <= 400  and
    char_length(coalesce(stack,'')) <= 1500 and
    char_length(coalesce(ua,''))    <= 200  and
    char_length(coalesce(src,''))   <= 200
  );

-- Solo el administrador puede LEER y BORRAR
drop policy if exists "atlas_errors_select_admin" on public.atlas_errors;
create policy "atlas_errors_select_admin" on public.atlas_errors
  for select to authenticated using (public.atlas_is_admin());

drop policy if exists "atlas_errors_delete_admin" on public.atlas_errors;
create policy "atlas_errors_delete_admin" on public.atlas_errors
  for delete to authenticated using (public.atlas_is_admin());

create index if not exists atlas_errors_created_idx on public.atlas_errors (created_at desc);
