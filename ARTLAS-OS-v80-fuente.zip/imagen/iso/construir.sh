#!/bin/bash
# AR.T.L.A.S. OS · construye la ISO amd64. En Debian 13 corre live-build directo; en otro sistema usa Docker.
# Uso: sudo imagen/iso/construir.sh       (resultado en imagen/salida/)
set -euo pipefail
R=$(cd "$(dirname "$0")/../.." && pwd); SAL=${ARTLAS_SALIDA:-$R/imagen/salida}; mkdir -p "$SAL"
[ -f "$R/dist/nucleo/artlas-nucleo.mjs" ] || (cd "$R" && node build.mjs)
VER=$(node -p "require('$R/artlas.config.json').ver" 2>/dev/null || echo v7)
W=$(mktemp -d /tmp/artlas-iso.XXXX); cp -a "$R/imagen/iso/." "$W/"
INC="$W/config/includes.chroot"; mkdir -p "$INC/opt/artlas" "$INC/etc"
cp -a "$R/dist/web-only" "$INC/opt/artlas/app"; cp -a "$R/dist/nucleo" "$INC/opt/artlas/nucleo"; cp -a "$R/dist/rag" "$INC/opt/artlas/rag"
cp -a "$R/imagen/comun/raiz/." "$INC/"; cp "$R/imagen/comun/instalar-artlas.sh" "$INC/opt/artlas/"
# v8.0: perfil «tiny» (ARTLAS_PERFIL=tiny) → AR.T.L.A.S. OS Tiny, ISO ~700 MB
PERFIL=${ARTLAS_PERFIL:-completa}
if [ "$PERFIL" = tiny ]; then
  grep -hv '^\s*#' "$R/imagen/comun/paquetes-tiny.txt" "$W/config/package-lists/amd64-tiny.list" | grep -v '^\s*$' > "$W/config/package-lists/artlas.list.chroot"
  echo tiny > "$INC/etc/artlas-edicion"; NOMBRE="ARTLAS-OS-Tiny-$VER-amd64.iso"
  sed -i 's/--archive-areas "main contrib non-free non-free-firmware"/--archive-areas "main"/; s/--iso-application "AR.T.L.A.S. OS"/--iso-application "AR.T.L.A.S. OS Tiny"/; s/--iso-volume "ARTLAS-OS"/--iso-volume "ARTLAS-OS-TINY"/' "$W/auto/config"
  sed -i 's/^d-i apt-setup\/non-free-firmware boolean true/d-i apt-setup\/non-free-firmware boolean false/' "$W/config/includes.installer/preseed.cfg"
else
  grep -hv '^\s*#' "$R/imagen/comun/paquetes.txt" "$W/config/package-lists/amd64.list" | grep -v '^\s*$' > "$W/config/package-lists/artlas.list.chroot"
  echo completa > "$INC/etc/artlas-edicion"; NOMBRE="ARTLAS-OS-$VER-amd64.iso"
fi
rm -f "$W/config/package-lists/amd64.list" "$W/config/package-lists/amd64-tiny.list"
EN_DEBIAN=0; grep -q 'VERSION_CODENAME=trixie' /etc/os-release 2>/dev/null && command -v lb >/dev/null && EN_DEBIAN=1
if [ "$EN_DEBIAN" = 1 ]; then (cd "$W" && lb clean && ./auto/config && ./auto/build)
else docker run --rm --privileged -v "$W:/w" -w /w debian:trixie bash -c "apt-get update -q && apt-get install -y -q live-build && lb clean && ./auto/config && ./auto/build"; fi
ISO=$(ls "$W"/*.iso 2>/dev/null | head -1 || true)
if [ -z "$ISO" ]; then echo "::error::live-build no generó la ISO. Últimas líneas del registro:"; tail -n 60 "$W/build.log" 2>/dev/null || true; exit 1; fi
echo "ISO generada: $(du -h "$ISO" | cut -f1)"; cp "$ISO" "$SAL/$NOMBRE"
(cd "$SAL" && sha256sum "$NOMBRE" > "$NOMBRE.sha256")
echo "Listo: $SAL/$NOMBRE ($(du -h "$SAL/$NOMBRE" | cut -f1))"
