#!/bin/bash
# AR.T.L.A.S. OS · construye la imagen para Raspberry Pi (arm64) con pi-gen (oficial de Raspberry Pi).
# En una PC x86 usa emulación (qemu-user-static); en una máquina arm64 es más rápido.
# Uso: imagen/rpi/construir.sh       (resultado en imagen/salida/)
set -euo pipefail
R=$(cd "$(dirname "$0")/../.." && pwd); SAL=${ARTLAS_SALIDA:-$R/imagen/salida}; mkdir -p "$SAL"
[ -f "$R/dist/nucleo/artlas-nucleo.mjs" ] || (cd "$R" && node build.mjs)
VER=$(node -p "require('$R/artlas.config.json').ver" 2>/dev/null || echo v7)
PG=${PIGEN_DIR:-/tmp/pi-gen}; RAMA=${PIGEN_RAMA:-arm64}
[ -d "$PG/.git" ] || git clone --depth 1 --branch "$RAMA" https://github.com/RPi-Distro/pi-gen.git "$PG"
rm -rf "$PG/stage-artlas"; cp -a "$R/imagen/rpi/stage-artlas" "$PG/"
F="$PG/stage-artlas/01-artlas/files"; mkdir -p "$F/opt/artlas"
cp -a "$R/dist/web-only" "$F/opt/artlas/app"; cp -a "$R/dist/nucleo" "$F/opt/artlas/nucleo"; cp -a "$R/dist/rag" "$F/opt/artlas/rag"
cp "$R/imagen/comun/instalar-artlas.sh" "$F/opt/artlas/"; cp -a "$R/imagen/comun/raiz" "$F/raiz"; mkdir -p "$F/raiz/etc"; echo completa > "$F/raiz/etc/artlas-edicion"
grep -v '^\s*#' "$R/imagen/comun/paquetes.txt" | grep -v '^\s*$' > "$PG/stage-artlas/00-paquetes/00-packages"
cp "$R/imagen/rpi/config" "$PG/config"; echo "IMG_DATE=$(date +%Y-%m-%d)" >> "$PG/config"
(cd "$PG" && ./build-docker.sh)
IMG=$(ls -t "$PG"/deploy/*.img.xz | head -1); cp "$IMG" "$SAL/ARTLAS-OS-$VER-raspberrypi-arm64.img.xz"
(cd "$SAL" && sha256sum "ARTLAS-OS-$VER-raspberrypi-arm64.img.xz" > "ARTLAS-OS-$VER-raspberrypi-arm64.img.xz.sha256")
echo "Listo: $SAL/ARTLAS-OS-$VER-raspberrypi-arm64.img.xz"
