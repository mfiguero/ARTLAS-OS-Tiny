#!/bin/bash -e
bash /opt/artlas/instalar-artlas.sh
# Raspberry Pi OS: sin asistente de primer arranque de escritorio; el kiosco arranca en la consola 1
systemctl disable userconfig.service 2>/dev/null || true
systemctl set-default multi-user.target
