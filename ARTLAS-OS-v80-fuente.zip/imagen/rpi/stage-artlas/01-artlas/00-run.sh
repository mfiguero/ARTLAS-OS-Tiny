#!/bin/bash -e
# copia AR.T.L.A.S. OS (preparado por imagen/rpi/construir.sh en files/) dentro de la imagen
install -d "${ROOTFS_DIR}/opt/artlas"
cp -a files/opt/artlas/. "${ROOTFS_DIR}/opt/artlas/"
cp -a files/raiz/. "${ROOTFS_DIR}/"
