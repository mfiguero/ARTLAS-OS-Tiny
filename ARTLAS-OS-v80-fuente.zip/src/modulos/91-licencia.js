/* ==================================================================
   v6.8.2 · Política de Privacidad, Términos de Uso y Licencia
   - Casilla NO premarcada en «Cuenta AR.T.L.A.S.»: obligatoria para crear la cuenta.
   - Obligatoria también (una vez por versión del documento) para descargar Escritorio
     o RAG, instalar la app e ingresar a la app instalada.
   - Registro de la aceptación: en la cuenta (metadatos de Supabase), en la tabla
     atlas_consents (fecha/hora del servidor e IP, ver supabase/consentimientos.sql)
     y en el navegador.
   - El PDF (licencia-artlas.pdf) se publica en el sitio y va dentro de los paquetes
     de Escritorio y RAG. El texto completo se lee dentro de la app (ARTLAS_LIC, recursos).
   ================================================================== */
const V69={ver:"__ARTLAS_LIC_VER__",pdf:"licencia-artlas.pdf",cont:null,synced:{}};

function v69Doc(){ return v60L("Política de Privacidad, los Términos de Uso y la Licencia AR.T.L.A.S. ","Privacy Policy, Terms of Use and AR.T.L.A.S. License ")+V69.ver; }
function v69LabelHtml(){ return v60L("He leído y acepto la ","I have read and accept the ")+`<a onclick="event.preventDefault();event.stopPropagation();v69Ver()">${v69Doc()}</a>`; }
function v69Key(email){ return String(email||"").trim().toLowerCase(); }
function v69Local(){ try{ return JSON.parse(localStorage.getItem("atlas_lic")||"{}")||{}; }catch(e){ return {}; } }
function v69LocalSet(email,rec){ try{ const L=v69Local(); L[v69Key(email)]=rec; localStorage.setItem("atlas_lic",JSON.stringify(L)); }catch(e){} }
function v69RecFor(u){
  if(!u) return null;
  try{ const m=u.user_metadata&&u.user_metadata.artlas_lic; if(m&&m.ver===V69.ver) return m; }catch(e){}
  const r=v69Local()[v69Key(u.email)]; return r&&r.ver===V69.ver?r:null;
}
function v69Rec(){ return v61Logged()?v69RecFor(user):null; }
function v69Accepted(){ return !!v69Rec(); }
function v69NewRec(origen){ return {ver:V69.ver,t:new Date().toISOString(),app:V60.ver,origen:origen||""}; }
/* registro en la base: fecha/hora e IP los pone el servidor (si la tabla existe) */
function v69Db(rec){
  try{
    if(!supa||!user||!supa.from) return;
    supa.from("atlas_consents").upsert({user_id:user.id,email:user.email,doc_ver:rec.ver,app_ver:rec.app||V60.ver,origen:rec.origen||"",ua:navigator.userAgent.slice(0,200)},{onConflict:"user_id,doc_ver",ignoreDuplicates:true}).then(()=>{},()=>{});
  }catch(e){}
}
async function v69Save(origen){
  if(!v61Logged()) return null;
  const rec=v69NewRec(origen);
  v69LocalSet(user.email,rec);
  try{ if(supa&&supa.auth&&supa.auth.updateUser){ const r=await supa.auth.updateUser({data:{artlas_lic:rec}}); if(r&&r.data&&r.data.user) user=r.data.user; } }catch(e){}
  v69Db(rec); V69.synced[user.id]=1;
  return rec;
}
/* al iniciar sesión: sube a la base la aceptación hecha al registrarse (o en este navegador) */
function v69Sync(){
  if(!v61Logged()||V69.synced[user.id]) return;
  const r=v69Rec(); if(!r) return;
  V69.synced[user.id]=1;
  const meta=user.user_metadata&&user.user_metadata.artlas_lic;
  if(!(meta&&meta.ver===V69.ver)){ try{ if(supa&&supa.auth&&supa.auth.updateUser) supa.auth.updateUser({data:{artlas_lic:r}}).then(()=>{},()=>{}); }catch(e){} }
  v69Db(r);
}

/* ---------------- casilla en «Cuenta AR.T.L.A.S.» ---------------- */
function v69Decorate(){
  const uf=$("user-forms"); if(!uf) return;
  let row=$("v69-row");
  if(!row){
    const btn=uf.querySelector("button.btn.dark");
    row=document.createElement("label"); row.id="v69-row"; row.className="v69-ckrow";
    if(btn) uf.insertBefore(row,btn); else uf.appendChild(row);
    row.innerHTML=`<input type="checkbox" id="v69-ck"><span id="v69-lab"></span>`;
    row.querySelector("input").addEventListener("change",()=>row.classList.remove("v69-err"));
  }
  const lab=$("v69-lab"); if(lab) lab.innerHTML=v69LabelHtml();
}
function v69Shake(){ const r=$("v69-row"); if(!r) return; r.classList.remove("v69-err"); void r.offsetWidth; r.classList.add("v69-err"); }
v60Wrap("openUser",()=>v69Decorate());

const V69_doSignup=doSignup;
doSignup=async function(){
  v69Decorate();
  const ck=$("v69-ck");
  if(!ck||!ck.checked){
    umsg(v60L("Para crear la cuenta tenés que leer y aceptar la ","To create the account you must read and accept the ")+v69Doc()+".");
    v69Shake(); return;
  }
  const rec=v69NewRec("registro"), email=(($("u-email")||{}).value||"").trim();
  let raw=null; const a=supa&&supa.auth;
  try{ if(a&&a.signUp){ raw=a.signUp; a.signUp=function(o){ o=Object.assign({},o); o.options=Object.assign({},o.options); o.options.data=Object.assign({},o.options.data,{artlas_lic:rec}); return raw.call(a,o); }; } }catch(e){}
  try{ return await V69_doSignup.apply(this,arguments); }
  finally{ if(raw) a.signUp=raw; if(email) v69LocalSet(email,rec); }
};
/* v6.8.3: «Ingresar» también exige la casilla si la cuenta todavía no aceptó la versión vigente.
   La verificación se hace apenas Supabase valida usuario y clave: si falta la aceptación,
   se cierra esa sesión en el acto y no se entra a la plataforma. */
const V69_doLogin=doLogin;
doLogin=async function(){
  v69Decorate();
  const ck=$("v69-ck"), marcada=!!(ck&&ck.checked);
  const a=supa&&supa.auth; let raw=null; V69.pendingSave=false;
  try{
    if(a&&a.signInWithPassword){
      raw=a.signInWithPassword;
      a.signInWithPassword=async function(o){
        const r=await raw.call(a,o);
        try{
          const u=r&&r.data&&r.data.user;
          if(u&&!r.error&&!v69RecFor(u)){
            if(!marcada){
              try{ await a.signOut(); }catch(e){}
              v69Shake();
              return {data:{user:null,session:null},error:{message:v60L("Para ingresar tenés que aceptar la ","To sign in you must accept the ")+v69Doc()+v60L(". Tildá la casilla y volvé a tocar «Ingresar» (se pide una sola vez por cada versión del documento).",". Tick the box and press “Sign in” again (asked only once per document version).")}};
            }
            v69LocalSet(u.email,v69NewRec("ingreso")); V69.pendingSave=true;   // ya cuenta como aceptada para el resto del ingreso
          }
        }catch(e){}
        return r;
      };
    }
  }catch(e){}
  let res;
  try{ res=await V69_doLogin.apply(this,arguments); }
  finally{ if(raw) a.signInWithPassword=raw; }
  try{ if(V69.pendingSave&&v61Logged()){ V69.pendingSave=false; await v69Save("ingreso"); } }catch(e){}
  return res;
};
/* sesión que se recupera sola (o ingreso por código) sin aceptación vigente: se pide antes de seguir */
function v69Guard(){
  if(!v61Logged()||v69Accepted()||$("v69-modal")) return;
  try{ if(v61GateVisible()) return; }catch(e){}                  // en la pantalla de ingreso se pide al entrar
  v69Modal("ingreso",()=>{},()=>v69Salir());
}
async function v69Salir(){ try{ V61.gateLoginPending=false; await doLogout(); }catch(e){} try{ v61GateShow(); }catch(e){} }
v60Wrap("updateUserUI",()=>{ try{ v69Sync(); v69Guard(); }catch(e){} });

/* ---------------- lectura y aceptación del documento ---------------- */
/* el documento se lee en español o en inglés (empieza en el idioma de la app) */
function v69DocHtml(){
  const D=(typeof ARTLAS_LIC!=="undefined")?ARTLAS_LIC:null; if(!D) return "";
  const en=V69.lang==="en"&&D.html_en;
  return `<p class="v69-nota">${en?D.nota_en:D.nota}</p>`+(en?D.html_en:D.html);
}
function v69Fecha(){
  const D=(typeof ARTLAS_LIC!=="undefined")?ARTLAS_LIC:null; if(!D) return "";
  return V69.lang==="en"&&D.fecha_en?"effective "+v60Esc(D.fecha_en):"vigente desde el "+v60Esc(D.fecha);
}
function v69Lang(l){
  V69.lang=l==="en"?"en":"es";
  const d=$("v69-doc"); if(d&&typeof ARTLAS_LIC!=="undefined"){ d.innerHTML=v69DocHtml(); d.scrollTop=0; d.setAttribute("lang",V69.lang); }
  const f=$("v69-fecha"); if(f) f.innerHTML=v69Fecha();
  document.querySelectorAll("#v69-modal .v69-tabs button").forEach(b=>b.classList.toggle("on",b.dataset.l===V69.lang));
}
function v69Modal(origen,cont,onCancel){
  v69Close();
  V69.lang=(typeof atlasLang!=="undefined"&&atlasLang==="en")?"en":"es";
  V69.cont=cont||null; V69.onCancel=onCancel||null;
  const L=v60L, D=(typeof ARTLAS_LIC!=="undefined")?ARTLAS_LIC:null;
  const m=document.createElement("div"); m.className="v68-modal"; m.id="v69-modal";
  m.onclick=e=>{ if(e.target===m&&!cont) v69Close(); };
  const quien=v61Logged()?`<div class="v69-meta">${L("Cuenta: ","Account: ")}<b>${v60Esc(user.email||"")}</b></div>`:"";
  m.innerHTML=`<div class="v68-box v69-box" role="dialog" aria-modal="true"><h3><img src="${v61Emblem()}" alt="">${L("Licencia de uso de AR.T.L.A.S.","AR.T.L.A.S. License")}</h3>
    ${D&&D.original?`<div class="v69-meta">${L("Licencia AR.T.L.A.S. ","AR.T.L.A.S. License ")+v60Esc(D.original)+L(" (original)"," (original)")}</div><div class="v69-meta">${L("Versión nueva: ","New version: ")}<b>${L("Licencia AR.T.L.A.S. ","AR.T.L.A.S. License ")+V69.ver}</b> · <span id="v69-fecha">${v69Fecha()}</span></div>`
      :`<div class="v69-meta">${L("Política de Privacidad, Términos de Uso y Licencia AR.T.L.A.S. ","Privacy Policy, Terms of Use and AR.T.L.A.S. License ")+V69.ver}${D?` · <span id="v69-fecha">${v69Fecha()}</span>`:""}</div>`}${quien}
    ${cont?`<div class="v69-res">${L("AR.T.L.A.S. es de <b>uso libre y gratuito</b>, pero no es código abierto: no se puede copiar ni clonar, ni usar parte de su código en otra aplicación, ni cambiar sus nombres o autores. Los usos no autorizados serán denunciados ante las autoridades competentes.","AR.T.L.A.S. is <b>free to use</b>, but it is not open source: it may not be copied or cloned, its code may not be used in another application, and its names or authors may not be changed. Unauthorized uses will be reported to the competent authorities.")}</div>`:""}
    ${D&&D.html_en?`<div class="v69-tabs" role="tablist"><button data-l="es" onclick="v69Lang('es')">Español</button><button data-l="en" onclick="v69Lang('en')">English</button></div>`:""}
    <div class="v69-doc" id="v69-doc">${D?v69DocHtml():`<p>${L("Abrí el PDF para leer el documento completo.","Open the PDF to read the full document.")}</p>`}</div>
    <a class="v69-pdf" href="${V69.pdf}" target="_blank" rel="noopener" download="Licencia-ARTLAS-${V69.ver}.pdf">📄 ${L("Descargar el documento en PDF (español e inglés)","Download the document as PDF (Spanish and English)")}</a>
    ${cont?`<label class="v69-ckrow" style="margin:12px 0 0"><input type="checkbox" id="v69-ck2" onchange="$('v69-ok').disabled=!this.checked"><span>${v69LabelHtml().replace(/<a [^>]*>|<\/a>/g,"")}</span></label>`:""}
    <div class="acts">${cont?`<button class="btn" onclick="v69Cancel()">${onCancel?L("Cancelar y cerrar sesión","Cancel and sign out"):L("Cancelar","Cancel")}</button><button class="btn dark" id="v69-ok" disabled onclick="v69Ok()">${L("Aceptar y continuar","Accept and continue")}</button>`
      :`<button class="btn dark" onclick="v69Close()">${L("Cerrar","Close")}</button>`}</div></div>`;
  m.dataset.origen=origen||"";
  document.body.appendChild(m);
  v69Lang(V69.lang);
}
function v69Ver(){ v69Modal("",null); }
function v69Close(){ const m=$("v69-modal"); if(m) m.remove(); V69.cont=null; V69.onCancel=null; }
function v69Cancel(){ const f=V69.onCancel; v69Close(); if(f) f(); }
async function v69Ok(){
  const m=$("v69-modal"), ck=$("v69-ck2"); if(!m||!ck||!ck.checked) return;
  const cont=V69.cont, origen=m.dataset.origen;
  await v69Save(origen);
  v69Close();
  if(cont) cont();
}
/* exige la aceptación vigente antes de una acción; devuelve true si la frena */
function v69Need(origen,cont){
  if(!v61Logged()||v69Accepted()) return false;
  v69Modal(origen,cont); return true;
}

/* ---------------- el PDF va dentro de los paquetes ---------------- */
async function v69WithPdf(run,path){
  let pdf=null;
  try{ if(location.protocol!=="file:"){ const r=await fetch(V69.pdf); if(r.ok) pdf=await r.arrayBuffer(); } }catch(e){}
  if(pdf&&typeof JSZip!=="undefined"){
    const P=JSZip.prototype, g=P.generateAsync;
    P.generateAsync=function(){ P.generateAsync=g; try{ this.file(path,pdf); }catch(e){} return g.apply(this,arguments); };
    setTimeout(()=>{ if(P.generateAsync!==g) P.generateAsync=g; },30000);
  }
  return run();
}
const V69_buildDesktop=buildDesktop;
buildDesktop=function(){
  const args=arguments, self=this;
  if(!v61Logged()) return V69_buildDesktop.apply(self,args);                 // invitado: pide la cuenta (v6.1)
  if(v69Need("descarga-escritorio",()=>buildDesktop.apply(self,args))) return;
  return v69WithPdf(()=>V69_buildDesktop.apply(self,args),"licencia-artlas.pdf");
};
const V69_downloadRagLocal=downloadRagLocal;
downloadRagLocal=function(){
  const args=arguments, self=this;
  if(!v61Logged()) return V69_downloadRagLocal.apply(self,args);
  if(v69Need("descarga-rag",()=>downloadRagLocal.apply(self,args))) return;
  return v69WithPdf(()=>V69_downloadRagLocal.apply(self,args),"ARTLAS_RAG/LICENCIA-AR.T.L.A.S.pdf");
};
const V69_install=v68Install;
v68Install=function(){
  const args=arguments, self=this;
  if(!v68Standalone()&&v69Need("instalacion-app",()=>v68Install.apply(self,args))) return;
  return V69_install.apply(self,args);
};
/* app instalada: no se entra sin aceptar la versión vigente */
const V69_gateHide=v61GateHide;
v61GateHide=function(){
  const args=arguments, self=this;
  if(v61Logged()&&!v69Accepted()){                                  // v6.8.3: en la web, Escritorio y la app instalada
    if(!$("v69-modal")) v69Modal(v68Standalone()?"app-instalada":"ingreso",()=>v61GateHide.apply(self,args),()=>v69Salir());
    return;
  }
  return V69_gateHide.apply(self,args);
};

/* ---------------- enlaces al documento ---------------- */
const V69_gateRender=v61GateRender;
v61GateRender=function(){
  V69_gateRender.apply(this,arguments);
  const sh=document.querySelector("#v61-gate .g-shell");
  if(sh&&!sh.querySelector(".g-lic")) sh.insertAdjacentHTML("beforeend",`<button class="g-lic" onclick="v69Ver()">${v60L("Política de privacidad · Términos de uso · Licencia","Privacy policy · Terms of use · License")}</button>`);
};
function v69Footer(){
  const sm=document.querySelector("#side-bottom small"); if(!sm||sm.querySelector(".v69-foot")) return;
  sm.insertAdjacentHTML("beforeend",`<br><a class="v69-foot" onclick="v69Ver()">${v60L("Licencia y privacidad","License and privacy")}</a>`);
}
try{ v69Footer(); v69Decorate(); }catch(e){ console.error("v69",e); }
