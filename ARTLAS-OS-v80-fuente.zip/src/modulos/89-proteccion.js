/* ==================================================================
   v6.8 · Protección contra copia
   1) build.mjs publica app.js codificado: abrirlo o descargarlo no muestra el código.
   2) La app solo funciona en los dominios autorizados (artlas.config.json → «dominios»),
      en la versión Escritorio y abierta desde el disco. En otro sitio muestra un aviso
      y queda registrado en el registro de errores (tipo «copia»).
   3) En la app instalada se bloquean el menú contextual (salvo en campos de texto o con
      texto seleccionado, para poder copiar respuestas), F12, Ctrl+U, Ctrl+S y las
      herramientas de desarrollo, igual que en la versión Escritorio.
   Nota: ninguna página web puede ocultar su código por completo; esto disuade la copia,
   no la hace imposible. Lo importante (cuentas y datos) está protegido en Supabase.
   ================================================================== */
const V68_DOM="__ARTLAS_DOMINIOS__".split(",").map(x=>x.trim().toLowerCase()).filter(Boolean);
function v68HostOk(h,list){
  h=String(h==null?"":h).toLowerCase().replace(/\.$/,"");
  if(!h) return true;                                   // archivo del disco (versión Escritorio / Web only local)
  return (list||V68_DOM).some(d=>{ d=String(d).trim().toLowerCase(); if(!d) return false;
    if(d.startsWith("*.")){ const b=d.slice(2); return h===b||h.endsWith("."+b); }
    if(d.includes("*")) return new RegExp("^"+d.split("*").map(x=>x.replace(/[.+?^${}()|[\]\\]/g,"\\$&")).join("[a-z0-9-]+")+"$").test(h);   // p. ej. *--artlas.netlify.app (vistas previas de Netlify)
    return h===d; });
}
function v68Copia(){
  try{ if(location.protocol==="file:"||v68HostOk(location.hostname)) return false; }catch(e){ return false; }
  window.__ARTLAS_COPIA__=true;
  const show=()=>{
    if(!document.body||$("v68-copia")) return;
    const d=document.createElement("div"); d.id="v68-copia"; d.className="v68-copia";
    d.innerHTML=`<img src="emblem.png" alt="" style="width:90px" onerror="this.remove()"><h2>Copia no autorizada de AR.T.L.A.S.</h2>
      <p>Esta plataforma solo funciona en su sitio oficial.<br><small>Unauthorized copy · AR.T.L.A.S. only runs on its official site.</small></p>
      <a href="https://artlas.ar/app.html">Ir a artlas.ar →</a><small style="color:#8f8f8f">© MMFC · AI-TECH · Prof. Mario M. Figueroa de la Cruz</small>`;
    document.body.appendChild(d);
    try{ document.documentElement.style.overflow="hidden"; if(document.activeElement) document.activeElement.blur(); }catch(e){}
  };
  show();
  try{ new MutationObserver(show).observe(document.body,{childList:true}); }catch(e){}
  try{ send=function(){}; }catch(e){}
  setTimeout(()=>{ try{ v67LogErr("copia","Dominio no autorizado: "+location.hostname,"",location.href.slice(0,120)); }catch(e){} },1500);
  return true;
}

/* app instalada: mismas protecciones que la versión Escritorio */
function v68Blocked(e){
  const k=(e.key||"").toLowerCase(), c=e.ctrlKey||e.metaKey;
  return k==="f12"||(c&&(e.shiftKey||e.altKey)&&(k==="i"||k==="j"||k==="c"))||(c&&!e.shiftKey&&!e.altKey&&(k==="u"||k==="s"));
}
function v68Guard(){
  if(window.__v68Guard) return; window.__v68Guard=true;
  document.addEventListener("contextmenu",e=>{
    if(!v68Standalone()) return;
    const t=e.target;
    if(t&&t.closest&&t.closest("input,textarea,[contenteditable=''],[contenteditable='true']")) return;
    try{ if(String(window.getSelection()||"").trim()) return; }catch(x){}
    e.preventDefault();
  },true);
  document.addEventListener("keydown",e=>{ if(v68Standalone()&&v68Blocked(e)){ e.preventDefault(); e.stopPropagation(); } },true);
  document.addEventListener("dragstart",e=>{ if(v68Standalone()&&e.target&&e.target.tagName==="IMG") e.preventDefault(); },true);
}
/* para la versión Escritorio: recupera el código original desde el app.js protegido */
function v68Decode(P,S){
  let k=S>>>0; const o=[]; let b=[];
  for(let i=0;i<P.length;i++){ let c=P.charCodeAt(i); k=(Math.imul(k,1103515245)+12345)>>>0; if(c>31&&c<127) c=(c-32+95-(k>>>16)%95)%95+32; b.push(c); if(b.length>8191){ o.push(String.fromCharCode.apply(null,b)); b=[]; } }
  o.push(String.fromCharCode.apply(null,b)); return o.join("");
}
function v68Unwrap(t){
  t=String(t||"");
  if(t.indexOf("/*ARTLAS-P*/")<0) return t;
  const i=t.lastIndexOf('})("'), j=t.lastIndexOf('",');
  if(i<0||j<i) return t;
  return v68Decode(JSON.parse(t.slice(i+3,j+1)),parseInt(t.slice(j+2),10));
}
try{
  console.log("%cAR.T.L.A.S.","color:#0d2b5e;font-size:22px;font-weight:800;letter-spacing:3px");
  console.log("%c© MMFC · AI-TECH. Código protegido: prohibida su copia, modificación o redistribución sin autorización.","color:#5d6b7a");
}catch(e){}
v68Copia();
v68Guard();
