
/* =====================================================================
   AR.T.L.A.S. · Módulo 98 · AR.T.L.A.S. OS — NAVEGADOR
   · App «Navegador»: barra de direcciones y búsqueda, historial, modo
     Lectura (cualquier sitio: lo lee el núcleo local o Jina Reader y se
     muestra limpio, con los enlaces navegables), modo Original (la página
     dentro de la ventana, si el sitio lo permite), YouTube embebido,
     «Abrir en Chrome» (navegador de la PC) y «Preguntar a AR.T.L.A.S.»
     sobre la página.
   · Asistente: herramientas web.buscar y web.leer (lecturas, sin aprobación;
     bloqueadas en «Solo local») y, si la respuesta no tiene el dato o la
     pregunta es de actualidad, ofrece «Buscar en la web y responder» o
     «Abrir en el Navegador».
   Usa los buscadores de la plataforma (módulo 70: Tavily/Jina con clave,
   DuckDuckGo, Wikipedia, Google Noticias). Envuelve funciones; no cambia la base.
   ===================================================================== */
AOS_IC.globe='<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>';
const AOSN_SITES=[["Google","https://www.google.com"],["Wikipedia","https://es.wikipedia.org"],["Google Académico","https://scholar.google.com"],["arXiv","https://arxiv.org"],["YouTube","https://www.youtube.com"],["Hugging Face","https://huggingface.co"]];
function aosnIsUrl(t){ t=String(t||"").trim(); return /^https?:\/\//i.test(t)||(/^[\w-]+(\.[\w-]+)+(:\d+)?(\/\S*)?$/i.test(t)&&!/\s/.test(t)); }
function aosnNorm(t){ t=String(t||"").trim(); return /^https?:\/\//i.test(t)?t:"https://"+t; }
/* ícono oficial de cada sitio (favicon), cargado en el momento como en cualquier navegador */
function aosnFav(u){ return "https://www.google.com/s2/favicons?sz=64&domain_url="+encodeURIComponent(u); }
function aosnHost(u){ try{ return new URL(u).hostname.replace(/^www\./,""); }catch(e){ return u; } }
function aosnYt(u){ const m=String(u).match(/(?:youtube\.com\/watch\?[^#]*v=|youtu\.be\/|youtube\.com\/shorts\/)([\w-]{6,})/i); return m?m[1]:null; }

/* ---------- red: búsqueda y lectura ---------- */
async function aosnResults(q){
  const items=[], prov=[]; const add=(r,n)=>{ if(r&&r.items) r.items.forEach(x=>{ if(x.url&&!items.some(y=>y.url===x.url)) items.push(x); }); if(r&&r.items&&r.items.length&&!prov.includes(n)) prov.push(n); };
  let answer="";
  try{ if(v63Key("tavily")){ const r=await v63Tavily(q); add(r,"Tavily"); answer=(r&&r.answer)||""; } }catch(e){}
  if(items.length<4){ const [d,w]=await Promise.allSettled([v63Ddg(q),v63Wiki(q)]); if(d.status==="fulfilled") add(d.value,"DuckDuckGo"); if(w.status==="fulfilled") add(w.value,"Wikipedia"); }
  if(!items.length){ try{ add(await v63News(q),"Google News"); }catch(e){} }
  if(!items.length){ try{ add(await v63DdgInstant(q),"DuckDuckGo"); }catch(e){} }
  return {q,items:items.slice(0,10),prov,answer};
}
async function aosnRead(url){
  if(aosNucOk()){
    try{ const r=await aosNuc("web.leer",{url,max:80000}); return {url:r.url,titulo:r.titulo||aosnHost(r.url),texto:r.texto,via:aosL("núcleo local","local core")}; }
    catch(e){ if(!/desconocida|unknown/i.test(e.message||"")) throw e; }
  }
  const r=await v63Fetch("https://r.jina.ai/"+url,{headers:v63JinaH({"Accept":"text/plain","X-Retain-Images":"none"})},20000);
  if(!r||!r.ok) throw new Error(aosL("No pude leer la página. Probá «Original» o «Abrir en Chrome».","Couldn't read the page. Try «Original» or «Open in Chrome»."));
  let t=await r.text(); const tt=(t.match(/^Title:\s*(.*)$/m)||[])[1]||aosnHost(url); const i=t.indexOf("Markdown Content:"); if(i>=0) t=t.slice(i+17);
  t=t.replace(/!\[[^\]]*\]\([^)]*\)/g,"").replace(/\n{3,}/g,"\n\n").trim();
  return {url,titulo:tt.trim(),texto:t,via:"Jina Reader"};
}
async function aosnExternal(url){
  try{ if(aosNucOk()){ await aosNuc("web.abrir",{url}); aosToast(aosL("Abriendo en el navegador de la PC…","Opening in the PC browser…"),"ok"); return; } }catch(e){ if(!/desconocida|unknown/i.test(e.message||"")){ aosToast(e.message,"err"); return; } }
  window.open(url,"_blank","noopener");
}

/* ---------- app Navegador ---------- */
aosRegister("navegador",{title:()=>aosL("Navegador","Browser"),sub:()=>aosL("Buscá y leé la web; preguntale a AR.T.L.A.S. sobre cualquier página","Search and read the web; ask AR.T.L.A.S. about any page"),icon:"globe",desk:true,order:95,single:false,w:980,h:640,
  kw:"navegador browser chrome web internet google buscar página url",
  render(win,opts){
    win.state={hist:[],i:-1,modo:v60LS("atlas_os_nav_modo","lectura"),cur:null};
    win.body.innerHTML=`<style>
      .aosn-bar{display:flex;gap:5px;align-items:center;padding:7px 8px;border-bottom:1px solid #dbe6f3;background:#f4f8fd;flex-wrap:wrap}
      .aosn-bar .aos-btn.sm{padding:4px 8px}.aosn-url{flex:1;min-width:180px;padding:6px 12px!important;border-radius:16px!important;font-size:13px!important}
      .aosn-seg{display:flex;border:1px solid #c9d6e8;border-radius:8px;overflow:hidden}.aosn-seg button{border:none;background:#fff;padding:4px 9px;font-size:12px;color:#33445c;cursor:pointer}.aosn-seg button.on{background:#1976d2;color:#fff}
      .aosn-c{flex:1;overflow:auto;position:relative;background:#fff;user-select:text}
      .aosn-read{max-width:820px;margin:0 auto;padding:22px 26px 40px;font:15px/1.65 Georgia,"Times New Roman",serif;color:#1d2533}
      .aosn-read h1{font:700 24px/1.25 system-ui,sans-serif;color:#0d2b5e}.aosn-read h2,.aosn-read h3{font-family:system-ui,sans-serif;color:#0d2b5e}
      .aosn-read a{color:#1565c0}.aosn-read table{border-collapse:collapse;font-size:13px}.aosn-read td,.aosn-read th{border:1px solid #c9d6e8;padding:3px 6px}.aosn-read pre{white-space:pre-wrap;background:#f4f6fa;padding:8px;border-radius:6px;font-size:12.5px}
      .aosn-meta{font:12px system-ui,sans-serif;color:#6b7a90;margin-bottom:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center}
      .aosn-res{max-width:760px;margin:0 auto;padding:16px 22px}.aosn-r{padding:10px 0;border-bottom:1px solid #eef2f7}.aosn-r a.t{font-size:16px;color:#1a0dab;text-decoration:none;cursor:pointer}.aosn-r a.t:hover{text-decoration:underline}
      .aosn-r .u{font-size:12px;color:#188038;margin:2px 0}.aosn-r .s{font-size:13px;color:#3c4043;line-height:1.45}
      .aosn-home{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100%;padding:30px;gap:16px;background:radial-gradient(ellipse at 50% 30%,#eaf3ff,#fff 70%)}
      .aosn-home .q{width:min(560px,90%);padding:12px 18px;border-radius:24px;border:1px solid #c9d6e8;font-size:15px;outline:none;box-shadow:0 2px 10px rgba(13,43,94,.08)}
      .aosn-home .q:focus{border-color:#1976d2}.aosn-tiles{display:flex;gap:10px;flex-wrap:wrap;justify-content:center}
      .aosn-tiles{max-width:960px;gap:8px!important}.aosn-tiles button{min-width:0;max-width:158px;height:58px;display:flex;align-items:center;gap:9px;padding:8px 12px 8px 9px;border:1px solid #dbe6f3;border-radius:14px;background:#fff;cursor:pointer;font-size:13px;color:#0d2b5e;text-align:left;line-height:1.2;box-shadow:0 1px 3px rgba(13,43,94,.06);transition:transform .12s,box-shadow .12s,border-color .12s}
      .aosn-tiles button:hover{border-color:#4f9cf9;background:#f4f8fd;transform:translateY(-2px);box-shadow:0 6px 14px rgba(13,43,94,.12)}
      .aosn-tiles img{width:34px;height:34px;object-fit:contain;flex:none;border-radius:8px}.aosn-tiles .lt{width:34px;height:34px;border-radius:9px;display:flex;align-items:center;justify-content:center;font:700 16px system-ui;color:#fff;background:linear-gradient(160deg,#4f9cf9,#1565c0);flex:none}
      .aosn-brand{display:flex;align-items:center;gap:14px}.aosn-brand img{width:44px;height:44px;border-radius:10px;box-shadow:0 2px 8px rgba(13,43,94,.25)}
      .aosn-note{padding:6px 12px;background:#fdf6ea;color:#633806;font-size:12px;border-bottom:1px solid #f1e0c2}
    </style>
    <div class="aosn-bar">
      <button class="aos-btn sm" data-n="back" title="${aosEsc(aosL("Atrás","Back"))}">←</button><button class="aos-btn sm" data-n="fwd" title="${aosEsc(aosL("Adelante","Forward"))}">→</button>
      <button class="aos-btn sm" data-n="reload" title="${aosEsc(aosL("Recargar","Reload"))}">⟳</button><button class="aos-btn sm" data-n="home" title="${aosEsc(aosL("Inicio","Home"))}">⌂</button>
      <input class="aos-in aosn-url" placeholder="${aosEsc(aosL("Buscá en la web o escribí una dirección","Search the web or type an address"))}" autocomplete="off" spellcheck="false">
      <div class="aosn-seg"><button data-m="lectura">${aosL("Lectura","Reader")}</button><button data-m="original">${aosL("Original","Original")}</button></div>
      <button class="aos-btn sm" data-n="ask">${aosL("Preguntar a AR.T.L.A.S.","Ask AR.T.L.A.S.")}</button>
      <button class="aos-btn sm" data-n="ext">${(typeof AOS_APPL!=="undefined"&&AOS_APPL)?aosL("Abrir en Chromium","Open in Chromium"):aosL("Abrir en Chrome","Open in Chrome")}</button>
    </div><div class="aosn-c"></div>`;
    const B=win.body, inp=B.querySelector(".aosn-url");
    inp.addEventListener("keydown",e=>{ if(e.key==="Enter"){ e.preventDefault(); aosnGo(win,inp.value); } });
    B.querySelectorAll("[data-m]").forEach(b=>b.onclick=()=>{ win.state.modo=b.dataset.m; v60LSset("atlas_os_nav_modo",b.dataset.m); aosnSeg(win); const c=win.state.cur; if(c&&c.tipo==="url") aosnShow(win,c,false); });
    B.querySelectorAll("[data-n]").forEach(b=>b.onclick=()=>aosnCmd(win,b.dataset.n));
    aosnSeg(win);
    if(opts&&opts.url) aosnGo(win,opts.url); else if(opts&&opts.q) aosnGo(win,opts.q,{buscar:true}); else aosnShow(win,{tipo:"inicio"},true);
  },
  reopen(win,opts){ if(opts&&(opts.url||opts.q)) aosnGo(win,opts.url||opts.q,{buscar:!opts.url}); }
});
function aosnSeg(win){ win.body.querySelectorAll("[data-m]").forEach(b=>b.classList.toggle("on",b.dataset.m===win.state.modo)); }
function aosnCmd(win,k){
  const s=win.state;
  if(k==="back"&&s.i>0){ s.i--; aosnShow(win,s.hist[s.i],false); }
  if(k==="fwd"&&s.i<s.hist.length-1){ s.i++; aosnShow(win,s.hist[s.i],false); }
  if(k==="reload"&&s.cur) aosnShow(win,s.cur,false,true);
  if(k==="home") aosnShow(win,{tipo:"inicio"},true);
  if(k==="ext"){ const c=s.cur; if(c&&c.tipo==="url") aosnExternal(c.url); else if(c&&c.tipo==="buscar") aosnExternal("https://www.google.com/search?q="+encodeURIComponent(c.q)); else aosnExternal("https://www.google.com"); }
  if(k==="ask") aosnAsk(win);
}
function aosnGo(win,t,o){ t=String(t||"").trim(); if(!t) return; o=o||{};
  if(!o.buscar&&aosnIsUrl(t)) return aosnShow(win,{tipo:"url",url:aosnNorm(t)},true);
  return aosnShow(win,{tipo:"buscar",q:t},true);
}
async function aosnShow(win,e,push,force){
  const s=win.state, C=win.body.querySelector(".aosn-c"), inp=win.body.querySelector(".aosn-url");
  if(push){ s.hist=s.hist.slice(0,s.i+1); s.hist.push(e); s.i=s.hist.length-1; }
  s.cur=e; const tok=(s.tok=(s.tok||0)+1);
  inp.value=e.tipo==="url"?e.url:e.tipo==="buscar"?e.q:"";
  if(e.tipo==="inicio"){
    aosTitle(win,aosL("Navegador","Browser"));
    const lg=aosImg("asistente");
    C.innerHTML=`<div class="aosn-home"><div class="aosn-brand">${lg?`<img src="${lg}" alt="">`:""}<div style="font:800 28px system-ui;letter-spacing:.2em;color:#0d2b5e">AR.T.L.A.S. <span style="color:#1aa7ec">WEB</span></div></div>
      <input class="q" placeholder="${aosEsc(aosL("¿Qué querés buscar?","What do you want to search?"))}" autocomplete="off"><div class="aosn-tiles">${AOSN_SITES.map(([n,u])=>`<button data-u="${aosEsc(u)}"><img src="${aosEsc(aosnFav(u))}" alt="" onerror="this.outerHTML='<span class=lt>${aosEsc(n[0])}</span>'">${aosEsc(n)}</button>`).join("")}</div>
      <div style="font-size:12px;color:#6b7a90;max-width:560px;text-align:center">${aosL("«Lectura» muestra cualquier página limpia y con enlaces navegables. Algunos sitios (Google, bancos, redes) no se dejan mostrar dentro de otra página: para esos está «Abrir en Chrome».","«Reader» shows any page clean, with clickable links. Some sites (Google, banks, social networks) can't be shown inside another page: use «Open in Chrome».")}</div></div>`;
    const q=C.querySelector(".q"); q.addEventListener("keydown",ev=>{ if(ev.key==="Enter") aosnGo(win,q.value); }); setTimeout(()=>q.focus(),50);
    C.querySelectorAll("[data-u]").forEach(b=>b.onclick=()=>{ const u=b.dataset.u; if(/google\.com|youtube\.com$/.test(aosnHost(u))&&!/scholar/.test(u)) aosnExternal(u); else aosnGo(win,u); });
    return;
  }
  if(e.tipo==="buscar"){
    aosTitle(win,e.q+" · "+aosL("Búsqueda","Search"));
    C.innerHTML=`<div class="aosn-res"><div class="aosn-meta">${aosL("Buscando…","Searching…")}</div></div>`;
    try{
      const r=(!force&&e.res)||await aosnResults(e.q); if(tok!==s.tok) return; e.res=r;
      const R=C.querySelector(".aosn-res");
      R.innerHTML=`<div class="aosn-meta">${r.items.length?aosL("Resultados de ","Results from ")+aosEsc(r.prov.join(" · ")):aosL("Sin resultados de los buscadores.","No results from the search engines.")}
        <span style="flex:1"></span>${r.items.length?`<button class="aos-btn sm pri" data-x="sum">${aosL("Responder con AR.T.L.A.S.","Answer with AR.T.L.A.S.")}</button>`:""}<button class="aos-btn sm" data-x="g">${aosL("Ver en Google (Chrome)","See on Google (Chrome)")}</button></div>
        ${r.answer?`<div class="aos-card" style="padding:10px 12px;margin-bottom:8px;font-size:13.5px">${aosEsc(v63Clean(r.answer,700))}</div>`:""}
        ${r.items.map((x,i)=>`<div class="aosn-r"><a class="t" data-i="${i}">${aosEsc(x.title||x.url)}</a><div class="u">${aosEsc(aosnHost(x.url))}${x.date?" · "+aosEsc(x.date):""}${x.src?" · "+aosEsc(x.src):""}</div><div class="s">${aosEsc(v63Clean(x.snip||"",280))}</div></div>`).join("")}`;
      R.querySelectorAll("a.t").forEach(a=>a.onclick=()=>aosnGo(win,r.items[+a.dataset.i].url));
      R.querySelector('[data-x="g"]').onclick=()=>aosnExternal("https://www.google.com/search?q="+encodeURIComponent(e.q));
      const sb=R.querySelector('[data-x="sum"]'); if(sb) sb.onclick=()=>aosnAnswer(e.q,r);
    }catch(er){ if(tok===s.tok) C.innerHTML=`<div class="aos-empty">${aosEsc(er.message||String(er))}</div>`; }
    return;
  }
  /* página */
  const yt=aosnYt(e.url);
  if(yt){ aosTitle(win,"YouTube"); C.innerHTML=`<iframe src="https://www.youtube.com/embed/${aosEsc(yt)}" style="border:0;width:100%;height:100%" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`; return; }
  if(s.modo==="original"){
    aosTitle(win,aosnHost(e.url));
    C.innerHTML=`<div class="aosn-note">${aosL("Si la página queda en blanco, ese sitio no permite mostrarse dentro de otra: usá «Lectura» o «Abrir en Chrome».","If the page stays blank, that site can't be shown inside another one: use «Reader» or «Open in Chrome».")}</div><iframe src="${aosEsc(e.url)}" style="border:0;width:100%;height:calc(100% - 30px)" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox" referrerpolicy="no-referrer"></iframe>`;
    return;
  }
  C.innerHTML=`<div class="aosn-read"><div class="aosn-meta">${aosL("Leyendo ","Reading ")+aosEsc(aosnHost(e.url))}…</div></div>`;
  try{
    const p=(!force&&e.page)||await aosnRead(e.url); if(tok!==s.tok) return; e.page=p;
    aosTitle(win,p.titulo||aosnHost(p.url));
    const R=C.querySelector(".aosn-read");
    R.innerHTML=`<div class="aosn-meta"><b style="color:#0d2b5e">${aosEsc(aosnHost(p.url))}</b><span>${aosL("vista de lectura · ","reader view · ")+aosEsc(p.via)}</span></div>${p.titulo&&!/^#\s/.test(p.texto)?`<h1>${aosEsc(p.titulo)}</h1>`:""}${aosOfMd2Html(p.texto.slice(0,150000))}`;
    R.querySelectorAll("a[href]").forEach(a=>{ const h=a.getAttribute("href"); a.onclick=ev=>{ ev.preventDefault(); if(/^https?:/i.test(h)) aosnGo(win,h); }; a.title=h; });
  }catch(er){
    if(tok!==s.tok) return;
    C.innerHTML=`<div class="aos-empty" style="padding:30px">${aosEsc(er.message||String(er))}<div style="margin-top:12px;display:flex;gap:6px;justify-content:center"><button class="aos-btn" data-y="o">${aosL("Ver «Original»","View «Original»")}</button><button class="aos-btn pri" data-y="c">${aosL("Abrir en Chrome","Open in Chrome")}</button></div></div>`;
    C.querySelector('[data-y="o"]').onclick=()=>{ s.modo="original"; aosnSeg(win); aosnShow(win,e,false); };
    C.querySelector('[data-y="c"]').onclick=()=>aosnExternal(e.url);
  }
}
function aosnAsk(win){
  const c=win.state.cur; if(!c||c.tipo==="inicio"){ aosToast(aosL("Abrí primero una página o una búsqueda.","Open a page or a search first."),"warn"); return; }
  const w=aosLaunch("asistente"); if(!w) return;
  if(c.tipo==="buscar"&&c.res) aosAgentAttachText(w,aosL("Búsqueda: ","Search: ")+c.q,aosnFmt(c.res));
  else if(c.page) aosAgentAttachText(w,c.page.titulo||aosnHost(c.url),"URL: "+c.page.url+"\n\n"+c.page.texto.slice(0,24000));
  else aosAgentAttachText(w,aosnHost(c.url),"URL: "+c.url);
  const ta=w.body.querySelector(".aosa-in"); if(ta) ta.placeholder=aosL("¿Qué querés saber de esta página?","What do you want to know about this page?");
}
function aosnFmt(r,read){
  let s=aosL("Fecha de hoy: ","Today: ")+v63Today()+"\n"+aosL("Resultados de búsqueda web para «","Web search results for «")+r.q+"» ("+r.prov.join(" · ")+"):\n\n";
  if(r.answer) s+=aosL("Resumen del buscador: ","Search engine summary: ")+v63Clean(r.answer,900)+"\n\n";
  r.items.forEach((x,i)=>{ s+="["+(i+1)+"] "+(x.title||"")+(x.date?" ("+x.date+")":"")+"\nURL: "+x.url+"\n"+v63Clean(x.snip||"",400)+"\n\n"; });
  (read||[]).forEach(p=>{ s+="--- "+aosL("Contenido de ","Content of ")+p.url+" ---\n"+p.texto.slice(0,6000)+"\n\n"; });
  return s;
}
async function aosnSearchPack(q){
  const r=await aosnResults(q); const read=[];
  const top=r.items.filter(x=>!/news\.google\.com/.test(x.url)).slice(0,2);
  const got=await Promise.allSettled(top.map(x=>aosnRead(x.url)));
  got.forEach(g=>{ if(g.status==="fulfilled"&&g.value.texto&&g.value.texto.length>200) read.push(g.value); });
  return {r,read,text:aosnFmt(r,read)};
}
async function aosnAnswer(q,r){
  const w=aosLaunch("asistente"); if(!w) return;
  aosAgentAttachText(w,aosL("Búsqueda web: ","Web search: ")+q,aosL("INSTRUCCIÓN: respondé con estos resultados de la web y citá las fuentes con su URL.\n\n","INSTRUCTION: answer with these web results and cite the sources with their URL.\n\n")+aosnFmt(r));
  aosAgentAsk(w,q);
}

/* ---------- asistente: herramientas web y oferta de navegar ---------- */
["web.buscar","web.leer","web.navegar"].forEach(o=>{ AOS_OPS.add(o); AOS_READ.add(o); });
const V98n_aosSysPrompt=aosSysPrompt;
aosSysPrompt=function(){
  const base=V98n_aosSysPrompt.apply(this,arguments); if(aosMotor()==="solo-local") return base;
  const extra=aosL(
`WEB (lecturas, sin aprobación): web.buscar {q} → resultados con título, URL y extracto · web.leer {url} → texto de la página · web.navegar {url} o {q} → la abre en el Navegador para el usuario.
Si la pregunta necesita datos actuales o que no conocés, buscá en la web en lugar de decir que no sabés, y citá las URLs.`,
`WEB (reads, no approval): web.buscar {q} → results with title, URL and snippet · web.leer {url} → page text · web.navegar {url} or {q} → opens it in the Browser for the user.
If the question needs current data or facts you don't know, search the web instead of saying you don't know, and cite the URLs.`);
  return base.replace(/\nREGLAS:|\nRULES:/,m=>"\n"+extra+m);
};
const V98n_aosOpDesc=aosOpDesc;
aosOpDesc=function(o){
  if(o.op==="web.buscar") return aosL("Buscar en la web ","Search the web for ")+"«"+aosEsc(o.q||"")+"»";
  if(o.op==="web.leer") return aosL("Leer la página ","Read the page ")+"<b>"+aosEsc(aosnHost(o.url||""))+"</b>";
  if(o.op==="web.navegar") return aosL("Abrir en el Navegador ","Open in the Browser ")+"<b>"+aosEsc(o.url?aosnHost(o.url):(o.q||""))+"</b>";
  return V98n_aosOpDesc.apply(this,arguments);
};
const V98n_aosExec=aosExec;
aosExec=async function(o,ctx){
  if(!/^web\./.test(o&&o.op||"")) return V98n_aosExec.apply(this,arguments);
  const t0=performance.now(); const done=(text,short)=>({ok:true,text,short,ms:performance.now()-t0});
  try{
    if(o.op==="web.navegar"){ aosLaunch("navegador",o.url?{url:o.url,nuevo:true}:{q:o.q||"",nuevo:true}); return done("OK",aosL("abrió el Navegador","opened the Browser")); }
    if(aosMotor()==="solo-local") throw new Error(aosL("modo «Solo local»: sin internet","«Local only» mode: no internet"));
    AOS._webTurn=true;
    if(o.op==="web.buscar"){ const r=await aosnResults(String(o.q||"")); if(!r.items.length) return done(aosL("Sin resultados.","No results."),aosL("buscó en la web: sin resultados","searched the web: no results")); return done(aosnFmt(r).slice(0,6000),aosL("buscó en la web · ","searched the web · ")+r.items.length); }
    if(o.op==="web.leer"){ const p=await aosnRead(aosnNorm(o.url)); return done(("TÍTULO: "+p.titulo+"\nURL: "+p.url+"\n\n"+p.texto).slice(0,12000),aosL("leyó ","read ")+aosnHost(p.url)); }
  }catch(e){ return {ok:false,text:"ERROR: "+(e.message||e),short:"⚠ "+(e.message||e),ms:performance.now()-t0}; }
};
const V98n_aosQuick=aosQuick;
aosQuick=async function(q){
  const t=String(q||"").trim();
  let m=t.match(/^(?:busc[aá](?:me)?|googlea|search(?: for)?)\s+(?:en\s+)?(?:la web|internet|google|the web)\s*:?\s+(.+)$/i)||t.match(/^(?:busc[aá](?:me)?)\s+(.+?)\s+en\s+(?:la web|internet|google)$/i);
  if(m) return [{op:"web.navegar",q:m[1]}];
  m=t.match(/^(?:abr[ií](?:me)?|ir a|and[aá] a|open|go to)\s+(?:la (?:p[aá]gina|web)\s+)?(https?:\/\/\S+|[\w-]+(?:\.[\w-]+)+(?:\/\S*)?)$/i);
  if(m) return [{op:"web.navegar",url:aosnNorm(m[1])}];
  if(/^(?:abr[ií](?:me)?|open)\s+(?:el\s+)?(?:navegador|browser)$/i.test(t)) return [{op:"web.navegar",q:""}];
  return V98n_aosQuick.apply(this,arguments);
};
const V98n_aosAgentAsk=aosAgentAsk;
aosAgentAsk=async function(win,q){
  AOS._webTurn=false; const hadCtx=!!(win&&win.state&&win.state.ctx&&win.state.ctx.some(c=>/^(Búsqueda web|Web search)/.test(c.nombre||"")));
  const r=await V98n_aosAgentAsk.apply(this,arguments);
  try{
    if(!win||hadCtx||AOS._webTurn||aosMotor()==="solo-local") return r;
    const bubbles=win.body.querySelectorAll(".aosa-m .aosa-txt"); const last=bubbles[bubbles.length-1]; if(!last) return r;
    const ans=last.innerText||""; const noInfo=v63SaysNoInfo(ans)||/no (tengo|puedo) (acceso|consultar|navegar)|sin acceso a internet|no puedo buscar|i (don'?t|do not) have (access|real-time)/i.test(ans);
    let actual=false; try{ actual=v63NeedsWeb(q); }catch(e){}
    if(!noInfo&&!actual) return r;
    const box=document.createElement("div"); box.className="aosa-web"; box.style.cssText="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:8px;padding-top:8px;border-top:1px dashed #dbe6f3;font-size:12.5px;color:#33445c";
    box.innerHTML=`<span>${noInfo?aosL("¿Lo busco en la web?","Shall I search the web?"):aosL("Para datos actualizados:","For up-to-date data:")}</span><button class="aos-btn sm pri" data-w="buscar">🔎 ${aosL("Buscar en la web y responder","Search the web and answer")}</button><button class="aos-btn sm" data-w="nav">🌐 ${aosL("Abrir en el Navegador","Open in the Browser")}</button>`;
    last.parentNode.appendChild(box);
    box.querySelector('[data-w="nav"]').onclick=()=>aosLaunch("navegador",{q,nuevo:true});
    box.querySelector('[data-w="buscar"]').onclick=async ev=>{
      box.querySelectorAll("button").forEach(b=>b.disabled=true); ev.target.textContent="🔎 "+aosL("Buscando…","Searching…");
      try{ const pk=await aosnSearchPack(q); if(!pk.r.items.length){ ev.target.textContent=aosL("Sin resultados","No results"); box.querySelector('[data-w="nav"]').disabled=false; return; }
        aosAgentAttachText(win,aosL("Búsqueda web: ","Web search: ")+q,aosL("INSTRUCCIÓN: respondé con estos resultados de la web y citá las fuentes con su URL.\n\n","INSTRUCTION: answer with these web results and cite the sources with their URL.\n\n")+pk.text);
        box.remove(); await aosAgentAsk(win,q);
      }catch(e){ ev.target.textContent="⚠ "+(e.message||e); }
    };
    const M=win.body.querySelector(".aosa-m"); if(M) M.scrollTop=M.scrollHeight;
  }catch(e){}
  return r;
};

/* ---------- v7.2 · AI Navigator Hub (el hub de navegación de herramientas de IA de AI-TECH) ---------- */
const AOS_HUB_URL="https://ainavigatorhub-v2.netlify.app/";
aosRegister("hub",{title:()=>"AI Navigator Hub",sub:()=>aosL("Hub de navegación de herramientas de IA","AI tools navigation hub"),icon:"globe",desk:true,order:96,w:1120,h:700,
  kw:"hub navigator ai navigator hub herramientas ia chatgpt gemini claude deepseek copilot",
  render(win){
    win.body.innerHTML=`<div class="aos-tbar" style="gap:6px">
        <button class="aos-btn sm" data-h="reload" title="${aosEsc(aosL("Recargar","Reload"))}">⟳</button>
        <span style="font-size:12px;color:#6b7a90;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${aosEsc(AOS_HUB_URL.replace(/^https:\/\//,"").replace(/\/$/,""))}</span>
        <button class="aos-btn sm" data-h="ext">${aosL("Abrir en Chrome","Open in Chrome")}</button></div>
      <iframe class="aoshub-f" src="${AOS_HUB_URL}" style="border:0;width:100%;height:calc(100% - 42px);background:#0a1a3f" allow="clipboard-write; fullscreen" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads" referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
    win.body.querySelector('[data-h="reload"]').onclick=()=>{ const f=win.body.querySelector(".aoshub-f"); f.src=AOS_HUB_URL+"?t="+Date.now(); };
    win.body.querySelector('[data-h="ext"]').onclick=()=>aosnExternal(AOS_HUB_URL);
  }
});
