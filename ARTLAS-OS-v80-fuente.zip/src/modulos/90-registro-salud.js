
/* =====================================================================
   AR.T.L.A.S. · Módulo REGISTRO DE ERRORES y SALUD DE LA PLATAFORMA
   - Captura errores de JavaScript (error / unhandledrejection).
   - Los guarda en este navegador (últimos 50) y, si existe la tabla
     public.atlas_errors en Supabase, los envía (solo inserción).
   - Nunca registra conversaciones, claves ni datos de cuentas: solo
     mensaje, origen, versión, navegador y ruta.
   - Control Center → «Salud de la plataforma», visible solo para el
     administrador (función SQL atlas_is_admin()).
   ===================================================================== */
const V67_BUILD=window.__ARTLAS_BUILD__||null;   // lo agrega build.mjs al compilar
const V67E={sent:0,max:15,seen:{},sid:Math.random().toString(36).slice(2,10),admin:null,remote:null};
function v67ErrLocal(){ try{ return JSON.parse(localStorage.getItem("atlas_errlog")||"[]"); }catch(e){ return []; } }
function v67Scrub(s){ return String(s||"").replace(/(sk-|gsk_|sk-ant-|AIza|hf_|tvly-|jina_)[A-Za-z0-9_\-]{6,}/g,"$1•••").replace(/[\w.+-]+@[\w-]+\.[\w.]+/g,"•@•"); }
function v67LogErr(kind,msg,stack,src){
  msg=v67Scrub(msg).slice(0,300); if(!msg) return;
  if(/ResizeObserver loop|Script error\.?$|^cancel(l)?ed$|AbortError/i.test(msg)) return;
  if(/chrome-extension:|moz-extension:|safari-extension:/.test(String(src)+String(stack))) return;
  const key=kind+"|"+msg;
  const rec={t:Date.now(),kind,msg,src:v67Scrub(src).slice(0,160),stack:v67Scrub(stack).slice(0,1200),ver:V60.ver};
  try{
    const L=v67ErrLocal(); const ex=L.find(x=>x.kind===kind&&x.msg===msg&&x.ver===rec.ver);
    if(ex){ ex.n=(ex.n||1)+1; ex.t=rec.t; } else { rec.n=1; L.unshift(rec); }
    localStorage.setItem("atlas_errlog",JSON.stringify(L.slice(0,50)));
  }catch(e){}
  if(V67E.seen[key]||V67E.sent>=V67E.max) return;
  V67E.seen[key]=1; V67E.sent++;
  try{
    if(typeof supa!=="undefined"&&supa&&supa.from)
      supa.from("atlas_errors").insert({ver:V60.ver,kind,msg,stack:rec.stack,src:rec.src,path:location.protocol==="file:"?"escritorio":location.pathname,ua:navigator.userAgent.slice(0,180),sess:V67E.sid}).then(()=>{},()=>{});
  }catch(e){}
}
window.addEventListener("error",e=>{ try{ v67LogErr("error",e.message||(e.error&&e.error.message)||"",(e.error&&e.error.stack)||"",(e.filename||"").split("/").pop().split("?")[0]+":"+(e.lineno||0)+":"+(e.colno||0)); }catch(x){} });
window.addEventListener("unhandledrejection",e=>{ try{ const r=e.reason; v67LogErr("promesa",(r&&r.message)||String(r||""),(r&&r.stack)||"",""); }catch(x){} });

/* ---------- ¿administrador? (decide el servidor, no el navegador) ---------- */
async function v67IsAdmin(){
  if(V67E.admin!==null) return V67E.admin;
  try{
    if(typeof supa==="undefined"||!supa||!user){ return false; }
    const {data,error}=await supa.rpc("atlas_is_admin");
    V67E.admin=!error&&data===true;
  }catch(e){ V67E.admin=false; }
  return V67E.admin;
}
v60Wrap("doLogout",()=>{ V67E.admin=null; V67E.remote=null; });
async function v67LoadRemote(){
  try{
    const {data,error}=await supa.from("atlas_errors").select("created_at,ver,kind,msg,src,path,ua").order("created_at",{ascending:false}).limit(300);
    if(error) return {error:error.message||String(error)};
    const g={};
    (data||[]).forEach(r=>{ const k=r.ver+"|"+r.msg; if(!g[k]) g[k]={ver:r.ver,msg:r.msg,src:r.src,n:0,last:r.created_at,first:r.created_at,ua:r.ua}; g[k].n++; if(r.created_at<g[k].first) g[k].first=r.created_at; });
    return {rows:Object.values(g).sort((a,b)=>b.last<a.last?-1:1),total:(data||[]).length};
  }catch(e){ return {error:(e&&e.message)||String(e)}; }
}
function v67Kb(n){ return n>=1048576?(n/1048576).toFixed(2).replace(".",",")+" MB":Math.round(n/1024)+" KB"; }
function v67When(t){ try{ return new Date(t).toLocaleString(atlasLang==="en"?"en-US":"es-AR",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"}); }catch(e){ return ""; } }
function v67Browser(ua){ ua=String(ua||""); const m=/(Edg|OPR|Chrome|Firefox|Version)\/(\d+)/.exec(ua); if(!m) return "—"; const n={Edg:"Edge",OPR:"Opera",Chrome:"Chrome",Firefox:"Firefox",Version:"Safari"}[m[1]]; return n+" "+m[2]+(/Mobile|Android|iPhone/.test(ua)?" · "+v60L("móvil","mobile"):""); }
async function v67HealthHtml(){
  const B=V67_BUILD||{};
  const L=v67ErrLocal();
  const rem=V67E.remote||(V67E.remote=await v67LoadRemote());
  const tests=B.pruebas||null;
  const errs7=(rem.rows||[]).filter(r=>Date.now()-new Date(r.last).getTime()<7*864e5).reduce((n,r)=>n+r.n,0);
  const kpi=(t,v,s,cls)=>`<div class="v67h-kpi"><small>${t}</small><b class="${cls||""}">${v}</b><span>${s||""}</span></div>`;
  const mods=(B.modulos||[]).map(m=>`<span class="v67h-mod" title="${v67Kb(m.bytes)}">${v60Esc(m.n)}</span>`).join("");
  const testRows=tests?(tests.suites||[]).map(s=>`<tr><td>${v60Esc(s.nombre)}</td><td class="num">${s.ok}/${s.total}</td><td><span class="v67h-tag ${s.ok===s.total?"ok":"err"}">${s.ok===s.total?"✓":"✗"}</span></td></tr>`).join(""):"";
  const remRows=rem.error?`<tr><td colspan="4" class="dim">${v60L("No se pudo leer la tabla atlas_errors","Could not read the atlas_errors table")}: ${v60Esc(rem.error)}. ${v60L("¿Ejecutaste supabase/registro-errores.sql?","Did you run supabase/registro-errores.sql?")}</td></tr>`
    :(rem.rows||[]).slice(0,12).map(r=>`<tr><td>${v60Esc(r.msg)}<div class="dim" style="font-size:11px">${v60Esc(r.src||"")} · ${v60Esc(v67Browser(r.ua))} · ${v67When(r.last)}</div></td><td>${v60Esc(r.ver||"")}</td><td class="num">${r.n}</td><td><span class="v67h-tag ${r.ver===V60.ver?"warn":"ok"}">${r.ver===V60.ver?v60L("Actual","Current"):v60L("Anterior","Older")}</span></td></tr>`).join("")
    ||`<tr><td colspan="4" class="dim">✓ ${v60L("Sin errores registrados.","No errors recorded.")}</td></tr>`;
  const locRows=L.slice(0,6).map(r=>`<tr><td>${v60Esc(r.msg)}<div class="dim" style="font-size:11px">${v60Esc(r.src||"")} · ${v67When(r.t)}</div></td><td>${v60Esc(r.ver||"")}</td><td class="num">${r.n||1}</td></tr>`).join("")||`<tr><td colspan="3" class="dim">✓ ${v60L("Sin errores en este navegador.","No errors in this browser.")}</td></tr>`;
  return `<div class="card mt v67h" id="v67-health"><h4>⚙️ ${v60L("Salud de la plataforma","Platform health")} <small class="dim" style="font-weight:500">· ${v60L("visible solo para el administrador","visible to the administrator only")}</small></h4>
    <div class="v67h-kpis">
      ${kpi(v60L("Versión publicada","Published version"),v60Esc(V60.ver),B.fecha?v60L("Compilación del ","Built on ")+v67When(B.fecha):"")}
      ${kpi(v60L("Pruebas automáticas","Automated tests"),tests?tests.ok+" / "+tests.total:"—",tests?(tests.ok===tests.total?"✓ "+v60L("Todas aprobadas","All passed"):"✗ "+v60L("Hay pruebas fallidas","Some tests failed")):v60L("sin reporte","no report"),tests&&tests.ok===tests.total?"ok":"")}
      ${kpi(v60L("Errores en producción · 7 días","Production errors · 7 days"),rem.error?"—":errs7,rem.error?v60L("tabla sin configurar","table not set up"):(rem.total||0)+" "+v60L("registros recientes","recent records"))}
      ${kpi(v60L("Tamaño de app.js","app.js size"),B.min?v67Kb(B.min):"—",B.total?v60L("fuente: ","source: ")+v67Kb(B.total)+" · "+(B.modulos||[]).length+" "+v60L("módulos","modules"):"")}
    </div>
    <div class="v67h-grid">
      <div><h5>📦 ${v60L("Módulos","Modules")}</h5><div class="v67h-mods">${mods||"—"}</div>
        <p class="dim" style="font-size:11.5px;margin-top:8px">${v60L("El código se mantiene en módulos y se compila en un único app.js minificado. La versión de escritorio se arma igual que siempre.","Code is kept in modules and compiled into a single minified app.js. The desktop version is built as always.")}</p></div>
      <div><h5>🧪 ${v60L("Pruebas automáticas","Automated tests")}${tests&&tests.fecha?` <small class="dim">· ${v67When(tests.fecha)}</small>`:""}</h5>
        ${tests?`<table class="tbl v67h-tbl">${testRows}</table>`:`<p class="dim" style="font-size:12px">${v60L("Sin reporte de pruebas en esta compilación.","No test report in this build.")}</p>`}</div>
      <div><h5>🚨 ${v60L("Registro de errores (todos los usuarios)","Error log (all users)")}</h5>
        <table class="tbl v67h-tbl"><tr><th>${v60L("Error","Error")}</th><th>${v60L("Versión","Version")}</th><th class="num">${v60L("Veces","Count")}</th><th></th></tr>${remRows}</table>
        <h5 style="margin-top:12px">💻 ${v60L("En este navegador","In this browser")}</h5>
        <table class="tbl v67h-tbl"><tr><th>${v60L("Error","Error")}</th><th>${v60L("Versión","Version")}</th><th class="num">${v60L("Veces","Count")}</th></tr>${locRows}</table>
        <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap"><button class="btn sm" onclick="V67E.remote=null;v60RenderControl()">🔄 ${v60L("Actualizar","Refresh")}</button><button class="btn sm" onclick="try{localStorage.removeItem('atlas_errlog')}catch(e){};v60RenderControl()">🧹 ${v60L("Limpiar registro local","Clear local log")}</button></div>
        <p class="dim" style="font-size:11.5px;margin-top:8px">${v60L("Se registran el mensaje del error, la versión, el navegador y la sección. Nunca conversaciones, documentos ni claves.","Only the error message, version, browser and section are recorded. Never conversations, documents or keys.")}</p></div>
    </div></div>`;
}
const V67_renderControl=v60RenderControl;
v60RenderControl=function(){
  V67_renderControl.apply(this,arguments);
  const el=$("control-inner"); if(!el) return;
  v67IsAdmin().then(async ok=>{
    if(!ok||curView!=="control") return;
    const html=await v67HealthHtml();
    if(curView!=="control") return;
    const old=$("v67-health"); if(old) old.remove();
    el.insertAdjacentHTML("beforeend",html);
  });
};
