
/* ==================== SKILLS PARA AGENTES ====================
   Una skill es un procedimiento reutilizable (nombre + cuándo usarla +
   instrucciones + referencia opcional). Se asignan a los agentes y se
   inyectan en su prompt de sistema. Import/Export en formato SKILL.md
   (frontmatter name/description), compatible con Agent Skills.          */
const V60_SK_BUILTIN=[
  {id:"sk_apa7", icon:"🎓", name:"Redacción académica APA 7",
   desc:"Cuando haya que redactar o revisar textos académicos: informes, tesis, papers, estado del arte o trabajos prácticos.",
   instr:"1. Estructurá el texto en: Introducción, Desarrollo (con subtítulos), Conclusiones y Referencias.\n2. Usá registro formal, impersonal y preciso; evitá coloquialismos y adjetivos vacíos.\n3. Citá en el texto con formato APA 7: (Autor, año) o Autor (año); para 3 o más autores usá «et al.» desde la primera cita.\n4. Armá la lista de Referencias en orden alfabético con sangría francesa. Artículo: Apellido, I. (año). Título. *Revista*, volumen(número), páginas. https://doi.org/...\n5. NUNCA inventes referencias, DOI ni páginas: si no podés verificar una fuente, marcala como [VERIFICAR].\n6. Cerrá con una lista breve de mejoras sugeridas al texto (claridad, coherencia, evidencia)."},
  {id:"sk_link", icon:"📡", name:"Cálculo de radioenlace (link budget)",
   desc:"Cuando se pida diseñar, dimensionar o verificar un enlace de radio o microondas punto a punto.",
   instr:"1. Listá los datos de entrada y supuestos: frecuencia f, distancia d, potencia Ptx, ganancias Gtx/Grx, pérdidas de cables/conectores, sensibilidad del receptor.\n2. Pérdida en espacio libre: FSPL(dB) = 20·log10(d_km) + 20·log10(f_MHz) + 32,44.\n3. Potencia recibida: Prx(dBm) = Ptx(dBm) + Gtx(dBi) + Grx(dBi) − Lcables(dB) − FSPL(dB) − Lotras(dB).\n4. Margen de desvanecimiento: MF = Prx − Sensibilidad. Recomendá MF ≥ 20 dB en enlaces críticos y justificá.\n5. Primera zona de Fresnel en el punto crítico: r1(m) = 17,32·√(d1·d2 / (f_GHz·d)), con d1, d2, d en km. Exigí despeje ≥ 60 % de r1.\n6. Presentá los resultados en una tabla (parámetro, valor, unidad), verificá unidades y concluí si el enlace es viable."},
  {id:"sk_ipv4", icon:"🌐", name:"Subneteo IPv4 / VLSM",
   desc:"Cuando se pida dividir una red IPv4, calcular máscaras o planificar el direccionamiento de una red.",
   instr:"1. Ordená los requerimientos de hosts de mayor a menor.\n2. Para cada subred: bits de host h = ⌈log2(hosts + 2)⌉, prefijo = 32 − h, tamaño de bloque = 2^h.\n3. Asigná las subredes en forma contigua, alineadas a su tamaño de bloque, empezando por la dirección base.\n4. Presentá una tabla: Subred, Hosts pedidos, Hosts útiles, Prefijo, Máscara, Dirección de red, Primer host, Último host, Broadcast.\n5. Verificá que no haya solapamientos y que todo quepa en la red original; informá el espacio libre restante.\n6. Con fines didácticos, mostrá el cálculo en binario de al menos una subred."},
  {id:"sk_eda", icon:"📊", name:"Análisis exploratorio de datos (EDA)",
   desc:"Cuando el usuario comparta datos (CSV/Excel) o pida analizarlos, perfilarlos o sacar conclusiones.",
   instr:"1. Perfilá el dataset: filas, columnas, tipos, valores faltantes y duplicados.\n2. Calculá estadística descriptiva por variable (media, mediana, desvío, mín, máx, percentiles).\n3. Detectá outliers con el criterio IQR (Q1 − 1,5·IQR; Q3 + 1,5·IQR) y comentá su posible causa.\n4. Analizá correlaciones relevantes (Pearson/Spearman) sin confundir correlación con causalidad.\n5. Sugerí las visualizaciones adecuadas para cada hallazgo.\n6. Entregá código Python (pandas / matplotlib) reproducible.\n7. Cerrá con conclusiones, limitaciones de los datos y próximos pasos."},
  {id:"sk_exec", icon:"📋", name:"Informe ejecutivo",
   desc:"Cuando se pida un resumen para directivos, un informe de situación o una recomendación para tomar una decisión.",
   instr:"1. Empezá con la conclusión (BLUF): una o dos oraciones con la recomendación principal.\n2. Contexto en no más de 3 líneas.\n3. De 3 a 5 hallazgos clave, cada uno con su dato o evidencia.\n4. Riesgos y supuestos.\n5. Recomendación y próximos pasos con responsable y plazo sugeridos.\n6. Extensión máxima: una página. Lenguaje claro, sin jerga innecesaria."},
  {id:"sk_code", icon:"🧪", name:"Revisión de código",
   desc:"Cuando se comparta código o se pida revisarlo, depurarlo, optimizarlo o mejorarlo.",
   instr:"1. Entendé el objetivo del código antes de opinar; si falta contexto, indicá tus supuestos.\n2. Revisá en este orden: corrección (bugs y casos borde), seguridad (inyección, secretos expuestos, validación de entradas), rendimiento y legibilidad.\n3. Listá los problemas priorizados como CRÍTICO / MEDIO / MENOR, indicando la línea o fragmento y el porqué.\n4. Entregá el código corregido completo en un bloque, sin funciones vacías ni TODO.\n5. Sugerí pruebas unitarias para los casos críticos."}
];
function v60SkillsAll(){
  const userSk=v60J("atlas_skills",[]), hidden=v60J("atlas_skills_hidden",[]);
  const map=new Map();
  V60_SK_BUILTIN.forEach(s=>{ if(!hidden.includes(s.id)) map.set(s.id,{...s,builtin:true}); });
  userSk.forEach(s=>{ if(s&&s.id) map.set(s.id,{...s,builtin:!!V60_SK_BUILTIN.find(b=>b.id===s.id),edited:true}); });
  return [...map.values()];
}
function v60SkillGet(id){ return v60SkillsAll().find(s=>s.id===id); }
function v60AgentSkills(a){ return ((a&&a.skills)||[]).map(v60SkillGet).filter(Boolean); }
function v60SkillStore(s){
  const list=v60J("atlas_skills",[]);
  const clean={id:s.id,icon:s.icon||"🧩",name:s.name,desc:s.desc||"",instr:s.instr||"",ref:s.ref||"",refName:s.refName||"",updated:Date.now()};
  const i=list.findIndex(x=>x.id===s.id); if(i>=0) list[i]=clean; else list.unshift(clean);
  const hidden=v60J("atlas_skills_hidden",[]).filter(x=>x!==s.id); v60LSset("atlas_skills_hidden",JSON.stringify(hidden));
  if(!v60LSset("atlas_skills",JSON.stringify(list))){ alert(v60L("No hay espacio suficiente en el navegador para guardar esta skill. Reducí el texto de referencia.","Not enough browser storage to save this skill. Shorten the reference text.")); return false; }
  return true;
}
function v60SkillDel(id){
  const s=v60SkillGet(id); if(!s) return;
  const used=agents.filter(a=>(a.skills||[]).includes(id)).length;
  if(!confirm(v60L(`¿Eliminar la skill «${s.name}»?`+(used?` La usan ${used} agente(s).`:""),`Delete skill “${s.name}”?`+(used?` ${used} agent(s) use it.`:"")))) return;
  v60LSset("atlas_skills",JSON.stringify(v60J("atlas_skills",[]).filter(x=>x.id!==id)));
  if(V60_SK_BUILTIN.find(b=>b.id===id)){ const h=v60J("atlas_skills_hidden",[]); if(!h.includes(id)) h.push(id); v60LSset("atlas_skills_hidden",JSON.stringify(h)); }
  v60RenderSkillsUI(); renderAgents();
}
function v60SkillsRestore(){ localStorage.removeItem("atlas_skills_hidden"); v60RenderSkillsUI(); }
function v60Slug(t){ return (t||"skill").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,64)||"skill"; }
function v60SkillToMd(s){
  const oneLine=(s.desc||"").replace(/\s+/g," ").trim().replace(/"/g,'\\"');
  return `---\nname: ${v60Slug(s.name)}\ndescription: "${oneLine}"\n---\n\n# ${s.name}\n\n${(s.instr||"").trim()}\n`+(s.ref?`\n## ${v60L("Referencia","Reference")}${s.refName?" ("+s.refName+")":""}\n\n${s.ref.trim()}\n`:"");
}
async function v60SkillExport(id){
  const s=v60SkillGet(id); if(!s) return;
  const slug=v60Slug(s.name), md=v60SkillToMd(s);
  let blob, fname;
  if(typeof JSZip!=="undefined"){ const z=new JSZip(); z.folder(slug).file("SKILL.md",md); blob=await z.generateAsync({type:"blob"}); fname=slug+".zip"; }
  else { blob=new Blob([md],{type:"text/markdown"}); fname=slug+".SKILL.md"; }
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=fname; a.click();
}
function v60ParseSkillMd(text,fname){
  text=(text||"").replace(/\r\n/g,"\n");
  let name="", desc="", body=text;
  const m=text.match(/^---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  if(m){
    body=m[2]; const lines=m[1].split("\n");
    for(let i=0;i<lines.length;i++){
      const mm=lines[i].match(/^([A-Za-z_][\w-]*)\s*:\s*(.*)$/); if(!mm) continue;
      let k=mm[1].toLowerCase(), v=mm[2].trim();
      if(v===">"||v==="|"||v===">-"||v==="|-"||v===""){ const acc=[]; while(i+1<lines.length&&/^\s+/.test(lines[i+1])){ acc.push(lines[++i].trim()); } v=acc.join(v.startsWith("|")?"\n":" "); }
      v=v.replace(/^["']|["']$/g,"").replace(/\\"/g,'"');
      if(k==="name") name=v; if(k==="description") desc=v;
    }
  }
  let title=""; const h=body.match(/^\s*#\s+(.+)\n/); if(h){ title=h[1].trim(); body=body.slice(h.index+h[0].length); }
  let ref="", refName="";
  const rm=body.match(/\n##\s+(?:Referencia|Reference)(?:\s*\(([^)]*)\))?\s*\n([\s\S]*)$/i);
  if(rm){ ref=rm[2].trim(); refName=rm[1]||""; body=body.slice(0,rm.index); }
  const pretty=(name||"").replace(/-/g," ").replace(/^\w/,c=>c.toUpperCase());
  return {name:title||pretty||(fname||"Skill").replace(/\.(md|txt)$/i,""), desc, instr:body.trim(), ref:ref.slice(0,60000), refName};
}
async function v60SkillImport(files){
  const f=files&&files[0]; const inpEl=$("sk-imp"); if(inpEl) inpEl.value=""; if(!f) return;
  try{
    let draft;
    if(/\.(zip|skill)$/i.test(f.name)){
      if(typeof JSZip==="undefined") throw new Error(v60L("El empaquetador ZIP no cargó.","The ZIP library did not load."));
      const z=await JSZip.loadAsync(f);
      const entries=Object.values(z.files).filter(e=>!e.dir);
      const main=entries.find(e=>/(^|\/)SKILL\.md$/i.test(e.name)); if(!main) throw new Error(v60L("No encontré un SKILL.md dentro del ZIP.","No SKILL.md found inside the ZIP."));
      draft=v60ParseSkillMd(await main.async("string"), main.name);
      const dir=main.name.replace(/SKILL\.md$/i,"");
      const extra=entries.filter(e=>e!==main&&e.name.startsWith(dir)&&/\.(md|txt|csv|json)$/i.test(e.name)).slice(0,6);
      for(const e of extra){ const t=await e.async("string"); draft.ref=((draft.ref?draft.ref+"\n\n":"")+"--- "+e.name.replace(dir,"")+" ---\n"+t).slice(0,60000); }
      if(extra.length&&!draft.refName) draft.refName=extra.map(e=>e.name.replace(dir,"")).join(", ").slice(0,120);
    }else{
      draft=v60ParseSkillMd(await f.text(), f.name);
    }
    V60.skEdit={...draft,icon:"🧩",id:null,imported:true};
    v60RenderSkillsUI(); const e=$("sk-name"); if(e) e.scrollIntoView({behavior:"smooth",block:"center"});
  }catch(e){ alert(v60L("No pude importar la skill: ","Could not import the skill: ")+(e.message||e)); }
}
function v60SkillNew(){ V60.skEdit={id:null,icon:"🧩",name:"",desc:"",instr:"",ref:"",refName:""}; v60RenderSkillsUI(); setTimeout(()=>{ const e=$("sk-name"); if(e){ e.focus(); e.scrollIntoView({behavior:"smooth",block:"center"}); } },30); }
function v60SkillEdit(id){ const s=v60SkillGet(id); if(!s) return; V60.skEdit={...s}; v60RenderSkillsUI(); setTimeout(()=>{ const e=$("sk-name"); if(e) e.scrollIntoView({behavior:"smooth",block:"center"}); },30); }
function v60SkillCancel(){ V60.skEdit=null; v60RenderSkillsUI(); }
function v60SkillCollect(){ const e=V60.skEdit; if(!e) return; ["name","desc","instr","ref","icon"].forEach(k=>{ const el=$("sk-"+k); if(el) e[k]=el.value; }); }
function v60SkillSave(){
  v60SkillCollect(); const e=V60.skEdit; if(!e) return;
  e.name=(e.name||"").trim(); e.instr=(e.instr||"").trim();
  if(!e.name||!e.instr){ alert(v60L("La skill necesita al menos un nombre e instrucciones.","A skill needs at least a name and instructions.")); return; }
  if(!e.id) e.id="sk_"+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
  if(v60SkillStore(e)){ V60.skEdit=null; v60RenderSkillsUI(); renderAgents(); v60RefreshView(); }
}
function v60SkillRefFile(files){
  const f=files&&files[0]; const inpEl=$("sk-reffile"); if(inpEl) inpEl.value=""; if(!f) return;
  v60SkillCollect(); const note=$("sk-refnote"); if(note) note.textContent="⏳ "+v60L("leyendo","reading")+" "+f.name+"…";
  extractText(f).then(t=>{ V60.skEdit.ref=(t||"").slice(0,60000); V60.skEdit.refName=f.name; v60RenderSkillsUI(); })
    .catch(e=>{ if(note) note.textContent="⚠️ "+(e.message||e); });
}
document.addEventListener("click",e=>{ const c=e.target.closest&&e.target.closest("#a-skills .chk"); if(c) c.classList.toggle("on"); });

function v60RenderSkillsUI(){
  const all=v60SkillsAll();
  const box=$("a-skills");
  if(box){
    const sel=new Set([...box.querySelectorAll(".chk.on")].map(x=>x.dataset.id));
    box.innerHTML=all.map(s=>`<span class="chk ${sel.has(s.id)?"on":""}" data-id="${v60Esc(s.id)}" title="${v60Esc(s.desc)}">${v60Esc(s.icon||"🧩")} ${v60Esc(s.name)}</span>`).join("")
      || `<span class="note" style="margin:0">${v60L("No hay skills en la biblioteca.","No skills in the library.")}</span>`;
  }
  const card=$("sk-card"); if(!card) return;
  const e=V60.skEdit;
  const ed=e?`<div class="sk-ed">
      <b style="font-size:13.5px">${e.id?v60L("✏️ Editar skill","✏️ Edit skill"):e.imported?v60L("⬆ Revisá la skill importada antes de guardarla","⬆ Review the imported skill before saving"):v60L("＋ Nueva skill","＋ New skill")}</b>
      ${e.imported?`<div class="note" style="margin:4px 0 8px">⚠️ ${v60L("Las instrucciones de una skill se inyectan en el prompt del agente: guardá solo skills de fuentes confiables.","A skill's instructions are injected into the agent's prompt: only save skills from trusted sources.")}</div>`:""}
      <div class="sk-row" style="margin-top:10px"><div class="field"><label>${v60L("Ícono","Icon")}</label><input id="sk-icon" maxlength="4" value="${v60Esc(e.icon||"🧩")}"></div>
        <div class="field"><label>${v60L("Nombre","Name")}</label><input id="sk-name" value="${v60Esc(e.name)}" placeholder="${v60L("Ej: Cálculo de radioenlace","e.g. Radio link budget")}"></div></div>
      <div class="field"><label>${v60L("Cuándo usarla (el agente decide con esto si la aplica)","When to use it (the agent decides with this whether to apply it)")}</label><input id="sk-desc" value="${v60Esc(e.desc)}" placeholder="${v60L("Ej: cuando se pida diseñar o verificar un enlace de microondas","e.g. when asked to design or verify a microwave link")}"></div>
      <div class="field"><label>${v60L("Instrucciones (paso a paso, formato de salida, reglas)","Instructions (step by step, output format, rules)")}</label><textarea id="sk-instr" style="min-height:150px;font-family:Consolas,monospace;font-size:12.5px">${v60Esc(e.instr)}</textarea></div>
      <div class="field"><label>${v60L("Referencia opcional (tablas, normas, plantillas, ejemplos)","Optional reference (tables, standards, templates, examples)")}${e.refName?" · 📄 "+v60Esc(e.refName):""}</label><textarea id="sk-ref" style="min-height:70px">${v60Esc(e.ref)}</textarea>
        <input type="file" id="sk-reffile" accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.md,.json" style="display:none" onchange="v60SkillRefFile(this.files)">
        <button class="btn" style="margin-top:6px;padding:5px 12px;font-size:12px" onclick="$('sk-reffile').click()">📎 ${v60L("Cargar desde archivo","Load from file")}</button> <span class="note" id="sk-refnote"></span></div>
      <button class="btn dark" onclick="v60SkillSave()">💾 ${v60L("Guardar skill","Save skill")}</button> <button class="btn" onclick="v60SkillCancel()">${v60L("Cancelar","Cancel")}</button></div>`:"";
  const list=all.map(s=>{ const used=agents.filter(a=>(a.skills||[]).includes(s.id)).length;
    return `<div class="sk-item"><span class="sk-ic">${v60Esc(s.icon||"🧩")}</span><div class="sk-b"><b>${v60Esc(s.name)}</b>
      <div class="sk-meta">${s.builtin?`<span class="tag">${v60L("ejemplo","example")}${s.edited?" · "+v60L("editada","edited"):""}</span>`:`<span class="tag">${v60L("propia","custom")}</span>`}${s.ref?`<span class="tag">📄 ${v60L("con referencia","with reference")}</span>`:""}<span class="tag">🤖 ${used}</span></div>
      <small>${v60Esc(s.desc||"")}</small>
      <div class="sk-act"><button class="btn sm" onclick="v60SkillEdit('${v60Esc(s.id)}')">✏️ ${v60L("Editar","Edit")}</button><button class="btn sm" onclick="v60SkillExport('${v60Esc(s.id)}')">📤 SKILL.md</button><button class="btn sm" onclick="v60SkillDel('${v60Esc(s.id)}')">🗑</button></div></div></div>`; }).join("");
  const hiddenN=v60J("atlas_skills_hidden",[]).length;
  card.innerHTML=`<h4>🧩 ${v60L("Biblioteca de Skills","Skills library")} · ${all.length}</h4>
    <p style="font-size:13px;color:var(--muted);line-height:1.6;margin-bottom:12px">${v60L("Una <b>skill</b> es un procedimiento experto y reutilizable: le enseña al agente <b>cómo</b> hacer una tarea (pasos, fórmulas, formato de salida, reglas). Asignala a uno o varios agentes; el agente la aplica cuando la consulta coincide con su «cuándo usarla». Formato <b>SKILL.md</b> compatible con Agent Skills.","A <b>skill</b> is a reusable expert procedure: it teaches the agent <b>how</b> to do a task (steps, formulas, output format, rules). Assign it to one or more agents; the agent applies it when the request matches its “when to use it”. <b>SKILL.md</b> format, compatible with Agent Skills.")}</p>
    <div style="margin-bottom:14px;display:flex;gap:8px;flex-wrap:wrap"><button class="btn dark" onclick="v60SkillNew()">＋ ${v60L("Nueva skill","New skill")}</button>
      <input type="file" id="sk-imp" accept=".md,.txt,.zip,.skill" style="display:none" onchange="v60SkillImport(this.files)">
      <button class="btn" onclick="$('sk-imp').click()">⬆ ${v60L("Importar SKILL.md / .zip","Import SKILL.md / .zip")}</button>
      ${hiddenN?`<button class="btn" onclick="v60SkillsRestore()">↺ ${v60L("Restaurar ejemplos","Restore examples")} (${hiddenN})</button>`:""}</div>
    ${ed}<div class="sk-lib">${list||`<div class="note">${v60L("La biblioteca está vacía.","The library is empty.")}</div>`}</div>`;
}

/* ---------- integración con Agent Studio ---------- */
const V60_buildAgentSys=buildAgentSys;
buildAgentSys=function(a){
  let s=V60_buildAgentSys(a);
  const sk=v60AgentSkills(a); if(!sk.length) return s;
  let block="\n\n===== SKILLS DEL AGENTE =====\nTenés las siguientes SKILLS (procedimientos expertos). Para cada consulta: revisá el «Cuándo usarla» de cada skill; si una aplica, seguí sus instrucciones al pie de la letra y empezá tu respuesta con una línea «🧩 Skill aplicada: <nombre>». Si ninguna aplica, respondé normalmente sin mencionarlas.\n";
  let budget=14000;
  sk.forEach(k=>{
    let part=`\n--- SKILL: ${k.name} ---\nCuándo usarla: ${k.desc||"(sin descripción)"}\nInstrucciones:\n${k.instr}\n`;
    if(k.ref) part+=`Referencia${k.refName?" ("+k.refName+")":""}:\n${k.ref.slice(0,Math.max(0,Math.min(6000,budget-part.length)))}\n`;
    block+=part.slice(0,Math.max(0,budget)); budget-=part.length;
  });
  const mk="\n\n===== CONOCIMIENTO DEL AGENTE"; const i=s.indexOf(mk);
  return i>=0 ? s.slice(0,i)+block+s.slice(i) : s+block;
};
const V60_createAgent=createAgent;
createAgent=function(){
  const sel=[...document.querySelectorAll("#a-skills .chk.on")].map(x=>x.dataset.id);
  const before=agents[0];
  V60_createAgent.apply(this,arguments);
  const a=agents[0];
  if(a&&a!==before){ a.skills=sel; agentPut(a); document.querySelectorAll("#a-skills .chk.on").forEach(x=>x.classList.remove("on")); renderAgents(); }
};
const V60_agentEdit=agentEdit;
agentEdit=function(ix){
  V60_agentEdit.apply(this,arguments);
  const a=agents[ix]; if(!a) return;
  v60RenderSkillsUI();
  document.querySelectorAll("#a-skills .chk").forEach(c=>c.classList.toggle("on",(a.skills||[]).includes(c.dataset.id)));
};
v60Wrap("renderAgents",()=>{
  const cards=document.querySelectorAll("#a-list .agent-card");
  cards.forEach((card,ix)=>{
    const a=agents[ix]; const sk=v60AgentSkills(a); const tg=card.querySelector(".tags");
    if(tg&&sk.length) tg.insertAdjacentHTML("beforeend",sk.map(s=>`<span class="tag" style="border-color:#c9dcf3;color:#1557a0">${v60Esc(s.icon||"🧩")} ${v60Esc(s.name)}</span>`).join(""));
  });
  renderNav(); v60RenderSkillsKeep(); if(curView==="home"||curView==="control") v60RefreshView();
});
v60Wrap("agentChat",ix=>{
  const a=agents[ix]; const n=v60AgentSkills(a).length;
  if(a&&n) inp.placeholder=v60L(`Agente "${a.name}" activo · 🧩 ${n} skill${n>1?"s":""} — escribí tu mensaje…`,`Agent "${a.name}" active · 🧩 ${n} skill${n>1?"s":""} — type your message…`);
});
agentShare=function(ix){
  const a=agents[ix]; if(!a) return;
  const pack={atlas_agent:true,version:2,name:a.name,type:a.type,goal:a.goal,caps:a.caps||[],tools:a.tools||[],docs:a.docs||[],
    skills:v60AgentSkills(a).map(s=>({id:s.id,icon:s.icon,name:s.name,desc:s.desc,instr:s.instr,ref:s.ref||"",refName:s.refName||""}))};
  const blob=new Blob([JSON.stringify(pack,null,2)],{type:"application/json"});
  const dl=document.createElement("a"); dl.href=URL.createObjectURL(blob);
  dl.download=(a.name||"agente").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")+".atlas-agent.json"; dl.click();
  const log=$("a-log"); if(log) log.textContent="🔗 "+v60L(`Agente "${a.name}" exportado (.json) con ${pack.skills.length} skill(s) y ${pack.docs.length} documento(s).`,`Agent "${a.name}" exported (.json) with ${pack.skills.length} skill(s) and ${pack.docs.length} document(s).`);
};
function v60AgentImport(files){
  const f=files&&files[0]; const el=$("ag-imp"); if(el) el.value=""; if(!f) return;
  f.text().then(t=>{
    const p=JSON.parse(t); if(!p||!p.atlas_agent) throw new Error(v60L("no es un agente de AR.T.L.A.S.","not an AR.T.L.A.S. agent"));
    const ids=[];
    (p.skills||[]).forEach(s=>{ if(!s||!s.name||!s.instr) return; const ex=v60SkillsAll().find(x=>x.id===s.id||x.name===s.name); if(ex){ ids.push(ex.id); return; } const id=s.id||("sk_"+Date.now().toString(36)+Math.random().toString(36).slice(2,5)); if(v60SkillStore({...s,id})) ids.push(id); });
    let name=p.name||"Agente importado"; while(agents.find(x=>x.name===name)) name+=" (2)";
    const a={name,type:p.type||"Investigador",goal:p.goal||"",caps:p.caps||[],tools:(p.tools||[]).filter(t=>["calc","python","web"].includes(t)),docs:(p.docs||[]).map(d=>({name:d.name,text:d.text||""})),skills:ids};
    agents.unshift(a); agentPut(a); renderAgents();
    const log=$("a-log"); if(log) log.textContent="✓ "+v60L(`Agente "${name}" importado con ${ids.length} skill(s).`,`Agent "${name}" imported with ${ids.length} skill(s).`);
  }).catch(e=>alert(v60L("No pude importar el agente: ","Could not import the agent: ")+(e.message||e)));
}
async function v60SeedDemo(){
  const demoAgents=[
    {name:"Investigador Telecom (demo)",type:"Investigador",goal:"Investigar papers y estándares sobre 5G, fibra óptica y machine learning aplicado a redes; comparar resultados y redactar el estado del arte con citas verificables.",caps:["Memoria","Planificación","Navegación Web"],docs:[],skills:["sk_apa7","sk_link"]},
    {name:"Analista de Datos (demo)",type:"Empresarial",goal:"Analizar datasets de negocio o de tráfico de red, detectar patrones y anomalías, y comunicar hallazgos a directivos.",caps:["Memoria","Gráficos","Herramientas"],docs:[],skills:["sk_eda","sk_exec"]},
    {name:"Tutor de Redes (demo)",type:"Universitario",goal:"Acompañar a estudiantes de Ingeniería en Telecomunicaciones: explicar conceptos, resolver ejercicios de subneteo y radioenlaces paso a paso y proponer práctica.",tools:["calc","python"],caps:["Memoria","Planificación"],docs:[],skills:["sk_ipv4","sk_link"]}
  ];
  let n=0;
  for(const a of demoAgents){ if(!agents.find(x=>x.name===a.name)){ agents.push(a); try{ await agentPut(a); }catch(e){} n++; } }
  if(!flows.find(f=>f.name==="Paper → Resumen ejecutivo (demo)")){
    flows.push({name:"Paper → Resumen ejecutivo (demo)",steps:[
      {title:"Investigar",prompt:"Listá los hallazgos, datos y conceptos clave sobre: {{entrada}}",model:"auto"},
      {title:"Analizar",prompt:"Analizá críticamente estos hallazgos: fortalezas, debilidades y brechas.\n\n{{entrada}}",model:"auto"},
      {title:"Resumen ejecutivo",prompt:"Redactá un resumen ejecutivo de una página (conclusión primero, 3-5 puntos clave, recomendación):\n\n{{entrada}}",model:"auto"}]});
    wfSaveLS(); try{ renderFlows(); }catch(e){} n++;
  }
  renderAgents(); v60RefreshView();
  alert(n?v60L("✓ Ejemplos cargados: agentes con skills y un workflow de demostración.","✓ Examples loaded: agents with skills and a demo workflow."):v60L("Los ejemplos ya estaban cargados.","Examples were already loaded."));
}
