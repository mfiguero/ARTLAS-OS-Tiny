
/* =====================================================================
   AR.T.L.A.S. · Módulo HERRAMIENTAS PARA AGENTES
   Herramientas reales que el agente puede usar antes de responder:
     calc   → calculadora exacta (sin eval), con funciones de telecomunicaciones
     python → Python en el navegador (módulo 85)
     web    → lector de páginas (r.jina.ai)
   Protocolo independiente del proveedor: el modelo pide una herramienta con un
   bloque ```tool:calc / ```tool:python / ```tool:web; AR.T.L.A.S. la ejecuta,
   devuelve el resultado y el modelo continúa (máx. 4 pasos).
   ===================================================================== */
const V67T={agentTools:null,agentSys:null};
const V67_TOOLS={
  calc:{ic:"🧮",es:"Calculadora exacta",en:"Exact calculator",dEs:"Cuentas sin errores: dB, logaritmos, unidades.",dEn:"Error-free maths: dB, logarithms, units."},
  python:{ic:"🐍",es:"Python en el navegador",en:"Python in the browser",dEs:"numpy, pandas, matplotlib y scipy, en tu equipo.",dEn:"numpy, pandas, matplotlib and scipy, on your device."},
  web:{ic:"🌐",es:"Lector de páginas web",en:"Web page reader",dEs:"Lee una URL y la usa como fuente.",dEn:"Reads a URL and uses it as a source."}
};
function v67TName(k){ const t=V67_TOOLS[k]; return t?t.ic+" "+v60L(t.es,t.en):k; }

/* ---------- calculadora segura (descenso recursivo, sin eval) ---------- */
const V67_FN={
  log10:Math.log10, log:Math.log10, ln:Math.log, log2:Math.log2, sqrt:Math.sqrt, cbrt:Math.cbrt, exp:Math.exp, abs:Math.abs,
  sin:Math.sin, cos:Math.cos, tan:Math.tan, asin:Math.asin, acos:Math.acos, atan:Math.atan, atan2:Math.atan2,
  sinh:Math.sinh, cosh:Math.cosh, tanh:Math.tanh, floor:Math.floor, ceil:Math.ceil, round:(x,n)=>{ const f=Math.pow(10,n||0); return Math.round(x*f)/f; },
  min:Math.min, max:Math.max, pow:Math.pow, hypot:Math.hypot,
  deg:x=>x*180/Math.PI, rad:x=>x*Math.PI/180,
  fspl:(d_km,f_mhz)=>20*Math.log10(d_km)+20*Math.log10(f_mhz)+32.44,
  dbm2w:x=>Math.pow(10,(x-30)/10), w2dbm:x=>10*Math.log10(x)+30, dbm2mw:x=>Math.pow(10,x/10), mw2dbm:x=>10*Math.log10(x),
  db2lin:x=>Math.pow(10,x/10), lin2db:x=>10*Math.log10(x),
  fresnel:(d1_km,d2_km,f_ghz)=>17.32*Math.sqrt((d1_km*d2_km)/(f_ghz*(d1_km+d2_km)))
};
const V67_CONST={pi:Math.PI,e:Math.E,c:299792458,k:1.380649e-23};
function v67Calc(src){
  const s=String(src||"").replace(/×/g,"*").replace(/÷/g,"/").replace(/−/g,"-").replace(/·/g,"*");
  let i=0, inArgs=0;   // dentro de una función la coma separa argumentos; afuera es separador decimal
  const err=m=>{ throw new Error(m+(i<s.length?` (pos. ${i+1})`:"")); };
  const ws=()=>{ while(i<s.length&&/\s/.test(s[i])) i++; };
  const peek=t=>{ ws(); return s.startsWith(t,i); };
  const eat=t=>{ if(peek(t)){ i+=t.length; return true; } return false; };
  function num(){ ws(); const m=(inArgs?/^(\d+(?:\.\d+)?|\.\d+)(?:[eE][+-]?\d+)?/:/^(\d+(?:[.,]\d+)?|[.,]\d+)(?:[eE][+-]?\d+)?/).exec(s.slice(i)); if(!m) return null; i+=m[0].length; return parseFloat(m[0].replace(",",".")); }
  function primary(){
    ws();
    if(eat("(")){ const v=expr(); if(!eat(")")) err("Falta «)»"); return v; }
    const n=num(); if(n!==null) return n;
    const m=/^[a-zA-Z_][a-zA-Z_0-9]*/.exec(s.slice(i));
    if(!m) err("Expresión inválida");
    i+=m[0].length; const id=m[0];
    if(peek("(")){ eat("("); inArgs++; const args=[]; if(!peek(")")){ do{ args.push(expr()); }while(eat(";")||eat(",")); } if(!eat(")")) err("Falta «)»"); inArgs--;
      const f=V67_FN[id.toLowerCase()]; if(!f) err("Función desconocida: "+id); return f.apply(null,args); }
    if(id in V67_CONST) return V67_CONST[id];
    if(id.toLowerCase() in V67_CONST) return V67_CONST[id.toLowerCase()];
    err("Nombre desconocido: "+id);
  }
  function power(){ const b=primary(); if(eat("**")||eat("^")){ return Math.pow(b,unary()); } return b; }
  function unary(){ if(eat("-")) return -unary(); if(eat("+")) return unary(); return power(); }
  function term(){ let v=unary(); for(;;){ if(peek("**")) break; if(eat("*")) v*=unary(); else if(eat("/")) v/=unary(); else if(eat("%")) v%=unary(); else break; } return v; }
  function expr(){ let v=term(); for(;;){ if(eat("+")) v+=term(); else if(eat("-")) v-=term(); else break; } return v; }
  const v=expr(); ws(); if(i<s.length) err("Sobra texto");
  if(typeof v!=="number"||!isFinite(v)) throw new Error("Resultado no finito");
  return v;
}
function v67CalcFmt(v){ const a=Math.abs(v); if(a!==0&&(a>=1e9||a<1e-4)) return v.toExponential(6); return String(Math.round(v*1e10)/1e10); }

/* ---------- protocolo de herramientas ---------- */
function v67ToolsPrompt(tools){
  const en=atlasLang==="en";
  const lines=[];
  if(tools.includes("calc")) lines.push(en?"- tool:calc → exact calculator. Input: ONE expression, e.g. 20*log10(25)+20*log10(5800)+32.44. Functions: log10, ln, log2, sqrt, exp, sin/cos/tan (radians), deg, rad, round(x,n), min, max, fspl(d_km,f_mhz), fresnel(d1_km,d2_km,f_ghz), dbm2w, w2dbm, db2lin, lin2db. Constants: pi, e, c, k."
    :"- tool:calc → calculadora exacta. Entrada: UNA expresión, p. ej. 20*log10(25)+20*log10(5800)+32.44. Funciones: log10, ln, log2, sqrt, exp, sin/cos/tan (radianes), deg, rad, round(x,n), min, max, fspl(d_km,f_mhz), fresnel(d1_km,d2_km,f_ghz), dbm2w, w2dbm, db2lin, lin2db. Constantes: pi, e, c, k.");
  if(tools.includes("python")) lines.push(en?"- tool:python → runs Python 3 in the browser (numpy, pandas, scipy, scikit-learn, matplotlib available; NOT tensorflow, keras or torch). Returns what you print() and the charts (plt.show())."
    :"- tool:python → ejecuta Python 3 en el navegador (numpy, pandas, scipy, scikit-learn, matplotlib disponibles; NO tensorflow, keras ni torch). Devuelve lo que imprimas con print() y los gráficos (plt.show()).");
  if(tools.includes("web")) lines.push(en?"- tool:web → reads the content of ONE URL (input: the URL)."
    :"- tool:web → lee el contenido de UNA URL (entrada: la URL).");
  return (en
    ? "===== AVAILABLE TOOLS =====\n"+lines.join("\n")+"\nTo use a tool, reply ONLY with a fenced block whose language is the tool name, for example:\n```tool:calc\n20*log10(25)\n```\nThen wait for the result and continue. Use at most 4 tools. For ANY numeric calculation use tool:calc or tool:python instead of computing mentally. When you have everything, answer the user normally (no tool block)."
    : "===== HERRAMIENTAS DISPONIBLES =====\n"+lines.join("\n")+"\nPara usar una herramienta respondé SOLO con un bloque de código cuyo lenguaje sea el nombre de la herramienta, por ejemplo:\n```tool:calc\n20*log10(25)\n```\nEsperá el resultado y continuá. Usá como máximo 4 herramientas. Para CUALQUIER cálculo numérico usá tool:calc o tool:python en lugar de calcular de memoria. Cuando tengas todo, respondé al usuario normalmente (sin bloque de herramienta).");
}
function v67ParseTool(reply,tools){
  const m=/```\s*(?:tool|herramienta)\s*[:\-_ ]\s*(calc|python|web)[^\n]*\n([\s\S]*?)(?:```|$)/i.exec(String(reply||""));
  if(!m) return null;
  const tool=m[1].toLowerCase(); if(!tools.includes(tool)) return null;
  return {tool,input:m[2].replace(/\s+$/,"")};
}
function v67StripTools(t){ return String(t||"").replace(/```\s*(?:tool|herramienta)\s*[:\-_ ]\s*(calc|python|web)[^\n]*\n[\s\S]*?(```|$)/gi,"").trim(); }
async function v67ExecTool(call){
  const t0=performance.now();
  try{
    if(call.tool==="calc"){
      const expr=call.input.split("\n").map(x=>x.trim()).filter(Boolean)[0]||"";
      const v=v67Calc(expr);
      const sh=Math.abs(v)>=1e6||(v!==0&&Math.abs(v)<1e-3)?v.toExponential(3):(Math.round(v*1000)/1000).toLocaleString(atlasLang==="en"?"en-US":"es-AR",{maximumFractionDigits:3});
      return {ok:true,text:expr+" = "+v67CalcFmt(v),short:"`"+expr.slice(0,90)+"` = **"+sh+"**",ms:performance.now()-t0};
    }
    if(call.tool==="python"){
      const r=await v67PyRun(call.input);
      const lines=call.input.split("\n").filter(x=>x.trim()).length;
      const txt=[r.out&&r.out.trim(), r.res&&("→ "+r.res), r.err&&("ERROR: "+r.err), (r.figs&&r.figs.length)?"["+r.figs.length+" "+v60L("gráfico(s) generado(s)","chart(s) generated")+"]":""].filter(Boolean).join("\n")||v60L("(sin salida: usá print())","(no output: use print())");
      return {ok:r.ok,text:txt,figs:r.figs||[],short:lines+" "+v60L("líneas","lines")+(r.figs&&r.figs.length?" · "+r.figs.length+" "+v60L("gráfico(s)","chart(s)"):"")+(r.ok?"":" · ⚠ "+v60L("error","error")),ms:r.ms!=null?r.ms:performance.now()-t0,code:call.input};
    }
    if(call.tool==="web"){
      const url=(call.input.match(/https?:\/\/\S+/)||[])[0];
      if(!url) throw new Error(v60L("Falta una URL válida","A valid URL is missing"));
      const t=await v63Read(url,6000);
      if(!t) throw new Error(v60L("No se pudo leer la página","Could not read the page"));
      let host=url; try{ host=new URL(url).hostname; }catch(e){}
      return {ok:true,text:t,short:v60L("leyó ","read ")+host+" ("+t.length+" "+v60L("caracteres","characters")+")",ms:performance.now()-t0,url};
    }
  }catch(e){ return {ok:false,text:"ERROR: "+((e&&e.message)||e),short:"⚠ "+((e&&e.message)||e),ms:performance.now()-t0}; }
  return {ok:false,text:"ERROR",short:"⚠",ms:0};
}
function v67TraceMd(trace){
  if(!trace.length) return "";
  return "> 🛠️ **"+v60L("Pasos del agente","Agent steps")+"**\n"+trace.map((s,i)=>`> ${i+1}. ${V67_TOOLS[s.tool].ic} **${v60L(V67_TOOLS[s.tool].es,V67_TOOLS[s.tool].en)}** · ${s.short} · ${v67Fmt(s.ms||0)}`).join("\n")+"\n\n";
}

/* ---------- el agente con herramientas responde en un ciclo ---------- */
const V67_askOne=askOne;
askOne=async function(c,history,baseSys,imgs){
  let tools=c&&c.tools;
  if(!tools&&c&&c.sys&&V67T.agentTools&&c.sys===V67T.agentSys) tools=V67T.agentTools;
  tools=(tools||[]).filter(t=>V67_TOOLS[t]);
  if(!tools.length) return V67_askOne.apply(this,arguments);
  c.tools=tools;
  const m=MODELS[curModel];
  let pk=m.prov; if(!connected(pk)||pk==="basic") pk=["anthropic","openai","gemini","groq","deepseek","hf","other","zai","kimi","basic"].find(connected)||pk;
  if(!connected(pk)) return V67_askOne.apply(this,arguments);
  const via=`${m.name} → ${PROVIDERS[pk].label} · ${provModel(pk)} · 🛠️ ${tools.map(t=>V67_TOOLS[t].ic).join("")}`;
  const typing=addRow("assistant","",via); typing.querySelector(".content").innerHTML='<span class="typing"></span>'; scrollDown();
  const vEl=typing.querySelector(".via");
  const sys=[baseSys,m.sys,v67ToolsPrompt(tools)].filter(Boolean).join("\n\n");
  const hist=history.map(x=>({...x}));
  const trace=[], figs=[]; let final=null, reply=null;
  for(let step=0;step<5;step++){
    try{ reply=await callProvider(pk,cfg[pk]||{},hist,sys,step===0?imgs:undefined); }
    catch(e){
      if(step===0){ typing.remove(); return V67_askOne.apply(this,arguments); }   // el modelo falló: flujo normal con fallback
      final=v60L("⚠️ El modelo dejó de responder durante el uso de herramientas: ","⚠️ The model stopped responding while using tools: ")+((e&&e.message)||e); break;
    }
    const call=step<4?v67ParseTool(reply,tools):null;
    if(!call){ final=reply; break; }
    if(vEl) vEl.textContent=via+" · "+V67_TOOLS[call.tool].ic+" "+v60L("usando ","using ")+v60L(V67_TOOLS[call.tool].es,V67_TOOLS[call.tool].en)+"…";
    const r=await v67ExecTool(call);
    trace.push({tool:call.tool,short:r.short,ms:r.ms,ok:r.ok});
    if(r.figs) figs.push(...r.figs);
    typing.querySelector(".content").innerHTML=md(v67TraceMd(trace))+'<span class="typing"></span>'; scrollDown();
    hist.push({role:"assistant",content:String(reply).slice(0,6000)});
    hist.push({role:"user",content:(atlasLang==="en"?"RESULT of tool:":"RESULTADO de tool:")+call.tool+(r.ok?"":" (ERROR)")+"\n"+String(r.text).slice(0,7000)+"\n\n"+v60L("Continuá. Si ya tenés todo, respondé al usuario sin usar herramientas.","Continue. If you have everything, answer the user without using tools.")});
  }
  if(final==null){
    hist.push({role:"user",content:v60L("Respondé ahora al usuario con lo que obtuviste, sin usar herramientas.","Answer the user now with what you obtained, without using tools.")});
    try{ final=await callProvider(pk,cfg[pk]||{},hist,sys); }catch(e){ final="⚠️ "+((e&&e.message)||e); }
  }
  const content=v67TraceMd(trace)+(v67StripTools(final)||"…");
  const meta=via;
  const msg={role:"assistant",content,meta};
  const keep=figs.filter(b=>b.length<260000).slice(0,2); if(keep.length) msg.figs=keep;
  typing.querySelector(".content").innerHTML=md(content);
  if(vEl) vEl.textContent=meta;
  v67FigsInto(typing,figs.slice(0,4));
  c.msgs.push(msg); save(); scrollDown();
};
function v67FigsInto(row,figs){
  if(!row||!figs||!figs.length||row.querySelector(".v67-figs")) return;
  const d=document.createElement("div"); d.className="v67-figs";
  d.innerHTML=figs.map(b=>`<img class="v67-fig" alt="${v60L("Gráfico generado por el agente","Chart generated by the agent")}" src="data:image/png;base64,${b}">`).join("");
  const ct=row.querySelector(".content"); if(ct) ct.after(d);
}
/* gráficos guardados en el historial */
v60Wrap("renderMsgs",()=>{ try{
  const c=cur(); if(!c) return; const real=v66RealRows(); if(real.length!==c.msgs.length) return;
  real.forEach((r,i)=>{ if(c.msgs[i].figs) v67FigsInto(r,c.msgs[i].figs); });
}catch(e){} });
/* «Copiar» no incluye los pasos del agente */
const V67_copy=v66Copy;
v66Copy=async function(b){
  const row=b.closest(".row"), x=v66MsgOf(row);
  if(x&&x.m&&/^> 🛠️/.test(x.m.content||"")){
    const t=String(x.m.content).replace(/^> 🛠️[\s\S]*?\n\n/,"").replace(/\n\n🔎 \*\*(Fuentes|Sources)\*\*[\s\S]*$/,"").trim();
    v66Flash(b,await v66Clip(t)); return;
  }
  return V67_copy.apply(this,arguments);
};

/* ---------- Agent Studio: elegir herramientas ---------- */
function v67ToolsField(){
  const caps=$("a-caps"); if(!caps||$("a-tools")) return;
  const f=caps.closest(".field"); if(!f) return;
  f.insertAdjacentHTML("afterend",`<div class="field"><label>🛠️ ${v60L("Herramientas reales (el agente las usa antes de responder y muestra cada paso)","Real tools (the agent uses them before answering and shows each step)")}</label>
    <div class="checks" id="a-tools">${Object.keys(V67_TOOLS).map(k=>`<span class="chk" data-tool="${k}" title="${v60Esc(v60L(V67_TOOLS[k].dEs,V67_TOOLS[k].dEn))}">${V67_TOOLS[k].ic} ${v60Esc(v60L(V67_TOOLS[k].es,V67_TOOLS[k].en))}</span>`).join("")}</div></div>`);
}
document.addEventListener("click",e=>{ const t=e.target.closest&&e.target.closest("#a-tools .chk"); if(t) t.classList.toggle("on"); });
const V67_createAgent=createAgent;
createAgent=function(){
  const sel=[...document.querySelectorAll("#a-tools .chk.on")].map(x=>x.dataset.tool);
  const before=agents[0];
  V67_createAgent.apply(this,arguments);
  const a=agents[0];
  if(a&&a!==before){ a.tools=sel; agentPut(a); document.querySelectorAll("#a-tools .chk.on").forEach(x=>x.classList.remove("on")); renderAgents(); }
};
const V67_agentEdit=agentEdit;
agentEdit=function(ix){
  V67_agentEdit.apply(this,arguments);
  v67ToolsField();
  const a=agents[ix]; if(!a) return;
  document.querySelectorAll("#a-tools .chk").forEach(c=>c.classList.toggle("on",(a.tools||[]).includes(c.dataset.tool)));
};
v60Wrap("renderAgents",()=>{
  v67ToolsField();
  document.querySelectorAll("#a-list .agent-card").forEach((card,ix)=>{
    const a=agents[ix], tg=card.querySelector(".tags");
    if(a&&tg&&a.tools&&a.tools.length&&!tg.querySelector(".v67-ttag")) tg.insertAdjacentHTML("beforeend",a.tools.filter(t=>V67_TOOLS[t]).map(t=>`<span class="tag v67-ttag" style="border-color:#bfe6d8;color:#0c7a5e">${v60Esc(v67TName(t))}</span>`).join(""));
  });
});
/* el chat con un agente recuerda sus herramientas */
const V67_agentChat=agentChat;
agentChat=function(ix){
  V67_agentChat.apply(this,arguments);
  const a=agents[ix];
  V67T.agentTools=(a&&a.tools&&a.tools.length)?a.tools.slice():null;
  V67T.agentSys=V67T.agentTools?customSys:null;
};
const V67_newChat=newChat;
newChat=function(){ V67T.agentTools=null; V67T.agentSys=null; return V67_newChat.apply(this,arguments); };
