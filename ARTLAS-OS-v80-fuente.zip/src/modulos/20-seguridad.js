
/* ==================== SEGURIDAD DE CREDENCIALES ====================
   Modos:  local   = comportamiento v57 (localStorage en texto plano)
           session = keys solo en sessionStorage (se borran al cerrar la pestaña)
           vault   = keys cifradas con AES-256-GCM; clave derivada de una frase
                     de acceso con PBKDF2-SHA256 (250.000 iteraciones). La frase
                     nunca se guarda: sin ella las keys no se pueden descifrar.
   En todos los modos, atlas_cfg queda sin keys salvo en "local".              */
function v60KeyMode(){ const m=v60LS("atlas_keymode","local"); return (m==="session"||m==="vault")?m:"local"; }
function v60HasCrypto(){ try{ return !!(window.crypto&&crypto.subtle&&crypto.getRandomValues); }catch(e){ return false; } }
function v60SplitKeys(obj){
  const clean=JSON.parse(JSON.stringify(obj||{})), secrets={};
  Object.keys(clean).forEach(pk=>{ const c=clean[pk]; if(c&&typeof c==="object"&&!Array.isArray(c)&&c.key){ secrets[pk]=c.key; delete c.key; } });
  return {clean,secrets};
}
function v60MergeKeys(secrets){ Object.keys(secrets||{}).forEach(pk=>{ if(!secrets[pk]) return; cfg[pk]=cfg[pk]||{}; cfg[pk].key=secrets[pk]; }); }
function v60B64(u8){ let s=""; u8.forEach(b=>s+=String.fromCharCode(b)); return btoa(s); }
function v60UnB64(b){ const s=atob(b); const u=new Uint8Array(s.length); for(let i=0;i<s.length;i++) u[i]=s.charCodeAt(i); return u; }
async function v60DeriveKey(pass,salt){
  const base=await crypto.subtle.importKey("raw",new TextEncoder().encode(pass),"PBKDF2",false,["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2",salt,iterations:250000,hash:"SHA-256"},base,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]);
}
function v60VaultRec(){ return v60J("atlas_vault",null); }
function v60VaultLocked(){ return v60KeyMode()==="vault" && !V60.vaultKey; }
function v60VaultWrite(secrets){
  const key=V60.vaultKey, salt=V60.vaultSalt; if(!key||!salt) return;
  const data=JSON.stringify(secrets||{});
  V60.vaultQ=V60.vaultQ.then(async()=>{
    const iv=crypto.getRandomValues(new Uint8Array(12));
    const ct=await crypto.subtle.encrypt({name:"AES-GCM",iv},key,new TextEncoder().encode(data));
    v60LSset("atlas_vault",JSON.stringify({v:1,alg:"AES-256-GCM",kdf:"PBKDF2-SHA256",it:250000,salt:v60B64(salt),iv:v60B64(iv),ct:v60B64(new Uint8Array(ct)),updated:Date.now()}));
  }).catch(e=>console.error("vault write",e));
}
async function v60VaultDecrypt(pass){
  const rec=v60VaultRec(); if(!rec) throw new Error("no vault");
  const salt=v60UnB64(rec.salt), key=await v60DeriveKey(pass,salt);
  const pt=await crypto.subtle.decrypt({name:"AES-GCM",iv:v60UnB64(rec.iv)},key,v60UnB64(rec.ct));
  return {key,salt,secrets:JSON.parse(new TextDecoder().decode(pt))};
}

/* save(): igual que v57, pero separa las keys según el modo elegido */
const V60_save=save;
save=function(){
  try{ if(MODELS[curModel]&&connected(MODELS[curModel].prov)&&MODELS[curModel].prov!=="basic") v60LSset("atlas_model_v60",curModel); }catch(e){}
  const mode=v60KeyMode();
  if(mode==="local") return V60_save();
  localStorage.setItem("atlas_chats",JSON.stringify(chats));
  localStorage.setItem("atlas_model",curModel);
  const {clean,secrets}=v60SplitKeys(cfg);
  localStorage.setItem("atlas_cfg",JSON.stringify(clean));
  if(mode==="session") v60SSset("atlas_keys_s",JSON.stringify(secrets));
  else if(mode==="vault" && V60.vaultKey) v60VaultWrite(secrets);
};

function v60RestoreModel(){
  const pref=v60LS("atlas_model_v60","");
  if(pref&&MODELS[pref]&&connected(MODELS[pref].prov)&&v60Strategy()==="manual") curModel=pref;
  else if(!connected(MODELS[curModel].prov)){ const p=["anthropic","openai","gemini","groq","hf","other"].find(connected); curModel=p?levelOf(p):"free"; }
}
function v60AfterKeysChanged(){ try{ v60RestoreModel(); save(); renderMenu(); renderRoute(); if(curView==="arch") renderArch(); v60SecBar(); v60RefreshView(); }catch(e){ console.error(e); } }

/* ---------- diálogo de bóveda (crear / desbloquear) ---------- */
function v60VaultDom(){
  if($("vault-overlay")) return;
  const d=document.createElement("div"); d.className="overlay2"; d.id="vault-overlay";
  d.innerHTML=`<div id="vault-modal"><h3 id="vm-title"></h3><p class="sub" id="vm-sub"></p>
    <div class="field" id="vm-f1"><label id="vm-l1"></label><input type="password" id="vm-p1" autocomplete="off"></div>
    <div class="field" id="vm-f2"><label id="vm-l2"></label><input type="password" id="vm-p2" autocomplete="off"></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn dark" id="vm-ok" onclick="v60VmOk()"></button><button class="btn" id="vm-cancel" onclick="v60VmClose(false)"></button></div>
    <div class="note" id="vm-msg"></div>
    <div class="note" id="vm-forgot" style="display:none"><a href="#" onclick="event.preventDefault();v60VaultReset()"></a></div></div>`;
  document.body.appendChild(d);
  ["vm-p1","vm-p2"].forEach(id=>$(id).addEventListener("keydown",e=>{ if(e.key==="Enter") v60VmOk(); }));
}
function v60VaultDialog(mode){
  v60VaultDom(); V60.vmMode=mode;
  const create=mode==="create";
  $("vm-title").textContent=create?v60L("🔐 Crear bóveda cifrada","🔐 Create encrypted vault"):v60L("🔐 Desbloquear bóveda","🔐 Unlock vault");
  $("vm-sub").textContent=create
    ?v60L("Tus API keys se cifrarán con AES-256-GCM usando una clave derivada de esta frase (PBKDF2, 250.000 iteraciones). La frase no se guarda en ningún lado: si la olvidás, tendrás que volver a cargar tus keys.","Your API keys will be encrypted with AES-256-GCM using a key derived from this passphrase (PBKDF2, 250,000 iterations). The passphrase is never stored: if you forget it, you will need to re-enter your keys.")
    :v60L("Tus API keys están cifradas en este navegador. Ingresá tu frase de acceso para usarlas en esta sesión.","Your API keys are encrypted in this browser. Enter your passphrase to use them in this session.");
  $("vm-l1").textContent=create?v60L("Frase de acceso (mínimo 8 caracteres)","Passphrase (min. 8 characters)"):v60L("Frase de acceso","Passphrase");
  $("vm-l2").textContent=v60L("Repetí la frase","Repeat passphrase");
  $("vm-f2").style.display=create?"block":"none";
  $("vm-ok").textContent=create?v60L("Crear y cifrar","Create & encrypt"):v60L("Desbloquear","Unlock");
  $("vm-cancel").textContent=create?v60L("Cancelar","Cancel"):v60L("Seguir sin keys","Continue without keys");
  $("vm-forgot").style.display=create?"none":"block";
  $("vm-forgot").querySelector("a").textContent=v60L("Olvidé mi frase — reiniciar la bóveda (se borran las keys guardadas)","I forgot my passphrase — reset the vault (stored keys are deleted)");
  $("vm-p1").value=""; $("vm-p2").value=""; $("vm-msg").textContent=""; $("vm-msg").style.color="";
  $("vault-overlay").classList.add("open"); setTimeout(()=>$("vm-p1").focus(),50);
  return new Promise(res=>{ V60.vmResolve=res; });
}
function v60VmClose(ok){ const o=$("vault-overlay"); if(o) o.classList.remove("open"); const r=V60.vmResolve; V60.vmResolve=null; if(r) r(!!ok); }
async function v60VmOk(){
  const p1=$("vm-p1").value, p2=$("vm-p2").value, msg=$("vm-msg");
  const err=t=>{ msg.textContent=t; msg.style.color="var(--red)"; };
  if(!v60HasCrypto()){ err(v60L("Este navegador no ofrece Web Crypto (se requiere HTTPS o un navegador actualizado).","This browser does not provide Web Crypto (HTTPS or an up-to-date browser is required).")); return; }
  if(V60.vmMode==="create"){
    if(p1.length<8){ err(v60L("La frase debe tener al menos 8 caracteres.","The passphrase must be at least 8 characters.")); return; }
    if(p1!==p2){ err(v60L("Las frases no coinciden.","Passphrases do not match.")); return; }
    msg.style.color="var(--muted)"; msg.textContent=v60L("Derivando clave…","Deriving key…");
    const salt=crypto.getRandomValues(new Uint8Array(16));
    V60.vaultKey=await v60DeriveKey(p1,salt); V60.vaultSalt=salt;
    v60VmClose(true); return;
  }
  msg.style.color="var(--muted)"; msg.textContent=v60L("Verificando…","Verifying…");
  try{
    const r=await v60VaultDecrypt(p1);
    const mem=v60SplitKeys(cfg).secrets;            // keys cargadas mientras estaba bloqueada
    V60.vaultKey=r.key; V60.vaultSalt=r.salt;
    v60MergeKeys(r.secrets); v60MergeKeys(mem);
    v60VmClose(true); v60AfterKeysChanged();
  }catch(e){ err(v60L("Frase incorrecta.","Wrong passphrase.")); }
}
async function v60VaultUnlock(){ if(!v60VaultRec()) return false; return v60VaultDialog("unlock"); }
function v60VaultLock(){
  if(v60KeyMode()!=="vault") return;
  V60.vaultKey=null;
  Object.keys(cfg).forEach(pk=>{ const c=cfg[pk]; if(c&&typeof c==="object"&&!Array.isArray(c)) delete c.key; });
  v60AfterKeysChanged();
}
async function v60VaultChangePass(){
  if(v60VaultLocked()){ const ok=await v60VaultUnlock(); if(!ok) return; }
  const ok=await v60VaultDialog("create"); if(ok){ save(); v60SecBar(); v60RefreshView(); alert(v60L("✓ Frase de acceso actualizada.","✓ Passphrase updated.")); }
}
function v60VaultReset(){
  if(!confirm(v60L("¿Reiniciar la bóveda? Se borrarán las API keys cifradas de este navegador y volverás al modo estándar.","Reset the vault? The encrypted API keys in this browser will be deleted and you will return to standard mode."))) return;
  localStorage.removeItem("atlas_vault"); V60.vaultKey=null; V60.vaultSalt=null; v60LSset("atlas_keymode","local");
  v60VmClose(false); v60AfterKeysChanged();
}
async function v60SetKeyMode(t){
  const cur=v60KeyMode(); if(t===cur) return;
  if(cur==="vault" && !V60.vaultKey && v60VaultRec()){
    alert(v60L("Primero desbloqueá la bóveda para poder migrar tus keys.","Unlock the vault first so your keys can be migrated."));
    const ok=await v60VaultUnlock(); if(!ok) return;
  }
  if(t==="vault"){
    if(!v60HasCrypto()){ alert(v60L("Este navegador no ofrece Web Crypto: la bóveda requiere HTTPS (o localhost) y un navegador actualizado.","This browser does not provide Web Crypto: the vault requires HTTPS (or localhost) and an up-to-date browser.")); return; }
    const ok=await v60VaultDialog("create"); if(!ok) return;
  }
  v60LSset("atlas_keymode",t);
  if(t!=="vault"){ localStorage.removeItem("atlas_vault"); V60.vaultKey=null; V60.vaultSalt=null; }
  if(t!=="session") v60SSset("atlas_keys_s",null);
  save(); v60SecBar(); v60RefreshView();
}
function v60ToggleCloudKeys(){ v60LSset("atlas_cloudkeys",v60CloudKeys()?"0":"1"); pushCloud(); v60SecBar(); v60RefreshView(); }

const V60_KEYMODES={
  local:  {ic:"💾", lvl:"l1", n:["Estándar","Standard"], tag:["BÁSICO","BASIC"],
           d:["Las keys quedan en este navegador (localStorage) en texto plano. Cómodo en un equipo personal.","Keys stay in this browser (localStorage) in plain text. Convenient on a personal computer."]},
  session:{ic:"⏱️", lvl:"l2", n:["Solo esta sesión","This session only"], tag:["MEDIO","MEDIUM"],
           d:["Las keys viven solo en esta pestaña (sessionStorage) y se borran al cerrarla. Ideal para equipos compartidos.","Keys live only in this tab (sessionStorage) and are erased when it closes. Ideal for shared computers."]},
  vault:  {ic:"🔐", lvl:"l3", n:["Bóveda cifrada","Encrypted vault"], tag:["ALTO","HIGH"],
           d:["Keys cifradas con AES-256-GCM + frase de acceso (PBKDF2 250k). Persisten, pero solo se descifran con tu frase.","Keys encrypted with AES-256-GCM + passphrase (PBKDF2 250k). They persist, but can only be decrypted with your passphrase."]}
};
function v60KM(k,f){ const v=V60_KEYMODES[k][f]; return Array.isArray(v)?v60L(v[0],v[1]):v; }
function v60SecStatus(){
  const m=v60KeyMode();
  if(m==="vault") return V60.vaultKey?v60L("🔓 Bóveda desbloqueada en esta sesión","🔓 Vault unlocked for this session"):v60L("🔒 Bóveda bloqueada: los modelos con key no están disponibles hasta desbloquearla","🔒 Vault locked: key-based models are unavailable until you unlock it");
  if(m==="session") return v60L("⏱️ Las keys se borran al cerrar esta pestaña","⏱️ Keys are erased when this tab closes");
  return v60L("💾 Keys guardadas en este navegador sin cifrar","💾 Keys stored unencrypted in this browser");
}
function v60SecurityHtml(){
  const m=v60KeyMode();
  let h=`<div class="sec-modes">`+Object.keys(V60_KEYMODES).map(k=>`<button class="sec-mode ${k===m?"sel":""}" onclick="v60SetKeyMode('${k}')"><b>${V60_KEYMODES[k].ic} ${v60KM(k,"n")}</b><small>${v60KM(k,"d")}</small><span class="lvl ${V60_KEYMODES[k].lvl}">${v60L("PROTECCIÓN","PROTECTION")} ${v60KM(k,"tag")}</span></button>`).join("")+`</div>`;
  h+=`<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:12px;font-size:13px"><b>${v60SecStatus()}</b>`;
  if(m==="vault"){
    h+= V60.vaultKey
      ? `<button class="btn" style="padding:5px 12px;font-size:12px" onclick="v60VaultLock()">🔒 ${v60L("Bloquear ahora","Lock now")}</button><button class="btn" style="padding:5px 12px;font-size:12px" onclick="v60VaultChangePass()">🔑 ${v60L("Cambiar frase","Change passphrase")}</button>`
      : `<button class="btn dark" style="padding:5px 12px;font-size:12px" onclick="v60VaultUnlock()">🔓 ${v60L("Desbloquear","Unlock")}</button>`;
  }
  h+=`</div>`;
  h+=`<div style="margin-top:14px;display:flex;flex-direction:column;gap:6px"><span class="switch ${v60CloudKeys()?"on":""}" onclick="v60ToggleCloudKeys()"><i></i>${v60L("Sincronizar API keys con mi cuenta en la nube (Supabase, protegido por RLS)","Sync API keys with my cloud account (Supabase, protected by RLS)")}</span>
      <span class="note" style="margin-top:0">${v60L("Si lo desactivás, solo se sincronizan preferencias (modelo, ruteo, estrategia); las keys quedan únicamente en este dispositivo.","If disabled, only preferences are synced (model, routing, strategy); keys stay only on this device.")}</span></div>`;
  h+=`<div class="note">${v60L("Hoja de ruta empresarial: gestión de secretos del lado servidor (el proxy inyecta las keys y el navegador nunca las ve), roles y permisos por organización, límites de uso, auditoría y protección contra prompt injection.","Enterprise roadmap: server-side secret management (the proxy injects keys and the browser never sees them), organisation roles and permissions, usage limits, audit logging and prompt-injection protection.")}</div>`;
  return h;
}
function v60SecBar(){
  const el=$("sec-bar"); if(!el) return;
  const m=v60KeyMode();
  el.innerHTML=`<span style="font-size:20px">${V60_KEYMODES[m].ic}</span><span class="t"><b>${v60L("Almacenamiento de keys","Key storage")}: ${v60KM(m,"n")}</b><br>${v60SecStatus()}${v60VaultLocked()?"<br>"+v60L("Las keys que cargues ahora quedan solo en memoria hasta que desbloquees la bóveda.","Keys entered now stay in memory only until you unlock the vault."):""}</span>`+
    (v60VaultLocked()?`<button class="btn dark" style="padding:6px 12px;font-size:12px" onclick="v60VaultUnlock()">🔓 ${v60L("Desbloquear","Unlock")}</button>`:"")+
    `<button class="btn" style="padding:6px 12px;font-size:12px" onclick="closeSettings();go('control');setTimeout(()=>{const s=$('v60-sec');if(s)s.scrollIntoView({behavior:'smooth'});},80)">${v60L("Cambiar modo","Change mode")}</button>`;
}
const V60_openSettings=openSettings;
openSettings=function(){ V60_openSettings.apply(this,arguments); try{ v60SecBar(); }catch(e){} };
const V60_saveSettings=saveSettings;
saveSettings=function(){
  V60_saveSettings.apply(this,arguments);
  try{
    if(v60VaultLocked() && Object.keys(v60SplitKeys(cfg).secrets).length){
      if(confirm(v60L("La bóveda está bloqueada: estas keys quedarán solo en memoria. ¿Desbloquear ahora para guardarlas cifradas?","The vault is locked: these keys will stay in memory only. Unlock now to store them encrypted?"))) v60VaultUnlock();
    }
    v60RefreshView();
  }catch(e){}
};
