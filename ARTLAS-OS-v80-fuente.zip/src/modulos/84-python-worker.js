/* =====================================================================
   AR.T.L.A.S. · Python en el navegador — código del Web Worker
   La compilación también lo publica como python-worker.js (mismo sitio).
   ===================================================================== */
const V67_PYO="https://cdn.jsdelivr.net/pyodide/v314.0.7/full/";
const V67_PRELUDE=[
"import sys, io, base64, time",
"_artlas_figs=[]",
"def _artlas_show(*a, **k):",
"    import matplotlib.pyplot as plt",
"    for n in plt.get_fignums():",
"        f=plt.figure(n); b=io.BytesIO(); f.savefig(b, format='png', dpi=90, bbox_inches='tight')",
"        _artlas_figs.append(base64.b64encode(b.getvalue()).decode())",
"    plt.close('all')",
"def _artlas_take():",
"    if 'matplotlib.pyplot' in sys.modules: _artlas_show()",
"    r=list(_artlas_figs); _artlas_figs.clear(); return r",
"class TiempoExcedido(BaseException): pass",
"def _artlas_guard(limit):",
"    t0=time.monotonic(); n=[0]",
"    def tr(frame, event, arg):",
"        n[0]+=1",
"        if n[0] % 512 == 0 and time.monotonic()-t0>limit:",
"            raise TiempoExcedido('Tiempo máximo excedido (%d s)' % limit)",
"        return tr",
"    sys.settrace(tr)",
"class _ArtlasExit:",
"    def __init__(self, c): self.code = c",
"async def _artlas_exec(src):",
"    from pyodide.code import eval_code_async",
"    try:",
"        return await eval_code_async(src, globals())",
"    except SystemExit as e:",
"        return _ArtlasExit(e.code)"].join("\n");
function v67WorkerSrc(kind){
  // kind: "module" (Worker tipo módulo) · "classic" (Worker clásico) · "iframe" (iframe aislado: modo compatible para file://)
  const load=kind==="classic"
    ? `importScripts(${JSON.stringify(V67_PYO+"pyodide.js")}); const m={loadPyodide:self.loadPyodide};`
    : kind==="iframe"
    ? `await new Promise((res,rej)=>{ const sc=document.createElement("script"); sc.src=${JSON.stringify(V67_PYO+"pyodide.js")}; sc.onload=res; sc.onerror=()=>rej(new Error("No se pudo descargar "+sc.src)); document.head.appendChild(sc); }); const m={loadPyodide:self.loadPyodide};`
    : `const m=await import(${JSON.stringify(V67_PYO+"pyodide.mjs")});`;
  const guard=kind==="iframe"?20:0;   // en el iframe no se puede cortar desde afuera: corta Python mismo
  const body=`
postMessage({phase:"alive",kind:${JSON.stringify(kind||"module")}});
let py=null, ready=null;
let SRC=[];
function tb(m){   // solo las líneas del código del usuario (sin el interior de Pyodide)
  const L=String(m).split("\\n"); const o=["Traceback (most recent call last):"]; let keep=false, any=false;
  for(let i=0;i<L.length;i++){ const l=L[i];
    if(/^\\s*File "/.test(l)){ keep=/^\\s*File "<exec>"/.test(l)&&!/in _artlas_exec\\s*$/.test(l)&&!/_artlas_exec/.test(L[i+1]||"");
      if(keep){ o.push(l.replace("<exec>","tu código")); any=true; const n=+((/line (\\d+)/.exec(l)||[])[1]||0); const src=(SRC[n-1]||"").trim(); if(src&&!/^\\s{4}\\S/.test(L[i+1]||"")) o.push("    "+src); } continue; }
    if(/^Traceback/.test(l)) continue;
    if(/^\\s/.test(l)){ if(keep) o.push(l); continue; }
    if(l.trim()){ o.push(l); keep=false; }
  }
  return any?o.join("\\n"):m;
}
async function boot(id){
  postMessage({id,phase:"loading"});
  ${load}
  py=await m.loadPyodide({indexURL:${JSON.stringify(V67_PYO)}});
  await py.runPythonAsync(${JSON.stringify(V67_PRELUDE)});
  // aislamiento: el código del usuario no puede leer bases locales del sitio
  for(const k of ["indexedDB","caches"]){ try{ Object.defineProperty(self,k,{value:undefined,configurable:false}); }catch(e){} }
}
self.onmessage=async(e)=>{
  const {id,code,stdin}=e.data||{};
  if(!id) return;
  let out="", err="";
  try{
    if(!ready) ready=boot(id);
    await ready;
    const dec=new TextDecoder();   // salida carácter a carácter: los input("…") quedan en orden, como en una terminal
    try{ py.setStdout({write:(b)=>{ out+=dec.decode(b,{stream:true}); return b.length; },isatty:false}); }catch(z){ py.setStdout({batched:s=>{ out+=s+"\\n"; }}); }
    py.setStderr({batched:s=>{ err+=s+"\\n"; }});
    const lines=Array.isArray(stdin)?stdin.slice():[];
    try{ py.setStdin({stdin:()=>{ if(!lines.length) return undefined; const l=lines.shift(); out+=l+"\\n"; return l; },isatty:false}); }catch(z){}
    const pk=[];
    try{ await py.loadPackagesFromImports(code,{messageCallback:(m)=>{ const x=/Loading (.+)/.exec(m||""); if(x){ pk.push(x[1]); postMessage({id,phase:"packages",names:x[1]}); } },errorCallback:(m)=>{ err+=m+"\\n"; }}); }catch(x){ err+=String(x&&x.message||x)+"\\n"; }
    if(/matplotlib/.test(code)){ await py.runPythonAsync("import matplotlib\\nmatplotlib.use('AGG')\\nimport matplotlib.pyplot as _plt\\n_plt.show=_artlas_show"); }
    postMessage({id,phase:"run"});
    const t0=performance.now();
    let res, repr="";
    ${guard?`py.runPython("_artlas_guard(${guard})");`:""}
    py.globals.set("_artlas_src",code); SRC=String(code).split("\\n");
    try{ res=await py.runPythonAsync("await _artlas_exec(_artlas_src)"); }
    catch(x){
      ${guard?`try{ py.runPython("sys.settrace(None)"); }catch(z){}`:""}
      const ms=performance.now()-t0; const msg=String(x&&x.message||x);
      let figs=[]; try{ const f=py.runPython("_artlas_take()"); figs=f.toJs(); f.destroy(); }catch(z){}
      const last=msg.trim().split("\\n").pop()||"";
      if(/^SystemExit\\b/.test(last)){ const c=last.replace(/^SystemExit:?\\s*/,"").trim(); const ok=!c||c==="0"||c==="None"; postMessage({id,ok,out:out+(!ok?c+"\\n":""),err:err.trim(),figs,ms,exit:true}); return; }
      postMessage({id,ok:false,out,err:(err+tb(msg)).trim(),figs,ms}); return;
    }
    ${guard?`try{ py.runPython("sys.settrace(None)"); }catch(z){}`:""}
    const ms=performance.now()-t0;
    if(res&&res.type==="_ArtlasExit"){   // sys.exit(): 0/None = fin normal; un texto o número = fin con error
      let c=null; try{ c=res.code; if(c&&c.toString) c=c.toString(); }catch(z){} try{ res.destroy(); }catch(z){}
      let figs=[]; try{ const f=py.runPython("_artlas_take()"); figs=f.toJs(); f.destroy(); }catch(z){}
      const ok=c===undefined||c===null||c===0||c==="0"||c==="None";
      postMessage({id,ok,out:out+(!ok?String(c)+"\\n":""),err:err.trim(),figs,ms,exit:true}); return;
    }
    if(res!==undefined&&res!==null){ try{ repr=(res&&typeof res==="object"&&res.toString)?res.toString():String(res); }catch(z){ repr=String(res); } try{ if(res&&res.destroy) res.destroy(); }catch(z){} }
    let figs=[]; try{ const f=py.runPython("_artlas_take()"); figs=f.toJs(); f.destroy(); }catch(z){}
    postMessage({id,ok:true,out,err:err.trim(),res:repr,figs,ms});
  }catch(x){ postMessage({id,ok:false,out,err:(err+String(x&&x.message||x)).trim(),figs:[],ms:0,boot:true}); }
};`;
  return kind==="iframe"
    ? `(function(){ const postMessage=(d)=>parent.postMessage(d,"*"); ${body} })();`
    : body;
}
