/* recurso movido a app-recursos.js: ARTLAS_ICO_B64 */
const DESK_SHORTCUT_BAT_B64="QGVjaG8gb2ZmDQpjaGNwIDY1MDAxID5udWwNCmNkIC9kICIlfmRwMCINCmVjaG8gQ3JlYW5kbyBhY2Nlc28gZGlyZWN0byBkZSBBUlRMQVMgZW4gZWwgRXNjcml0b3Jpby4uLg0KcG93ZXJzaGVsbCAtTm9Qcm9maWxlIC1FeGVjdXRpb25Qb2xpY3kgQnlwYXNzIC1Db21tYW5kICIkVz1OZXctT2JqZWN0IC1Db21PYmplY3QgV1NjcmlwdC5TaGVsbDsgJGQ9W0Vudmlyb25tZW50XTo6R2V0Rm9sZGVyUGF0aCgnRGVza3RvcCcpOyAkbG5rPUpvaW4tUGF0aCAkZCAnQVJUTEFTLmxuayc7ICRzPSRXLkNyZWF0ZVNob3J0Y3V0KCRsbmspOyAkcy5UYXJnZXRQYXRoPShKb2luLVBhdGggJFBXRC5QYXRoICdBUlRMQVMuaHRtbCcpOyAkcy5Xb3JraW5nRGlyZWN0b3J5PSRQV0QuUGF0aDsgJHMuSWNvbkxvY2F0aW9uPShKb2luLVBhdGggJFBXRC5QYXRoICdBUlRMQVMuaWNvJyk7ICRzLkRlc2NyaXB0aW9uPSdBUlRMQVMnOyAkcy5TYXZlKCkiDQppZiBlcnJvcmxldmVsIDEgKGVjaG8gSHVibyB1biBwcm9ibGVtYS4gUHJvYmEgY2xpYyBkZXJlY2hvLCBFamVjdXRhciBjb21vIGFkbWluaXN0cmFkb3IuKSBlbHNlIChlY2hvIExpc3RvISBGaWphdGUgZWwgaWNvbm8gQVJUTEFTIGVuIHR1IEVzY3JpdG9yaW8uKQ0KcGF1c2UNCg==";
/* recurso movido a app-recursos.js: RAGLOCAL_FILES */
function downloadRagLocal(){
  try{
    if(typeof JSZip==="undefined"){ alert("Recargá la página: falta el empaquetador (JSZip)."); return; }
    const zip=new JSZip(); const root=zip.folder("ARTLAS_RAG");
    for(const name in RAGLOCAL_FILES){
      const bin=atob(RAGLOCAL_FILES[name]); const arr=new Uint8Array(bin.length);
      for(let i=0;i<bin.length;i++) arr[i]=bin.charCodeAt(i);
      root.file(name, arr);
    }
    const note=document.getElementById("ragdl-note"); if(note)note.textContent="Armando paquete…";
    zip.generateAsync({type:"blob"}).then(function(blob){
      const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="ARTLAS_RAG.zip"; a.click();
      if(note)note.innerHTML="✓ Descargado. <b>Si Windows bloquea INICIAR.bat</b>: clic derecho al zip → Propiedades → Desbloquear (o usá INICIAR.py).";
    });
  }catch(e){ alert("Error al armar el zip: "+(e.message||e)); }
}

/* recurso movido a app-recursos.js: MANUAL_B64 */
/* === v30.1 arranque a prueba de fallos + reporte de errores en pantalla === */
window.addEventListener("error",function(ev){try{var b=document.getElementById("atlas-err");if(!b){b=document.createElement("div");b.id="atlas-err";b.style.cssText="position:fixed;left:0;right:0;bottom:0;background:#b00020;color:#fff;font:12px/1.4 monospace;padding:8px 12px;z-index:99999;white-space:pre-wrap;max-height:40vh;overflow:auto";(document.body||document.documentElement).appendChild(b);}b.textContent="\u26a0 "+(ev.message||ev.error)+"  ["+(String(ev.filename||"").split(/[\\/]/).pop())+":"+ev.lineno+":"+ev.colno+"]";}catch(_){}});
window.addEventListener("DOMContentLoaded",function(){try{if(typeof atlasBoot==="function")atlasBoot();}catch(e){console.error(e);}});
window.addEventListener("load",function(){try{if(typeof atlasBoot==="function")atlasBoot();}catch(e){}});

/* ================= PROVEEDORES Y MODELOS ================= */
const PROVIDERS = {
  openai:    {label:"OpenAI",            icon:"🟢", keyPh:"sk-…",      defModel:"gpt-4o-mini",  sub:"GPT-4o / o-series",
              note:"Obtené tu clave en platform.openai.com → API keys. Modelos: gpt-4o, gpt-4o-mini, o3-mini…"},
  anthropic: {label:"Anthropic (Claude)",icon:"🟠", keyPh:"sk-ant-…",  defModel:"claude-sonnet-4-5", sub:"Sonnet / Opus",
              note:"Clave en console.anthropic.com. Modelos: claude-sonnet-4-5, claude-haiku-4-5, claude-opus-4-8…"},
  gemini:    {label:"Google Gemini",     icon:"🔵", keyPh:"AIza…",     defModel:"gemini-2.0-flash", sub:"Flash / Pro",
              note:"Clave gratuita en aistudio.google.com → Get API key. Modelos: gemini-2.0-flash, gemini-2.5-pro…"},
  groq:      {label:"Groq — OSS ⚡",     icon:"🚀", keyPh:"gsk_…",     defModel:"openai/gpt-oss-120b", sub:"GPT OSS · Llama 4 · Qwen (open source)",
              note:"Inferencia ultra rápida de modelos open source con plan gratuito. Conseguí tu <a href='https://console.groq.com/keys' target='_blank'>API Key gratis</a> en console.groq.com. Lista completa de modelos en console.groq.com/docs/models — si uno da límite de uso (rate limit), cambiá a otro."},
  hf:        {label:"Hugging Face 🤗",   icon:"🤗", keyPh:"hf_…",      defModel:"meta-llama/Llama-3.3-70B-Instruct", sub:"Miles de modelos OSS",
              note:"Acceso a miles de modelos open source (Llama, Qwen, Mistral, DeepSeek, GLM…) vía la Inference API. Token gratis en <a href='https://huggingface.co/settings/tokens' target='_blank'>huggingface.co/settings/tokens</a> (tipo Read). Ejemplos de modelo: meta-llama/Llama-3.3-70B-Instruct · Qwen/Qwen2.5-72B-Instruct · deepseek-ai/DeepSeek-V3 · mistralai/Mistral-Small-24B-Instruct-2501"},
  basic:     {label:"Básico gratis (sin key)", icon:"🎁", keyPh:"", defModel:"openai", sub:"Modelo comunitario",
              note:"Modelo por defecto de AR.T.L.A.S. — funciona sin API key, ideal para empezar ya. Usa el servicio comunitario gratuito Pollinations.ai (sin garantía de disponibilidad ni privacidad: no envíes datos sensibles)."},
  ollama:    {label:"Ollama (local / OSS)",icon:"🦙", keyPh:"(sin clave — URL local)", defModel:"llama3.2", sub:"Llama · Qwen · Mistral",
              note:"Requiere Ollama corriendo en tu PC (ollama.com). Dejá vacío para desactivar; configurá URL y modelo. Si el navegador bloquea la conexión, iniciá Ollama con OLLAMA_ORIGINS=* ."},
  webllm:    {label:"ARTLAS Local (navegador)", icon:"🖥️", keyPh:"", defModel:"Qwen2.5-1.5B-Instruct-q4f16_1-MLC", sub:"Descarga y corre un modelo en tu navegador (WebGPU)",
              note:"Descargá y ejecutá un modelo chico DENTRO del navegador, sin instalar nada. Requiere un navegador con WebGPU (Chrome o Edge actualizados). La 1ª vez baja el modelo (~0,3–2 GB) y queda en caché. Funciona junto a los demás modelos en el ruteo (Simultáneo/Consenso)."},
  deepseek:  {label:"DeepSeek", icon:"🌀", keyPh:"sk-…", defModel:"deepseek-chat", sub:"DeepSeek V3 · R1",
              note:"Clave en platform.deepseek.com. Modelos: deepseek-chat (V3) y deepseek-reasoner (R1). ⚠ DeepSeek suele bloquear llamadas directas del navegador (CORS); si da error, usá el backend/proxy o el preset OpenRouter."},
  kimi:      {label:"Kimi (Moonshot)", icon:"🌙", keyPh:"sk-…", defModel:"moonshot-v1-8k", sub:"Kimi K2 · Moonshot",
              note:"Clave en platform.moonshot.ai. Modelos: kimi-k2, moonshot-v1-8k / 32k / 128k. ⚠ Puede requerir proxy por CORS desde el navegador."},
  zai:       {label:"Z.AI (GLM / Zhipu)", icon:"🟣", keyPh:"…", defModel:"glm-4-flash", sub:"GLM-4 Flash GRATIS · GLM 4.6",
              note:"Clave en z.ai. GLM-4-Flash es GRATIS. Modelos: glm-4-flash (gratis), glm-4.6, glm-4.5-air, glm-4-plus. ⚠ Puede requerir proxy por CORS."},
  felo:      {label:"Felo.ai", icon:"🔎", keyPh:"sk-…", defModel:"z-ai/glm-5.3-flash", sub:"Modelos premium más baratos",
              note:"API OpenAI-compatible en openapi.felo.ai (clave gratis en openapi.felo.ai/settings/api-keys). El plan FREE da ~200 créditos/día con acceso PARCIAL a modelos; algunos (como OX Alpha o Claude) piden plan pago. Tocá «🔄 Actualizar lista» para ver los modelos habilitados en TU cuenta. ⚠ Felo bloquea el navegador directo — usá la versión FULLSTACK (proxy)."},
  other:     {label:"Router Multimodelos", icon:"🧬", keyPh:"sk-…", defModel:"", sub:"OpenAI-compatible · OpenRouter · DeepSeek · Qwen · Kimi · Z.AI",
              note:"Cualquier proveedor con endpoint OpenAI-compatible: elegí un preset o cargá tu URL base. ⚠️ Algunos proveedores bloquean llamadas directas desde el navegador (CORS); si te da error de conexión, usá el preset OpenRouter (openrouter.ai/keys). 🖥️ Para correr un modelo LOCAL en CPU (sin GPU): abrí la app RAG-Local, y acá elegí el preset «ARTLAS Local CPU (RAG-Local)» — no requiere API key."}
};
const OTHER_PRESETS={
  deepseek:  {label:"DeepSeek",              url:"https://api.deepseek.com/v1",                          model:"deepseek-chat"},
  qwen:      {label:"Qwen (Alibaba DashScope)", url:"https://dashscope-intl.aliyuncs.com/compatible-mode/v1", model:"qwen-plus"},
  kimi:      {label:"Kimi (Moonshot AI)",    url:"https://api.moonshot.ai/v1",                           model:"moonshot-v1-8k"},
  zai:       {label:"Z.AI (GLM / Zhipu)",    url:"https://api.z.ai/api/paas/v4",                         model:"glm-4.6"},
  openrouter:{label:"OpenRouter (multi-modelo ⭐)", url:"https://openrouter.ai/api/v1",                  model:"deepseek/deepseek-chat-v3-0324:free"},
  together:  {label:"Together AI (free)",    url:"https://api.together.xyz/v1",                          model:"meta-llama/Llama-3.3-70B-Instruct-Turbo-Free"},
  localcpu:  {label:"ARTLAS Local CPU (RAG-Local, sin GPU)", url:"http://127.0.0.1:8760/v1",           model:"local"},
  localrag:  {label:"ARTLAS Local + Documentos (RAG, CPU)", url:"http://127.0.0.1:8760/v1",           model:"local-rag"},
  felo:      {label:"Felo.ai",               url:"https://openapi.felo.ai/api/v1",                       model:"z-ai/glm-5.3-flash"},
  custom:    {label:"Personalizado…",        url:"",                                                     model:""}
};
/* ===== Proveedores OpenAI-compatible dedicados (key propia + selector de modelo) ===== */
let OA_LIVE=JSON.parse(localStorage.getItem("atlas_oa_models")||"{}");
function oaModelList(k){ return (typeof OA_PROVIDERS!=="undefined"&&OA_LIVE[k]&&OA_LIVE[k].length)?OA_LIVE[k]:OA_PROVIDERS[k].models; }
function rerenderOaCard(k){ const h=document.getElementById("card-"+k); if(h) h.outerHTML=provCard(k,PROVIDERS[k]); }
async function oaRefreshModels(k){
  const st=document.getElementById("oa-st-"+k); const set=(t)=>{ if(st)st.textContent=t; };
  const keyEl=document.getElementById("key-"+k); const key=keyEl?keyEl.value.trim():"";
  if(!key){ set("Cargá primero la API key."); return; }
  cfg[k]=cfg[k]||{}; cfg[k].key=key; save();
  set("Cargando modelos de tu cuenta…");
  try{
    const url=(OA_PROVIDERS[k].url||"").replace(/\/$/,"")+"/models";
    const r=await apiFetch(url,{method:"GET",headers:{"Authorization":"Bearer "+key}});
    const j=await r.json(); if(!r.ok) throw new Error((j&&(j.error&&j.error.message||j.message))||r.status);
    const arr=((j.data||j.models||[])).map(m=>(m&&(m.id||m.model))||m).filter(Boolean);
    if(arr.length){ OA_LIVE[k]=arr.map(id=>[id,id]); localStorage.setItem("atlas_oa_models",JSON.stringify(OA_LIVE)); rerenderOaCard(k); }
    else set("Tu cuenta no devolvió modelos.");
  }catch(e){ set("✗ "+((e&&e.message)||e)); }
}
const OA_PROVIDERS={
  deepseek:{ url:"https://api.deepseek.com/v1", models:[["deepseek-chat","DeepSeek V3 (chat)"],["deepseek-reasoner","DeepSeek R1 (razonamiento)"]] },
  kimi:{     url:"https://api.moonshot.ai/v1",  models:[["kimi-k2-0711-preview","Kimi K2 (preview)"],["moonshot-v1-8k","Moonshot v1 8k"],["moonshot-v1-32k","Moonshot v1 32k"],["moonshot-v1-128k","Moonshot v1 128k"]] },
  zai:{      url:"https://api.z.ai/api/paas/v4", models:[["glm-4-flash","GLM-4 Flash · GRATIS"],["glm-4.6","GLM 4.6"],["glm-4.5-air","GLM 4.5 Air"],["glm-4-plus","GLM-4 Plus"]] },
  felo:{     url:"https://openapi.felo.ai/api/v1", models:[["z-ai/glm-5.3-flash","GLM 5.3 Flash (plan free)"],["stealth/ox-alpha","OX Alpha 1M (puede requerir pago)"],["claude-sonnet-4-6","Claude Sonnet 4.6 (pago)"]] }
};
/* ===== Modelos recomendados de OpenRouter (una sola API key). Refrescable en vivo. ===== */
const OPENROUTER_MODELS=[
  ["deepseek/deepseek-chat-v3.1:free","DeepSeek V3.1 · GRATIS"],
  ["deepseek/deepseek-r1-0528:free","DeepSeek R1 (0528) · GRATIS"],
  ["meta-llama/llama-3.3-70b-instruct:free","Llama 3.3 70B · GRATIS"],
  ["qwen/qwen3-235b-a22b:free","Qwen3 235B · GRATIS"],
  ["qwen/qwen-2.5-72b-instruct:free","Qwen 2.5 72B · GRATIS"],
  ["google/gemini-2.0-flash-exp:free","Gemini 2.0 Flash exp · GRATIS"],
  ["mistralai/mistral-small-3.2-24b-instruct:free","Mistral Small 3.2 · GRATIS"],
  ["z-ai/glm-4.5-air:free","GLM 4.5 Air · GRATIS"],
  ["moonshotai/kimi-k2:free","Kimi K2 · GRATIS"],
  ["anthropic/claude-sonnet-4.5","Claude Sonnet 4.5 (Anthropic)"],
  ["anthropic/claude-opus-4.1","Claude Opus 4.1 (Anthropic)"],
  ["openai/gpt-4o","GPT-4o (OpenAI)"],
  ["openai/gpt-4o-mini","GPT-4o mini (OpenAI)"],
  ["openai/o4-mini","o4-mini (OpenAI)"],
  ["google/gemini-2.5-flash","Gemini 2.5 Flash (Google)"],
  ["google/gemini-2.5-pro","Gemini 2.5 Pro (Google)"],
  ["deepseek/deepseek-chat-v3.1","DeepSeek V3.1"],
  ["qwen/qwen3-coder","Qwen3 Coder"],
  ["meta-llama/llama-4-maverick","Llama 4 Maverick (Meta)"],
  ["mistralai/mistral-large-2411","Mistral Large"],
  ["x-ai/grok-4","Grok 4 (xAI)"]
];
let OR_LIVE=JSON.parse(localStorage.getItem("atlas_or_models")||"null");
function orModelList(){ return (OR_LIVE&&OR_LIVE.length)?OR_LIVE:OPENROUTER_MODELS; }
/* ===== Modelos recomendados de Hugging Face (Inference Router). Refrescable en vivo. ===== */
const HF_MODELS=[
  ["meta-llama/Llama-3.3-70B-Instruct","Llama 3.3 70B (Meta)"],
  ["meta-llama/Llama-3.1-8B-Instruct","Llama 3.1 8B (Meta)"],
  ["Qwen/Qwen2.5-72B-Instruct","Qwen 2.5 72B (Alibaba)"],
  ["Qwen/Qwen2.5-7B-Instruct","Qwen 2.5 7B (Alibaba)"],
  ["deepseek-ai/DeepSeek-V3","DeepSeek V3"],
  ["deepseek-ai/DeepSeek-R1","DeepSeek R1 (razonamiento)"],
  ["mistralai/Mistral-Small-24B-Instruct-2501","Mistral Small 24B"],
  ["mistralai/Mixtral-8x7B-Instruct-v0.1","Mixtral 8x7B"],
  ["google/gemma-2-27b-it","Gemma 2 27B (Google)"],
  ["microsoft/Phi-3.5-mini-instruct","Phi 3.5 mini (Microsoft)"],
  ["NousResearch/Hermes-3-Llama-3.1-8B","Hermes 3 (Llama 3.1 8B)"],
  ["HuggingFaceH4/zephyr-7b-beta","Zephyr 7B"]
];
let HF_LIVE=JSON.parse(localStorage.getItem("atlas_hf_models")||"null");
function hfModelList(){ return (HF_LIVE&&HF_LIVE.length)?HF_LIVE:HF_MODELS; }
const GROQ_MODELS=[
  ["llama-3.3-70b-versatile","Llama 3.3 70B ⭐ (versátil)"],
  ["llama-3.1-8b-instant","Llama 3.1 8B (instantáneo)"],
  ["openai/gpt-oss-120b","GPT-OSS 120B (razonamiento)"],
  ["openai/gpt-oss-20b","GPT-OSS 20B (rápido)"],
  ["moonshotai/kimi-k2-instruct","Kimi K2 Instruct (Moonshot)"],
  ["deepseek-r1-distill-llama-70b","DeepSeek R1 Distill 70B"],
  ["meta-llama/llama-4-scout-17b-16e-instruct","Llama 4 Scout (visión)"],
  ["meta-llama/llama-4-maverick-17b-128e-instruct","Llama 4 Maverick"],
  ["qwen/qwen3-32b","Qwen 3 32B"],
  ["gemma2-9b-it","Gemma 2 9B"]
];
const BASIC_MODELS=[
  ["openai","GPT-4o (Pollinations)"],
  ["openai-large","GPT-4o Large (Pollinations)"],
  ["openai-fast","GPT-4o Fast (Pollinations)"],
  ["mistral","Mistral (Pollinations)"],
  ["llama","Llama (Pollinations)"],
  ["deepseek","DeepSeek (Pollinations)"],
  ["qwen-coder","Qwen Coder (Pollinations)"],
  ["searchgpt","SearchGPT · web (Pollinations)"],
  ["hackclub","Hack Club AI (gratis, sin key)"]
];
/* ===== WebLLM: modelos que corren DENTRO del navegador (WebGPU) ===== */
const WEBLLM_MODELS=[
  ["Qwen2.5-0.5B-Instruct-q4f16_1-MLC","Qwen2.5 0.5B (ultra liviano)"],
  ["Qwen2.5-1.5B-Instruct-q4f16_1-MLC","Qwen2.5 1.5B (recomendado)"],
  ["Qwen2.5-3B-Instruct-q4f16_1-MLC","Qwen2.5 3B"],
  ["Qwen2.5-Coder-1.5B-Instruct-q4f16_1-MLC","Qwen2.5 Coder 1.5B (código)"],
  ["Llama-3.2-1B-Instruct-q4f16_1-MLC","Llama 3.2 1B"],
  ["Llama-3.2-3B-Instruct-q4f16_1-MLC","Llama 3.2 3B"],
  ["Phi-3.5-mini-instruct-q4f16_1-MLC","Phi 3.5 mini"],
  ["gemma-2-2b-it-q4f16_1-MLC","Gemma 2 2B (Google)"],
  ["SmolLM2-1.7B-Instruct-q4f16_1-MLC","SmolLM2 1.7B"],
  ["TinyLlama-1.1B-Chat-v1.0-q4f16_1-MLC","TinyLlama 1.1B (mínimo)"]
];
let WEBLLM_LIVE=JSON.parse(localStorage.getItem("atlas_webllm_models")||"null");
function webllmModelList(){ return (WEBLLM_LIVE&&WEBLLM_LIVE.length)?WEBLLM_LIVE:WEBLLM_MODELS; }
let webllmEngine=null, webllmReady=false, webllmModel=null;
async function webllmLoad(){
  const el=document.getElementById("webllm-status");
  const set=(t)=>{ if(el) el.textContent=t; };
  if(!("gpu" in navigator)){ set("⚠ Tu navegador no tiene WebGPU. Usá Chrome o Edge actualizados."); return; }
  const model=(cfg.webllm&&cfg.webllm.model)||"Qwen2.5-1.5B-Instruct-q4f16_1-MLC";
  try{
    set("Cargando librería WebLLM…");
    const webllm=await import("https://esm.run/@mlc-ai/web-llm");
    webllmReady=false; try{renderMenu();}catch(e){}
    webllmEngine=await webllm.CreateMLCEngine(model,{ initProgressCallback:(p)=>set((p&&p.text)?p.text:"descargando modelo…") });
    webllmModel=model; webllmReady=true;
    cfg.webllm=cfg.webllm||{}; cfg.webllm.model=model; save();
    set("✓ listo — "+model); try{renderMenu();}catch(e){}
  }catch(e){ const _m=((e&&e.message)||e)+""; set("✗ "+_m+(/VectorInt|cache|Cache/i.test(_m)?" — tocá «🗑 Borrar caché del modelo» y cargá de nuevo.":"")); webllmReady=false; }
}
function rerenderWebllmCard(){ const h=document.getElementById("card-webllm"); if(h) h.outerHTML=provCard("webllm",PROVIDERS.webllm); }
async function webllmClearCache(){
  const el=document.getElementById("webllm-status"); const set=(t)=>{ if(el) el.textContent=t; };
  try{ if(webllmEngine&&webllmEngine.unload) await webllmEngine.unload(); }catch(e){}
  webllmEngine=null; webllmReady=false;
  try{ if(window.caches){ const ns=await caches.keys(); for(const n of ns){ if(/webllm|mlc|tvmjs/i.test(n)) await caches.delete(n); } } }catch(e){}
  try{ if(window.indexedDB&&indexedDB.databases){ const dbs=await indexedDB.databases(); for(const d of dbs){ if(d.name&&/webllm|mlc|tvmjs/i.test(d.name)) indexedDB.deleteDatabase(d.name); } } }catch(e){}
  set("🗑 Caché borrado. Tocá «Descargar / cargar modelo» para bajarlo de nuevo.");
  try{ renderMenu(); }catch(e){}
}
async function webllmRefreshList(){
  const el=document.getElementById("webllm-status"); const set=(t)=>{ if(el) el.textContent=t; };
  try{ set("Cargando lista de modelos…");
    const webllm=await import("https://esm.run/@mlc-ai/web-llm");
    const list=((webllm.prebuiltAppConfig&&webllm.prebuiltAppConfig.model_list)||[]).map(m=>m.model_id).filter(Boolean);
    if(list.length){ WEBLLM_LIVE=list.map(id=>[id,id]); localStorage.setItem("atlas_webllm_models",JSON.stringify(WEBLLM_LIVE)); rerenderWebllmCard(); }
    else set("No pude leer la lista.");
  }catch(e){ set("✗ "+((e&&e.message)||e)); }
}
const MODELS = {
  free:        {name:"AR.T.L.A.S. Free",         prov:"basic",     desc:"Modelo básico gratuito — funciona sin API key"},
  locallm:     {name:"AR.T.L.A.S. Local",        prov:"webllm",    desc:"Modelo descargado que corre en tu navegador (WebLLM · WebGPU)"},
  deepseekL:   {name:"AR.T.L.A.S. DeepSeek",     prov:"deepseek",  desc:"DeepSeek V3 / R1 (con tu API key)"},
  kimiL:       {name:"AR.T.L.A.S. Kimi",         prov:"kimi",      desc:"Kimi / Moonshot (con tu API key)"},
  zaiL:        {name:"AR.T.L.A.S. GLM",          prov:"zai",       desc:"Z.AI GLM — GLM-4 Flash es gratis"},
  feloL:       {name:"AR.T.L.A.S. Felo",         prov:"felo",      desc:"Felo.ai (verificá su API)"},
  oss:         {name:"AR.T.L.A.S. OSS",          prov:"groq",      desc:"Open source acelerado (Llama 3.3 70B vía Groq)"},
  local:       {name:"AR.T.L.A.S. Local",        prov:"ollama",    desc:"Modelos locales privados (Ollama en tu PC)"},
  otros:       {name:"AR.T.L.A.S. Otros",        prov:"other",     desc:"Qwen · Kimi · DeepSeek · Z.AI — vía endpoint OpenAI-compatible"},
  hf:          {name:"AR.T.L.A.S. HF",           prov:"hf",        desc:"Modelos OSS de Hugging Face — Llama, Qwen, Mistral, DeepSeek y miles más"},
  fast:        {name:"AR.T.L.A.S. Fast",         prov:"gemini",    desc:"Respuestas veloces para consultas y resúmenes"},
  medium:      {name:"AR.T.L.A.S. Medium",       prov:"openai",    desc:"Balance velocidad / calidad para uso diario"},
  dense:       {name:"AR.T.L.A.S. Dense",        prov:"anthropic", desc:"Máxima precisión y contexto largo"},
  thinking:    {name:"AR.T.L.A.S. Thinking",     prov:"anthropic", desc:"Razonamiento explícito paso a paso", sys:"Antes de responder, razoná paso a paso. Mostrá tu razonamiento brevemente al inicio, luego la respuesta final clara."},
  deepthink:   {name:"AR.T.L.A.S. Deep Thinking",prov:"openai",    desc:"Problemas complejos: planifica y evalúa alternativas", sys:"Problema complejo: primero planificá, evaluá al menos 2 alternativas con ventajas y desventajas, y recomendá la mejor con justificación."},
  deepresearch:{name:"AR.T.L.A.S. Deep Research",prov:"gemini",    desc:"Investigación: estructura, compara y cita fuentes", sys:"Modo investigación: estructurá la respuesta como informe con secciones, comparativas y referencias a fuentes conocidas. Aclarar cuando algo requiera verificación."}
};

/* ================= ESTADO ================= */
let cfg = JSON.parse(localStorage.getItem("atlas_cfg")||"{}");
let chats = JSON.parse(localStorage.getItem("atlas_chats")||"[]");
let kb = [];   // [{name,size,text,on}] — persistido en IndexedDB
let curId=null, curModel=localStorage.getItem("atlas_model")||"free", busy=false, customSys=null, agentWebPending=false;
function docsCoverQuery(sys,q){
  if(!sys||sys.indexOf("CONOCIMIENTO DEL AGENTE")<0) return false;
  const norm=s=>(s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9 ]/g," ");
  const stop=new Set("para pero como cual cuales cuáles donde cuando porque sobre entre desde hasta esta este estos estas segun tiene tienen puede pueden hacer tener cuanto cuanta cuantos cuál qué que una uno unas unos con sin los las del más menos".split(" "));
  const docs=norm(sys.split("CONOCIMIENTO DEL AGENTE").slice(1).join(" "));
  const words=[...new Set(norm(q).split(/\s+/).filter(w=>w.length>=4&&!stop.has(w)))];
  if(!words.length) return false;
  const found=words.filter(w=>docs.indexOf(w)>=0).length;
  return found>=Math.max(2,Math.ceil(words.length*0.6));
}
async function agentWebSearch(q){
  q=(q||"").trim(); if(!q) return "";
  // 1) Jina s.jina.ai: buscador que agrega resultados de MUCHOS sitios (sin API key, con CORS)
  try{
    const r=await fetch("https://s.jina.ai/?q="+encodeURIComponent(q),{headers:{"Accept":"text/plain","X-Respond-With":"no-content"}});
    if(r.ok){ const t=await r.text(); if(t&&t.trim().length>40) return t.trim().slice(0,6500); }
  }catch(e){}
  // 2) Respaldo: DuckDuckGo Instant Answer (JSON, CORS)
  try{
    const r=await fetch("https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&q="+encodeURIComponent(q));
    if(r.ok){ const j=await r.json(); const out=[];
      if(j.AbstractText) out.push(j.AbstractText+(j.AbstractURL?" ("+j.AbstractURL+")":""));
      (j.RelatedTopics||[]).forEach(t=>{ if(t.Text&&t.FirstURL) out.push("- "+t.Text+" — "+t.FirstURL); else if(t.Topics) t.Topics.forEach(x=>{ if(x.Text&&x.FirstURL) out.push("- "+x.Text+" — "+x.FirstURL); }); });
      if(out.length) return out.join("\n").slice(0,6500);
    }
  }catch(e){}
  return "";
}
if(!MODELS[curModel]) curModel="free";

const $=id=>document.getElementById(id);
function save(){ localStorage.setItem("atlas_chats",JSON.stringify(chats)); localStorage.setItem("atlas_cfg",JSON.stringify(cfg)); localStorage.setItem("atlas_model",curModel); }
function cur(){ return chats.find(c=>c.id===curId); }
function connected(pk){ const c=cfg[pk]; if(pk==="basic")return true; if(pk==="webllm")return !!webllmReady; if(typeof OA_PROVIDERS!=="undefined"&&OA_PROVIDERS[pk])return !!(c&&c.key); if(pk==="other")return !!(c&&c.url&&(c.key||/127\.0\.0\.1|localhost|0\.0\.0\.0/.test(c.url))); return pk==="ollama" ? !!(c&&c.enabled&&c.url) : !!(c&&c.key); }
function provModel(pk){ return (cfg[pk]&&cfg[pk].model)||PROVIDERS[pk].defModel; }
function provShort(pk){ return pk==="webllm"?"Local":pk==="other"?((cfg.other&&cfg.other.preset==="openrouter")?"OpenRouter":"Router"):PROVIDERS[pk].label; }
function esc(t){ return (t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;"); }

/* ================= MÓDULOS ================= */
const MODULES = {
  image:{t:"Image",i:"🎨",d:"Generá imágenes con IA. Escribí tu prompt, copialo y abrilo en el generador que prefieras — algunos reciben el prompt directo por URL.",
    special:"prompt",
    promptPh:"Ej: infografía isométrica de una red 5G con antenas, núcleo de red y dispositivos IoT, estilo flat design, colores azul y verde…",
    tools:[
      {n:"ChatGPT (DALL·E)",d:"Generación integrada en ChatGPT. Recibe tu prompt por URL.",u:"https://chatgpt.com/?q=Gener%C3%A1%20una%20imagen%3A%20%s",q:1},
      {n:"Bing Image Creator",d:"DALL·E gratis con cuenta Microsoft. Recibe tu prompt por URL.",u:"https://www.bing.com/images/create?q=%s",q:1},
      {n:"Google ImageFX",d:"Imagen 3 de Google, gratuito con cuenta Google.",u:"https://labs.google/fx/tools/image-fx"},
      {n:"Leonardo.Ai",d:"Arte y renders de alta calidad, plan gratuito diario.",u:"https://app.leonardo.ai"},
      {n:"Ideogram",d:"Excelente para texto dentro de imágenes y logos.",u:"https://ideogram.ai"},
      {n:"Hugging Face (FLUX)",d:"Modelos open source de generación de imágenes.",u:"https://huggingface.co/spaces?search=flux"}
    ]},
  code:{t:"Code",i:"⌨️",d:"Asistente de programación. Usá el chat de ARTLAS con un perfil experto en código (con tu API conectada), o abrí las herramientas especializadas.",
    special:"chatlaunch",
    launchLabel:"⌨️ Abrir chat de código ARTLAS",
    launchSys:"Sos un ingeniero de software senior experto en Python, JavaScript/TypeScript, Java, C#, C++, Rust, Go, PHP, SQL, Kotlin y Swift, y en frameworks de ML (TensorFlow, PyTorch, Keras). Respondé con código completo y funcional en bloques ```, explicá decisiones clave, señalá bugs y proponé mejoras. Priorizá buenas prácticas, seguridad y rendimiento.",
    launchModel:"thinking",
    tools:[
      {n:"GitHub Copilot",d:"Autocompletado y chat dentro de tu editor.",u:"https://github.com/features/copilot"},
      {n:"Cursor",d:"Editor con IA integrada para proyectos completos.",u:"https://cursor.com"},
      {n:"Replit",d:"IDE online con agente que crea apps completas.",u:"https://replit.com"},
      {n:"Google Colab",d:"Notebooks Python gratis con GPU y Gemini integrado.",u:"https://colab.research.google.com"},
      {n:"StackBlitz",d:"Entorno web instantáneo para JS/TS.",u:"https://stackblitz.com"},
      {n:"Windsurf",d:"Editor agéntico gratuito de Codeium.",u:"https://windsurf.com"}
    ]},
  web:{t:"Web Design",i:"🌐",d:"Generá sitios web. Con tu API conectada, ARTLAS genera el HTML y lo previsualiza acá mismo. O usá los generadores externos especializados.",
    special:"webgen",
    tools:[
      {n:"v0 (Vercel)",d:"Genera interfaces React/Tailwind desde texto.",u:"https://v0.dev"},
      {n:"bolt.new",d:"Apps web full-stack generadas por IA.",u:"https://bolt.new"},
      {n:"Lovable",d:"De idea a app web publicada, sin código.",u:"https://lovable.dev"},
      {n:"Framer AI",d:"Sitios con diseño profesional generados por IA.",u:"https://www.framer.com"},
      {n:"Webflow",d:"Diseño web visual con asistencia de IA.",u:"https://webflow.com"}
    ]},
  pres:{t:"Presentations",i:"📊",d:"Generá presentaciones. Escribí el tema, copialo y abrilo en el generador que prefieras.",
    special:"prompt",
    promptPh:"Ej: pitch deck de 10 slides para una startup de análisis de datos en telecomunicaciones: problema, solución, mercado, modelo de negocio, roadmap…",
    tools:[
      {n:"Gamma",d:"Presentaciones, documentos y webs desde un prompt. El mejor para empezar.",u:"https://gamma.app"},
      {n:"Canva Magic Design",d:"Diseños y presentaciones con IA, enorme biblioteca.",u:"https://www.canva.com/magic-design/"},
      {n:"Beautiful.ai",d:"Slides con diseño automático inteligente.",u:"https://www.beautiful.ai"},
      {n:"Presentations.AI",d:"Decks tipo ChatGPT-para-presentaciones.",u:"https://www.presentations.ai"},
      {n:"SlidesAI",d:"Convierte texto en slides dentro de Google Slides.",u:"https://www.slidesai.io"}
    ]},
  mcp:{t:"MCP",i:"🔌",d:"Model Context Protocol: el estándar abierto para conectar LLMs con herramientas externas. Explorá registros de servidores MCP listos para usar.",
    tools:[
      {n:"modelcontextprotocol.io",d:"Documentación oficial del protocolo y guías de inicio.",u:"https://modelcontextprotocol.io"},
      {n:"Servidores oficiales (GitHub)",d:"Repositorio con servidores MCP de referencia.",u:"https://github.com/modelcontextprotocol/servers"},
      {n:"mcp.so",d:"Directorio comunitario con miles de servidores MCP.",u:"https://mcp.so"},
      {n:"Smithery",d:"Registro e instalación de servidores MCP en un click.",u:"https://smithery.ai"},
      {n:"Glama MCP",d:"Catálogo curado con métricas de calidad.",u:"https://glama.ai/mcp/servers"}
    ]},
  know:{t:"Knowledge",i:"📚",d:"Subí documentos (PDF, Word, Excel, texto — hasta 50 MB) y activalos para que el chat de ARTLAS los use como contexto en sus respuestas.",
    special:"kb",
    tools:[
      {n:"NotebookLM",d:"Sube PDFs y fuentes; Google genera resúmenes y podcasts.",u:"https://notebooklm.google.com"},
      {n:"ChatPDF",d:"Conversá con cualquier PDF.",u:"https://www.chatpdf.com"},
      {n:"Perplexity Spaces",d:"Colecciones de archivos + búsqueda con IA.",u:"https://www.perplexity.ai"}
    ]},
  res:{t:"Research",i:"🔬",d:"Investigación científica. Buscá en las bases académicas directamente, o usá ARTLAS Deep Research con tu API conectada.",
    special:"research",
    tools:[
      {n:"Perplexity",d:"Respuestas con citas de fuentes en tiempo real.",u:"https://www.perplexity.ai/search?q=%s",q:1},
      {n:"Elicit",d:"Asistente de revisión sistemática de papers.",u:"https://elicit.com"},
      {n:"Consensus",d:"Responde preguntas con evidencia de papers.",u:"https://consensus.app"},
      {n:"SciSpace",d:"Lee y explica papers con IA.",u:"https://scispace.com"}
    ]},
  cowork:{t:"Cowork",i:"👥",d:"Trabajo colaborativo: exportá tus conversaciones y GPTs para compartir con tu equipo, o importá las de otros.",
    special:"cowork",
    tools:[
      {n:"Notion AI",d:"Workspace colaborativo con IA integrada.",u:"https://www.notion.so"},
      {n:"Slack",d:"Comunicación de equipo, integrable con LLMs.",u:"https://slack.com"},
      {n:"Microsoft Teams + Copilot",d:"Colaboración con Copilot integrado.",u:"https://www.microsoft.com/microsoft-teams"},
      {n:"GitHub",d:"Versionado y colaboración para el código de ARTLAS.",u:"https://github.com"}
    ]}
};

const ENGINES = [
  {n:"Google Scholar",u:"https://scholar.google.com/scholar?q=%s"},
  {n:"arXiv",u:"https://arxiv.org/search/?searchtype=all&query=%s"},
  {n:"PubMed",u:"https://pubmed.ncbi.nlm.nih.gov/?term=%s"},
  {n:"IEEE Xplore",u:"https://ieeexplore.ieee.org/search/searchresult.jsp?queryText=%s"},
  {n:"Semantic Scholar",u:"https://www.semanticscholar.org/search?q=%s"},
  {n:"SpringerLink",u:"https://link.springer.com/search?query=%s"},
  {n:"ScienceDirect",u:"https://www.sciencedirect.com/search?qs=%s"}
];

/* ================= NAVEGACIÓN ================= */
const NAV = [
  {id:"chat",   t:"Chat",        i:"💬", view:"view-chat"},
  {id:"builder",t:"Workflows",   i:"⛓️", view:"view-builder"},
  {id:"art",    t:"Artefactos",  i:"🧩", view:"view-art"},
  {id:"analytics",t:"Analíticas", i:"📈", view:"view-analytics"},
  {id:"agents", t:"Agents",      i:"🤖", view:"view-agents"},
  {id:"arch",   t:"Arquitectura",i:"🗺️", view:"view-arch"},
  {id:"desk",   t:"Versión escritorio",i:"🖥️", view:"view-desk"},
  {id:"manual", t:"Manual",       i:"📖", view:"view-manual"},
];
let curView="chat";
function renderNav(){
  $("nav-motores").innerHTML = NAV.map(n=>`<button class="side-btn ${curView===n.id?"active":""}" onclick="go('${n.id}')">${n.i}&nbsp; ${n.t}</button>`).join("");
  $("nav-mods").innerHTML = Object.entries(MODULES).map(([k,m])=>`<button class="side-btn ${curView===k?"active":""}" onclick="goMod('${k}')">${m.i}&nbsp; ${m.t}</button>`).join("");
}
function showView(vid){ document.querySelectorAll(".view").forEach(v=>v.classList.remove("on")); $(vid).classList.add("on"); }
function go(id){
  curView=id; const n=NAV.find(x=>x.id===id);
  showView(n.view); renderNav();
  const isChat=id==="chat";
  $("model-btn").style.display=isChat?"flex":"none";
  $("view-title").style.display=isChat?"none":"block";
  $("view-title").textContent=n.i+" "+n.t;
  if(id==="arch") renderArch();
  if(id==="art") artListLoad();
  if(id==="manual") loadManual();
}
function loadManual(){ const f=document.getElementById("manual-frame"); if(!f||f.getAttribute("data-loaded"))return; try{ const html=decodeURIComponent(escape(atob(MANUAL_B64))); try{ f.srcdoc=html; }catch(e){ const d=(f.contentWindow||{}).document; if(d){ d.open(); d.write(html); d.close(); } } f.setAttribute("data-loaded","1"); }catch(e){ console.error("manual",e); } }
function goChat(){ go("chat"); }

/* ================= RENDER DE MÓDULOS ================= */
function toolIco(u,n){
  let h=""; try{ h=new URL(u).hostname.replace(/^www\./,""); }catch(e){ h=""; }
  const lab=((n||h||"?")+"").trim(); const ch=(lab[0]||"?").toUpperCase();
  let s=0; const src=(h||lab); for(let i=0;i<src.length;i++) s=(src.charCodeAt(i)+((s<<5)-s))|0;
  const bg="hsl("+(Math.abs(s)%360)+",60%,50%)";
  const svg='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32"><rect width="32" height="32" rx="7" fill="'+bg+'"/><text x="16" y="22" font-family="Segoe UI,Arial,sans-serif" font-size="18" font-weight="700" fill="#fff" text-anchor="middle">'+ch+'</text></svg>';
  return '<img class="tool-ico" alt="" src="data:image/svg+xml;utf8,'+encodeURIComponent(svg)+'">';
}
function goMod(k){
  curView=k; const m=MODULES[k];
  showView("view-mod"); renderNav();
  $("model-btn").style.display="none"; $("view-title").style.display="block"; $("view-title").textContent=m.i+" "+m.t;

  let html=`<h3>${m.i} ${m.t}</h3><p class="sub">${m.d}</p>`;

  if(m.special==="prompt") html+=`
    <div class="card" style="margin-bottom:18px"><h4>Tu prompt</h4>
      <div class="qbox"><textarea id="mod-prompt" rows="3" placeholder="${m.promptPh}"></textarea></div>
      <button class="btn dark" onclick="copyPrompt()">📋 Copiar prompt</button><span id="copy-ok" class="copied"></span>
      <div class="note">Copiá el prompt y pegalo en la herramienta que abras abajo. Las marcadas con ⚡ lo reciben directo por URL.</div>
    </div>`;

  if(m.special==="chatlaunch") html+=`
    <div class="card" style="margin-bottom:18px"><h4>Integrado en ARTLAS</h4>
      <p style="font-size:13.5px;margin-bottom:12px">Chat con perfil de ingeniero senior (usa tu API conectada — nivel ${MODELS[m.launchModel].name}).</p>
      <button class="btn dark" onclick="launchModChat('${k}')">${m.launchLabel}</button>
    </div>`;

  if(m.special==="webgen") html+=`
    <div class="card" style="margin-bottom:18px"><h4>Generador integrado (usa tu API conectada)</h4>
      <div class="qbox"><textarea id="web-prompt" rows="2" placeholder="Ej: landing page moderna para una consultora de IA y telecomunicaciones, hero con gradiente, 3 servicios, testimonios y contacto"></textarea></div>
      <button class="btn dark" onclick="genWeb()" id="web-btn">✨ Generar sitio</button>
      <button class="btn" style="margin-left:8px" onclick="downloadWeb()" id="web-dl" disabled>⬇ Descargar HTML</button>
      <div class="note" id="web-note"></div>
      <iframe id="web-preview" sandbox="allow-scripts" style="display:none"></iframe>
    </div>`;

  if(m.special==="kb") html+=`
    <div class="card" style="margin-bottom:18px"><h4>Tus documentos</h4>
      <input type="file" id="kb-file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.md,.json,.log" style="display:none" onchange="kbUpload(this.files)">
      <button class="btn dark" onclick="$('kb-file').click()">⬆ Subir documentos — PDF, Word, Excel, texto (hasta 50 MB)</button>
      <div class="note">Los documentos activados (✓) se inyectan como contexto en el chat. Acepta PDF, Word (.docx), Excel y texto, hasta 50 MB por archivo — el texto se extrae acá mismo, en tu navegador.</div>
      <div id="kb-list" style="margin-top:14px"></div>
    </div>`;

  if(m.special==="research") html+=`
    <div class="card" style="margin-bottom:18px"><h4>Búsqueda académica</h4>
      <div class="qbox"><input type="text" id="res-q" placeholder="Ej: machine learning 5G network optimization" onkeydown="if(event.key==='Enter')openEngine(0)"></div>
      <div class="engines">${ENGINES.map((e,ix)=>`<button class="btn" onclick="openEngine(${ix})">🔎 ${e.n}</button>`).join("")}</div>
      <div class="note">Escribí tu consulta y elegí la base de datos — se abre con la búsqueda ya cargada.</div>
    </div>
    <div class="card" style="margin-bottom:18px"><h4>Integrado en ARTLAS</h4>
      <p style="font-size:13.5px;margin-bottom:12px">Generá estado del arte, marco teórico o comparativas con ARTLAS Deep Research (usa tu API conectada).</p>
      <button class="btn dark" onclick="launchResearch()">🔬 Abrir Deep Research en el Chat</button>
    </div>`;

  if(m.special==="cowork") html+=`
    <div class="card" style="margin-bottom:18px"><h4>Compartir tu trabajo</h4>
      <p style="font-size:13.5px;margin-bottom:12px">Exportá todas tus conversaciones y agentes como archivo JSON para compartir o respaldar, e importá los de tu equipo.</p>
      <button class="btn dark" onclick="exportAll()">⬇ Exportar workspace (JSON)</button>
      <input type="file" id="imp-file" accept=".json" style="display:none" onchange="importAll(this.files[0])">
      <button class="btn" style="margin-left:8px" onclick="$('imp-file').click()">⬆ Importar workspace</button>
      <span id="cowork-msg" class="copied"></span>
    </div>`;

  html+=`<div class="card"><h4>Herramientas externas</h4><div class="tools-grid">`+
    m.tools.map(t=>`<div class="tool-card"><b>${toolIco(t.u,t.n)}${t.q?"⚡ ":""}${t.n}</b><small>${t.d}</small>
      <a class="go" href="#" onclick="openTool('${k}','${t.n.replace(/'/g,"\\'")}');return false">Abrir ↗</a></div>`).join("")+
  `</div></div>`;

  $("mod-inner").innerHTML=html;
  if(m.special==="kb") renderKb();
}

function openTool(modKey,name){
  const t=MODULES[modKey].tools.find(x=>x.n===name); if(!t)return;
  let url=t.u;
  if(t.q){
    const p=$("mod-prompt")?$("mod-prompt").value.trim():($("res-q")?$("res-q").value.trim():"");
    url=t.u.replace("%s",encodeURIComponent(p||""));
    if(!p) url=t.u.replace("%s","");
  }
  window.open(url,"_blank");
}
function copyPrompt(){
  const p=$("mod-prompt").value.trim(); if(!p)return;
  navigator.clipboard.writeText(p).then(()=>{ $("copy-ok").textContent="✓ copiado"; setTimeout(()=>$("copy-ok").textContent="",2000); });
}
function openEngine(ix){
  const q=$("res-q").value.trim(); if(!q)return;
  window.open(ENGINES[ix].u.replace("%s",encodeURIComponent(q)),"_blank");
}
function launchModChat(k){
  const m=MODULES[k];
  curModel=m.launchModel; save();
  goChat(); newChat(); customSys=m.launchSys; inp.placeholder="Chat de código ARTLAS — pegá tu código o describí el problema…"; inp.focus();
}
function launchResearch(){
  customSys=null; curModel="deepresearch"; save(); renderMenu();
  goChat(); newChat(); inp.placeholder="Deep Research — describí tu tema de investigación…"; inp.focus();
}

/* ---------- Web generator ---------- */
let lastWebHtml=null;
async function genWeb(){
  const p=$("web-prompt").value.trim(); if(!p)return;
  const m=MODELS[curModel], pk=connected(m.prov)?m.prov:(["anthropic","openai","gemini","groq","hf","ollama","basic"].find(connected)||null);
  $("web-btn").disabled=true; $("web-note").textContent="Generando…";
  try{
    let html;
    if(pk){
      html=await callProvider(pk,cfg[pk],[{role:"user",content:"Generá una página web sobre: "+p}],
        "Sos un diseñador web experto. Devolvé ÚNICAMENTE un documento HTML completo (<!DOCTYPE html>…), con CSS embebido moderno y responsive. Sin explicaciones ni markdown, solo el código HTML.",[],pk==="groq"?5500:8000);
      html=html.replace(/^```html?\n?/,"").replace(/```\s*$/,"");
    }else{
      html=`<!DOCTYPE html><html><body style="font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;background:#f4f6f8"><div style="text-align:center;max-width:420px"><h2>Modo simulado</h2><p>Conectá una API key (⚙️) y ARTLAS generará acá un sitio real sobre:</p><p><b>${esc(p)}</b></p></div></body></html>`;
    }
    lastWebHtml=html;
    const f=$("web-preview"); f.style.display="block"; f.srcdoc=html;
    $("web-dl").disabled=false;
    $("web-note").textContent = pk?`Generado con ${PROVIDERS[pk].label} · ${provModel(pk)}. Podés descargarlo y subirlo a Netlify.`:"Vista simulada — conectá una API para generación real.";
  }catch(e){ $("web-note").textContent="⚠️ Error: "+(e.message||e); }
  $("web-btn").disabled=false;
}
function downloadWeb(){
  if(!lastWebHtml)return;
  const blob=new Blob([lastWebHtml],{type:"text/html"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="sitio-atlas.html"; a.click();
}

/* ---------- Knowledge base (IndexedDB, hasta 50 MB por documento) ---------- */
function idbOpen(){ return new Promise((res,rej)=>{ const r=indexedDB.open("atlas",3); r.onupgradeneeded=()=>{ const db=r.result; ["kb","agents","artifacts"].forEach(s=>{ if(!db.objectStoreNames.contains(s))db.createObjectStore(s,{keyPath:"name"}); }); }; r.onsuccess=()=>res(r.result); r.onerror=()=>rej(r.error); }); }
async function kbPut(doc){ const d=await idbOpen(); return new Promise((res,rej)=>{ const tx=d.transaction("kb","readwrite"); tx.objectStore("kb").put(doc); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
async function kbRemove(name){ const d=await idbOpen(); return new Promise((res,rej)=>{ const tx=d.transaction("kb","readwrite"); tx.objectStore("kb").delete(name); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
async function kbLoadAll(){ const d=await idbOpen(); return new Promise((res,rej)=>{ const rq=d.transaction("kb").objectStore("kb").getAll(); rq.onsuccess=()=>res(rq.result||[]); rq.onerror=()=>rej(rq.error); }); }
async function kbInit(){
  try{ const old=JSON.parse(localStorage.getItem("atlas_kb")||"[]"); if(old.length){ for(const doc of old) await kbPut(doc); localStorage.removeItem("atlas_kb"); } }catch(e){}
  try{ kb=await kbLoadAll(); }catch(e){ kb=[]; }
  renderKb(); updKbBadge();
}
function kbToggle(ix){ kb[ix].on=!kb[ix].on; kbPut(kb[ix]); renderKb(); updKbBadge(); }
function kbDel(ix){ const d=kb.splice(ix,1)[0]; if(d)kbRemove(d.name); renderKb(); updKbBadge(); }
function kbUpload(files){
  [...files].forEach(f=>{
    if(f.size>50*1024*1024){ alert(f.name+" supera 50 MB."); return; }
    const doc={name:f.name,size:f.size,text:"",on:true,status:"⏳"};
    kb.push(doc); renderKb();
    extractText(f).then(t=>{ doc.text=t.slice(0,1500000); delete doc.status; kbPut(doc); renderKb(); updKbBadge(); })
      .catch(e=>{ const ix=kb.indexOf(doc); if(ix>=0)kb.splice(ix,1); renderKb(); alert("No pude leer "+f.name+": "+(e.message||e)); });
  });
}
function renderKb(){
  const el=$("kb-list"); if(!el)return;
  el.innerHTML = kb.length? kb.map((d,ix)=>`<div class="kb-item">
    <span class="chk ${d.on?"on":""}" onclick="kbToggle(${ix})">${d.status?d.status+" leyendo":(d.on?"✓ activo":"inactivo")}</span>
    <span class="nm">📄 ${esc(d.name)}</span><small>${d.size>1048576?(d.size/1048576).toFixed(1)+" MB":(d.size/1024).toFixed(1)+" KB"}</small>
    <button class="btn" style="padding:4px 10px;font-size:11px" onclick="kbDel(${ix})">✕</button></div>`).join("")
    : `<div class="note">Todavía no subiste documentos.</div>`;
}
function kbSys(maxChars){
  const act=kb.filter(d=>d.on); if(!act.length)return null;
  let ctx="Base de conocimiento del usuario (usala para responder cuando sea relevante):\n";
  let budget=maxChars||60000;
  act.forEach(d=>{ const t=d.text.slice(0,Math.max(0,budget)); budget-=t.length; ctx+=`\n--- ${d.name} ---\n${t}\n`; });
  return ctx;
}
function updKbBadge(){
  const n=kb.filter(d=>d.on).length;
  const b=$("kb-badge");
  b.style.display=n?"block":"none";
  b.textContent=n?`📚 ${n} documento${n>1?"s":""} de Knowledge activo${n>1?"s":""} en este chat`:"";
}

/* ---------- Cowork ---------- */
function exportAll(){
  const data={plataforma:"ARTLAS",fecha:new Date().toISOString(),chats,agents,flows,kb:kb.map(d=>({name:d.name,size:d.size,on:d.on,text:d.text}))};
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="atlas-workspace.json"; a.click();
  $("cowork-msg").textContent="✓ exportado"; setTimeout(()=>$("cowork-msg").textContent="",2500);
}
function importAll(f){
  if(!f)return;
  const r=new FileReader();
  r.onload=()=>{ try{
    const d=JSON.parse(r.result);
    if(d.chats) chats=[...d.chats,...chats];
    if(d.agents){ agents=[...d.agents,...agents]; agents.forEach(a=>{ try{agentPut(a);}catch(e){} }); }
    if(d.kb) kb=[...d.kb,...kb];
    if(d.flows){ flows=[...d.flows,...flows]; wfSaveLS(); try{renderFlows();}catch(e){} }
    save(); renderChats(); renderAgents(); updKbBadge();
    $("cowork-msg").textContent="✓ importado: "+(d.chats?d.chats.length:0)+" chats"; setTimeout(()=>$("cowork-msg").textContent="",3000);
  }catch(e){ $("cowork-msg").textContent="✗ archivo inválido"; } };
  r.readAsText(f);
}

/* ================= MODEL MENU ================= */
function renderMenu(){
  $("model-menu").innerHTML = Object.entries(MODELS).map(([k,m])=>{
    const on=connected(m.prov);
    return `<div class="m-item ${k===curModel?"sel":""}" onclick="pickModel('${k}')">
      <div class="info"><b><span class="st ${on?"on":"off"}"></span>${m.name} <span class="prov-chip">${PROVIDERS[m.prov].label}</span></b>
      <small>${m.desc} · ${on?"conectado — "+provModel(m.prov):"modo simulado (configurar API)"}</small></div>
      <span class="check">✓</span></div>`;
  }).join("") + `<div class="m-item" onclick="openSettings()"><div class="info"><b>🔑 Conectar APIs…</b><small>Configurá tus claves de OpenAI, Gemini, Anthropic u Ollama</small></div></div>`;
  const m=MODELS[curModel], on=connected(m.prov);
  $("model-name").textContent=m.name;
  if(routeMode==="multi"||routeMode==="forest"){
    const n=taskCount();
    $("conn-badge").innerHTML=`<span class="st ${n>1?"on":"off"}"></span>${routeMode==="multi"?"⚡ Simultáneo":"🌳 Consenso"} · ${n} modelo${n>1?"s":""} en paralelo`;
  }else{
    $("conn-badge").innerHTML=`<span class="st ${on?"on":"off"}"></span>${on?PROVIDERS[m.prov].label+" · "+provModel(m.prov):"Simulado — sin API key"}`;
  }
  $("empty-sub").textContent = on ? `Conectado a ${PROVIDERS[m.prov].label} (${provModel(m.prov)}). Tus mensajes van directo a la API.`
    : "Estás en modo simulado. Tocá ⚙️ para conectar tus API keys de OpenAI, Gemini, Claude u Ollama.";
  const gm=$("g-model"); if(gm&&!gm.options.length) gm.innerHTML=Object.entries(MODELS).map(([k,mm])=>`<option value="${k}" ${k==="dense"?"selected":""}>${mm.name} (${PROVIDERS[mm.prov].label})</option>`).join("");
}
function toggleMenu(e){ e.stopPropagation(); const rm=$("route-menu"); if(rm)rm.classList.remove("open"); $("model-menu").classList.toggle("open"); }
document.addEventListener("click",()=>$("model-menu").classList.remove("open"));
function pickModel(k){ curModel=k; save(); renderMenu(); $("model-menu").classList.remove("open"); pushCloud(); }

/* ================= SETTINGS ================= */
function provCard(k,p){
  const c=cfg[k]||{};
  const head=`<div class="prov-head"><b>${p.icon} ${p.label}</b>
    <span><button class="test-btn" onclick="testProv('${k}')">Probar conexión</button><span class="test-res" id="tr-${k}"></span></span></div>`;
  if(k==="basic") return `<div class="prov-card" style="border-color:#bfe6d8;background:#fbfefd">${head}
    <div class="prov-grid">
      <div><label>Estado</label><div style="font-size:13px;padding:8px 2px;color:var(--green);font-weight:600">● Activo por defecto — no requiere API key</div></div>
      <div><label>Modelo</label><select id="mod-basic" style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:13px">
        ${BASIC_MODELS.map(([v,l])=>`<option value="${v}" ${(c.model||"openai")===v?"selected":""}>${l}</option>`).join("")}</select></div>
    </div>
    <div style="margin-top:12px;font-size:12px;line-height:2"><b>En Simultáneo / Consenso usar (modelos gratis, sin API key):</b>
      <span style="color:var(--amber)"> — poné el 🧭 Ruteo (arriba) en Simultáneo o Consenso.</span><br>
      ${BASIC_MODELS.map(([v,l])=>`<label style="display:inline-block;margin-right:12px;white-space:nowrap"><input type="checkbox" class="bs-multi" value="${v}" ${((c.multi&&c.multi.length?c.multi:[c.model||"openai"]).includes(v))?"checked":""} onchange="basicSyncMulti()"> ${l}</label>`).join("")}
    </div>
    <div class="prov-note">${i18nNote(k,p.note)}</div></div>`;
  if(k==="groq") return `<div class="prov-card">${head}
    <div class="prov-grid">
      <div><label>Groq API Key (gsk_…)</label><input id="key-groq" type="password" autocomplete="new-password" spellcheck="false" data-lpignore="true" data-1p-ignore data-form-type="other" placeholder="gsk_…" value="${c.key||""}"></div>
      <div><label>Modelo</label><select id="mod-groq" style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:13px">
        ${GROQ_MODELS.map(([v,l])=>`<option value="${v}" ${(c.model||"openai/gpt-oss-120b")===v?"selected":""}>${l}</option>`).join("")}</select></div>
    </div>
    <div style="margin-top:10px;font-size:12px;line-height:2"><b>En Simultáneo / Consenso usar:</b><br>
      ${GROQ_MODELS.map(([v,l])=>`<label style="margin-right:12px;white-space:nowrap"><input type="checkbox" class="gq-multi" value="${v}" ${(c.multi&&c.multi.length?c.multi:[c.model||"openai/gpt-oss-120b"]).includes(v)?"checked":""}> ${l}</label>`).join("")}
    </div>
    <div style="display:flex;gap:18px;flex-wrap:wrap;margin-top:12px;font-size:12px;align-items:center">
      <label style="display:flex;align-items:center;gap:6px">🌡 Temp <input type="range" id="groq-temp" min="0" max="2" step="0.1" value="${c.temp??0.7}" oninput="$('groq-temp-v').textContent=this.value"><b id="groq-temp-v">${c.temp??0.7}</b></label>
      <label style="display:flex;align-items:center;gap:6px">✍ Tokens <input type="range" id="groq-tokens" min="100" max="4000" step="50" value="${c.tokens??1024}" oninput="$('groq-tokens-v').textContent=this.value"><b id="groq-tokens-v">${c.tokens??1024}</b></label>
      <label style="display:flex;align-items:center;gap:6px">🎯 Top-p <input type="range" id="groq-topp" min="0.1" max="1" step="0.05" value="${c.topp??0.9}" oninput="$('groq-topp-v').textContent=this.value"><b id="groq-topp-v">${c.topp??0.9}</b></label>
    </div>
    <div class="prov-note">${i18nNote(k,p.note)}</div></div>`;
  if(k==="other"){
    const isOR=(c.preset||"deepseek")==="openrouter";
    const list=orModelList();
    const selVal=c.model||"";
    const orSelect=isOR?`<div class="field" style="margin-bottom:10px"><label>Elegí el LLM (una sola API key)
        <button type="button" class="test-btn" style="margin-left:8px;padding:2px 8px" onclick="orFetchModels(event)">🔄 Actualizar lista</button></label>
      <select id="or-sel" style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:13px" onchange="orPickModel(this.value)">
        ${list.map(([v,l])=>`<option value="${v}" ${selVal===v?"selected":""}>${l}</option>`).join("")}
      </select></div>`:"";
    const orMulti=isOR?`<div style="margin-top:12px;font-size:12px;line-height:2"><b>En Simultáneo / Consenso usar (varios modelos con la misma key):</b>
      <span style="color:var(--amber)"> — recordá poner el 🧭 Ruteo (arriba) en <b>Simultáneo</b> o <b>Consenso</b> para que respondan varios.</span><br>
      ${list.map(([v,l])=>`<label style="display:inline-block;margin-right:12px;white-space:nowrap"><input type="checkbox" class="or-multi" value="${v}" ${((c.multi&&c.multi.length?c.multi:[selVal]).includes(v))?"checked":""} onchange="orSyncMulti()"> ${l}</label>`).join("")}
      </div>`:"";
    return `<div class="prov-card" id="card-other">${head}
    <div class="field" style="margin-bottom:10px"><label>Proveedor (preset)</label>
      <select id="other-preset" style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:13px" onchange="otherPreset(this.value)">
        ${Object.entries(OTHER_PRESETS).map(([v,pp])=>`<option value="${v}" ${(c.preset||"deepseek")===v?"selected":""}>${pp.label}</option>`).join("")}
      </select></div>
    ${orSelect}
    <div class="prov-grid">
      <div><label>URL base (OpenAI-compatible)</label><input id="url-other" type="text" placeholder="https://api.deepseek.com/v1" value="${c.url||""}"></div>
      <div><label>Modelo${isOR?" (editable)":""}</label><input id="mod-other" type="text" placeholder="deepseek-chat" value="${c.model||""}" oninput="cfg.other=cfg.other||{};cfg.other.model=this.value;save()"></div>
    </div>
    <div class="prov-grid" style="margin-top:10px">
      <div><label>API key</label><input id="key-other" type="password" autocomplete="new-password" spellcheck="false" data-lpignore="true" data-1p-ignore data-form-type="other" placeholder="sk-…" value="${c.key||""}"></div>
      <div></div>
    </div>
    ${orMulti}
    <div class="prov-note">${i18nNote(k,p.note)}</div></div>`;
  }
  if(k==="hf"){
    const list=hfModelList();
    const selVal=c.model||"";
    return `<div class="prov-card" id="card-hf">${head}
    <div class="field" style="margin-bottom:10px"><label>Elegí el modelo
        <button type="button" class="test-btn" style="margin-left:8px;padding:2px 8px" onclick="hfFetchModels(event)">🔄 Actualizar lista</button></label>
      <select id="hf-sel" style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:13px" onchange="hfPickModel(this.value)">
        ${list.map(([v,l])=>`<option value="${v}" ${selVal===v?"selected":""}>${l}</option>`).join("")}
      </select></div>
    <div class="prov-grid">
      <div><label>API key (token HF)</label><input id="key-hf" type="password" autocomplete="new-password" spellcheck="false" data-lpignore="true" data-1p-ignore data-form-type="other" placeholder="hf_…" value="${c.key||""}"></div>
      <div><label>Modelo (editable)</label><input id="mod-hf" type="text" placeholder="${p.defModel}" value="${c.model||""}" oninput="cfg.hf=cfg.hf||{};cfg.hf.model=this.value;save()"></div>
    </div>
    <div class="prov-note">${i18nNote(k,p.note)}</div></div>`;
  }
  if(typeof OA_PROVIDERS!=="undefined" && OA_PROVIDERS[k]){
    const list=oaModelList(k); const selVal=c.model||PROVIDERS[k].defModel;
    return `<div class="prov-card" id="card-${k}">${head}
    <div class="prov-grid">
      <div><label>API key</label><input id="key-${k}" type="password" autocomplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" placeholder="${PROVIDERS[k].keyPh}" value="${c.key||""}"></div>
      <div><label>Modelo <button type="button" class="test-btn" style="margin-left:6px;padding:2px 8px" onclick="oaRefreshModels('${k}')">🔄 Actualizar lista</button></label>
        <select id="mod-${k}" style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:13px">
        ${list.map(([v,l])=>`<option value="${v}" ${selVal===v?"selected":""}>${l}</option>`).join("")}</select></div>
    </div>
    <span class="test-res" id="oa-st-${k}" style="font-size:11px"></span>
    <div class="prov-note">${i18nNote(k,p.note)}</div></div>`;
  }
  if(k==="webllm"){
    const list=webllmModelList(); const selVal=(c.model)||"Qwen2.5-1.5B-Instruct-q4f16_1-MLC"; const gpu=("gpu" in navigator);
    return `<div class="prov-card" id="card-webllm">${head}
    <div class="field" style="margin-bottom:10px"><label>Modelo a descargar (corre en tu navegador) <button type="button" class="test-btn" style="margin-left:8px;padding:2px 8px" onclick="webllmRefreshList()">🔄 Actualizar lista</button></label>
      <select id="webllm-model" onchange="cfg.webllm=cfg.webllm||{};cfg.webllm.model=this.value;save()" style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:8px 10px;font-size:13px">
        ${list.map(([v,l])=>`<option value="${v}" ${selVal===v?"selected":""}>${l}</option>`).join("")}
      </select></div>
    <button class="btn dark" onclick="webllmLoad()">⬇ Descargar / cargar modelo local</button>
    <button class="btn" style="margin-left:8px" onclick="webllmClearCache()">🗑 Borrar caché del modelo</button>
    <span class="test-res" id="webllm-status" style="margin-left:8px">${webllmReady?("✓ listo — "+(webllmModel||"")):(gpu?"sin cargar":"⚠ tu navegador no tiene WebGPU")}</span>
    <div class="prov-note">${i18nNote(k,p.note)}</div></div>`;
  }
  return `<div class="prov-card">${head}
    <div class="prov-grid">
      <div><label>${k==="ollama"?"URL del servidor":"API key"}</label>
        <input id="key-${k}" type="${k==="ollama"?"text":"password"}" autocomplete="new-password" spellcheck="false" data-lpignore="true" data-1p-ignore data-form-type="other" placeholder="${k==="ollama"?"http://localhost:11434":p.keyPh}" value="${k==="ollama"?(c.url||""):(c.key||"")}"></div>
      <div><label>Modelo</label><input id="mod-${k}" type="text" placeholder="${p.defModel}" value="${c.model||""}"></div>
    </div>
    <div class="prov-note">${i18nNote(k,p.note)}</div></div>`;
}
function syncOtherFromDOM(){
  cfg.other=cfg.other||{};
  const u=$("url-other"),m=$("mod-other"),k=$("key-other"),ps=$("other-preset");
  if(u)cfg.other.url=u.value.trim(); if(m)cfg.other.model=m.value.trim();
  if(k)cfg.other.key=k.value.trim(); if(ps)cfg.other.preset=ps.value;
  if(document.querySelector(".or-multi"))
    cfg.other.multi=[...document.querySelectorAll(".or-multi:checked")].map(x=>x.value);
}
function rerenderOther(){ const h=$("card-other"); if(h) h.outerHTML=provCard("other",PROVIDERS.other); }
function orPickModel(v){
  cfg.other=cfg.other||{}; cfg.other.model=v;
  const t=$("mod-other"); if(t)t.value=v;
  save(); renderMenu();
}
function orSyncMulti(){
  cfg.other=cfg.other||{};
  cfg.other.multi=[...document.querySelectorAll(".or-multi:checked")].map(x=>x.value);
  save(); renderMenu();
}
function rerenderHf(){ const h=$("card-hf"); if(h) h.outerHTML=provCard("hf",PROVIDERS.hf); }
function hfPickModel(v){
  cfg.hf=cfg.hf||{}; cfg.hf.model=v;
  const t=$("mod-hf"); if(t)t.value=v;
  save(); renderMenu();
}
async function hfFetchModels(ev){
  const btn=ev&&ev.target; if(btn){ btn.textContent="⏳ cargando…"; btn.disabled=true; }
  cfg.hf=cfg.hf||{};
  const kf=$("key-hf"),mf=$("mod-hf"); if(kf)cfg.hf.key=kf.value.trim(); if(mf)cfg.hf.model=mf.value.trim();
  try{
    const h={}; if(cfg.hf.key) h["Authorization"]="Bearer "+cfg.hf.key;
    const r=await fetch("https://router.huggingface.co/v1/models",{headers:h});
    const j=await r.json();
    HF_LIVE=(j.data||[]).map(m=>[m.id,m.id]).sort((a,b)=>a[1].localeCompare(b[1]));
    if(!HF_LIVE.length) throw new Error("respuesta vacía");
    localStorage.setItem("atlas_hf_models",JSON.stringify(HF_LIVE));
    rerenderHf();
  }catch(e){
    alert("No se pudo actualizar la lista de Hugging Face: "+(e.message||e)+"\nSe mantiene la lista actual.");
    if(btn){ btn.textContent="🔄 Actualizar lista"; btn.disabled=false; }
  }
}
function otherPreset(v){
  syncOtherFromDOM();
  const p=OTHER_PRESETS[v]; cfg.other.preset=v;
  if(p){ cfg.other.url=p.url; cfg.other.model=p.model; }
  rerenderOther();
}
async function orFetchModels(ev){
  const btn=ev&&ev.target; if(btn){ btn.textContent="⏳ cargando…"; btn.disabled=true; }
  syncOtherFromDOM();
  try{
    const r=await fetch("https://openrouter.ai/api/v1/models");
    const j=await r.json();
    OR_LIVE=(j.data||[]).map(m=>[m.id,(m.name||m.id)+(m.pricing&&(+m.pricing.prompt===0)?" · gratis":"")])
                        .sort((a,b)=>a[1].localeCompare(b[1]));
    if(!OR_LIVE.length) throw new Error("respuesta vacía");
    localStorage.setItem("atlas_or_models",JSON.stringify(OR_LIVE));
    rerenderOther();
  }catch(e){
    alert("No se pudo actualizar la lista de OpenRouter: "+(e.message||e)+"\nSe mantiene la lista actual.");
    if(btn){ btn.textContent="🔄 Actualizar lista"; btn.disabled=false; }
  }
}
function openSettings(){
  $("model-menu").classList.remove("open");
  $("prov-list").innerHTML = Object.entries(PROVIDERS).map(([k,p])=>provCard(k,p)).join("");
  $("overlay").classList.add("open");
}
function closeSettings(){ $("overlay").classList.remove("open"); }
function saveSettings(){
  const prevConn=connectedProviders();
  Object.keys(PROVIDERS).forEach(k=>{
    cfg[k]=cfg[k]||{};
    if(k==="basic"){ cfg[k].model=$("mod-basic").value; cfg[k].multi=[...document.querySelectorAll(".bs-multi:checked")].map(x=>x.value); return; }
    if(k==="other"){ cfg[k].preset=$("other-preset").value; cfg[k].url=$("url-other").value.trim();
      cfg[k].key=$("key-other").value.trim(); cfg[k].model=$("mod-other").value.trim();
      cfg[k].multi=[...document.querySelectorAll(".or-multi:checked")].map(x=>x.value); return; }
    if(k==="groq"){ cfg[k].key=$("key-groq").value.trim(); cfg[k].model=$("mod-groq").value;
      cfg[k].temp=+$("groq-temp").value; cfg[k].tokens=+$("groq-tokens").value; cfg[k].topp=+$("groq-topp").value;
      cfg[k].multi=[...document.querySelectorAll(".gq-multi:checked")].map(x=>x.value); return; }
    if(k==="webllm"){ const s=$("webllm-model"); if(s)cfg[k].model=s.value; return; }
    const v=$("key-"+k).value.trim(), m=$("mod-"+k).value.trim();
    if(k==="ollama"){ cfg[k].url=v; cfg[k].enabled=!!v; } else cfg[k].key=v;
    cfg[k].model=m||undefined;
  });
  const nowConn=connectedProviders();
  const nuevos=nowConn.filter(p=>!prevConn.includes(p)&&p!=="basic");
  if(nuevos.length&&(MODELS[curModel].prov==="basic"||!connected(MODELS[curModel].prov))){ curModel=levelOf(nuevos[0]); }
  save(); renderMenu(); if(curView==="arch")renderArch(); closeSettings(); pushCloud();
}
async function testProv(k){
  const r=$("tr-"+k); r.textContent="probando…"; r.style.color="var(--muted)";
  const tmp={...(cfg[k]||{})};
  if(k==="webllm"){ r.textContent=webllmReady?"✓ modelo cargado":"cargá el modelo con el botón"; r.style.color=webllmReady?"var(--green)":"var(--muted)"; return; }
  if(k==="basic"){ tmp.model=$("mod-basic").value; }
  else if(k==="other"){ tmp.url=$("url-other").value.trim(); tmp.key=$("key-other").value.trim(); tmp.model=$("mod-other").value.trim(); }
  else if(k==="groq"){ tmp.key=$("key-groq").value.trim(); tmp.model=$("mod-groq").value; }
  else if(k==="ollama"){ tmp.url=$("key-"+k).value.trim()||"http://localhost:11434"; tmp.enabled=true; tmp.model=$("mod-"+k).value.trim()||PROVIDERS[k].defModel; }
  else { tmp.key=$("key-"+k).value.trim(); tmp.model=$("mod-"+k).value.trim()||PROVIDERS[k].defModel; }
  try{ await callProvider(k,tmp,[{role:"user",content:"Respondé solo: OK"}],null);
    r.textContent="✓ conectado"; r.style.color="var(--green)";
  }catch(e){ r.textContent="✗ "+(e.message||"error").toString().slice(0,60); r.style.color="var(--red)"; }
}

/* ================= CHATS ================= */
function renderChats(){
  $("chat-list").innerHTML=chats.map(c=>`<div class="chat-item ${c.id===curId?"active":""}" onclick="goChat();openChat('${c.id}')">
    <span style="overflow:hidden;text-overflow:ellipsis">${esc(c.title)}</span><span class="del" onclick="event.stopPropagation();delChat('${c.id}')">✕</span></div>`).join("");
}
function newChat(){ curId=null; customSys=null; $("inp").placeholder="Escribí un mensaje a AR.T.L.A.S.…"; $("msgs").style.display="none"; $("msgs").innerHTML=""; $("empty").style.display="flex"; renderChats(); $("inp").focus(); }
function openChat(id){ curId=id; customSys=null; $("inp").placeholder="Escribí un mensaje a AR.T.L.A.S.…"; renderChats(); renderMsgs(); }
function delChat(id){ chats=chats.filter(c=>c.id!==id); if(curId===id)newChat(); save(); renderChats(); }
function renderMsgs(){
  const c=cur(); if(!c)return;
  $("empty").style.display="none"; $("msgs").style.display="flex";
  $("msgs").innerHTML=""; c.msgs.forEach(m=>addRow(m.role,m.content,m.meta));
  scrollDown();
}

/* ================= RENDER MENSAJES ================= */
function md(t){
  t=t.replace(/&/g,"&amp;").replace(/</g,"&lt;");
  t=t.replace(/```(\w*)\n?([\s\S]*?)```/g,(_,l,c)=>`<pre><code>${c}</code></pre>`);
  t=t.replace(/`([^`]+)`/g,"<code>$1</code>");
  t=t.replace(/\*\*([^*]+)\*\*/g,"<b>$1</b>");
  return t;
}
function addRow(role,content,meta){
  const d=document.createElement("div"); d.className="row "+(role==="user"?"user":"bot");
  if(role==="user") d.innerHTML=`<div class="content">${md(content)}</div>`;
  else d.innerHTML=`<div class="avatar">A</div><div class="body">
      <div class="who">AR.T.L.A.S. <span class="via">${meta||""}</span></div>
      <div class="content">${md(content)}</div></div>`;
  $("msgs").appendChild(d); return d;
}
function scrollDown(){ $("scroll").scrollTop=$("scroll").scrollHeight; }

/* ================= INPUT ================= */
const inp=$("inp");
inp.addEventListener("input",()=>{ inp.style.height="auto"; inp.style.height=Math.min(inp.scrollHeight,180)+"px"; suggest(); });
inp.addEventListener("keydown",e=>{ if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();} });
function useStarter(b){ inp.value=b.textContent.trim(); send(); }
function suggest(){
  const t=inp.value.toLowerCase(); let s=null;
  if(/investig|paper|scopus|arxiv|estado del arte/.test(t)) s="deepresearch";
  else if(/arquitectura|complejo|optimiz|demostr|evalu/.test(t)) s="deepthink";
  else if(/código|codigo|script|python|sql|debug/.test(t)) s="thinking";
  else if(/resum|qué es|que es|rápid|definí/.test(t)) s="fast";
  const el=$("sugg");
  if(s&&s!==curModel){ el.style.display="block"; el.innerHTML=`💡 Sugerencia del orquestador: <span onclick="pickModel('${s}');this.parentElement.style.display='none'">${MODELS[s].name}</span> es ideal para esta tarea.`; }
  else el.style.display="none";
}

/* ================= MENÚ ＋ / ADJUNTOS / VOZ ================= */
let atts=[], webMode=false, rec=null;
function togglePlus(e){ e.stopPropagation(); $("plus-menu").classList.toggle("open"); }
document.addEventListener("click",()=>{ const pm=$("plus-menu"); if(pm)pm.classList.remove("open"); });
function pmAttach(){ $("att-file").click(); }
function pmWeb(){ webMode=!webMode; renderMode(); inp.focus(); }
function pmDeep(){ curModel="deepresearch"; save(); renderMenu(); inp.placeholder="Investigar a fondo — describí tu tema…"; inp.focus(); }
function pmGitHub(){ const q=inp.value.trim(); window.open(q?"https://github.com/search?q="+encodeURIComponent(q)+"&type=repositories":"https://github.com","_blank"); }
function renderMode(){
  $("mode-row").innerHTML = webMode?`<span class="mode-chip">🌐 Búsqueda web activada — al enviar se abre tu consulta en el buscador <span class="x" onclick="webMode=false;renderMode()">✕</span></span>`:"";
}
function loadScript(src){ return new Promise((res,rej)=>{ if(document.querySelector('script[src="'+src+'"]'))return res(); const s=document.createElement("script"); s.src=src; s.onload=res; s.onerror=()=>rej(new Error("No se pudo cargar la librería (verificá tu conexión)")); document.head.appendChild(s); }); }
async function extractText(f){
  const ext=(f.name.split(".").pop()||"").toLowerCase();
  if(["txt","md","csv","json","log","xml","html"].includes(ext)) return await f.text();
  if(ext==="pdf"){
    await loadScript("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js");
    window.pdfjsLib.GlobalWorkerOptions.workerSrc="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
    const pdf=await window.pdfjsLib.getDocument({data:await f.arrayBuffer()}).promise;
    let out=""; const n=Math.min(pdf.numPages,400);
    for(let i=1;i<=n;i++){ const pg=await pdf.getPage(i); const tc=await pg.getTextContent(); out+=tc.items.map(it=>it.str).join(" ")+"\n"; if(out.length>1500000)break; }
    if(!out.trim()) throw new Error("el PDF no tiene texto extraíble (parece escaneado)");
    return out;
  }
  if(ext==="docx"||ext==="doc"){
    await loadScript("https://cdn.jsdelivr.net/npm/mammoth@1.6.0/mammoth.browser.min.js");
    const r=await window.mammoth.extractRawText({arrayBuffer:await f.arrayBuffer()});
    if(!r.value||!r.value.trim()) throw new Error("no pude extraer texto (si es .doc viejo, guardalo como .docx)");
    return r.value;
  }
  if(ext==="xlsx"||ext==="xls"){
    await loadScript("https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js");
    const wb=window.XLSX.read(await f.arrayBuffer(),{type:"array"});
    let out=""; wb.SheetNames.forEach(sn=>{ out+="### Hoja: "+sn+"\n"+window.XLSX.utils.sheet_to_csv(wb.Sheets[sn])+"\n\n"; });
    return out;
  }
  return await f.text();
}
function attAdd(files){
  [...files].forEach(f=>{
    if(atts.length>=5){ alert("Máximo 5 adjuntos por mensaje."); return; }
    if(f.type.startsWith("image/")){
      if(f.size>5*1024*1024){ alert(f.name+": máximo 5 MB por imagen."); return; }
      const r=new FileReader(); r.onload=()=>{ atts.push({kind:"img",name:f.name,dataUrl:r.result,mime:f.type}); renderAtts(); }; r.readAsDataURL(f);
    }else{
      if(f.size>10*1024*1024){ alert(f.name+": máximo 10 MB por documento en el chat. Para archivos más grandes usá el módulo Knowledge (hasta 50 MB)."); return; }
      const chip={kind:"txt",name:f.name,text:"",status:"⏳"};
      atts.push(chip); renderAtts();
      extractText(f).then(t=>{ chip.text=t.slice(0,200000); chip.status=""; renderAtts(); })
        .catch(e=>{ const ix=atts.indexOf(chip); if(ix>=0)atts.splice(ix,1); renderAtts(); alert("No pude leer "+f.name+": "+(e.message||e)); });
    }
  });
  $("att-file").value="";
}
function renderAtts(){
  $("att-row").innerHTML=atts.map((a,ix)=>`<span class="att-chip">${a.kind==="img"?`<img src="${a.dataUrl}">`:"📄"} ${esc(a.name)}${a.status?" "+a.status:""} <span class="x" onclick="atts.splice(${ix},1);renderAtts()">✕</span></span>`).join("");
}
function toggleMic(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){ alert("Tu navegador no soporta dictado por voz. Probá con Chrome o Edge."); return; }
  if(rec){ rec.stop(); return; }
  rec=new SR(); rec.lang=(typeof atlasLang!=="undefined"&&atlasLang==="en")?"en-US":"es-AR"; rec.interimResults=true; rec.continuous=true;
  const base=inp.value?inp.value+" ":"";
  $("mic").classList.add("rec");
  rec.onresult=e=>{ let t=""; for(const r of e.results) t+=r[0].transcript; inp.value=base+t; };
  rec.onerror=()=>{};
  rec.onend=()=>{ $("mic").classList.remove("rec"); rec=null; inp.focus(); };
  rec.start();
}

/* ================= RUTEO ================= */
const ROUTES={
  single:{ic:"🎯",name:"Único",desc:"Responde solo el modelo seleccionado arriba"},
  smart:{ic:"🧭",name:"Inteligente",desc:"El orquestador elige el mejor LLM según tu consulta y la métrica elegida"},
  multi:{ic:"⚡",name:"Simultáneo",desc:"Hasta 3 LLMs conectadas responden en paralelo, una debajo de otra"},
  forest:{ic:"🌳",name:"Consenso (Random Forest)",desc:"Varias LLMs responden y otra sintetiza la mejor respuesta de consenso"}
};
let routeMode=localStorage.getItem("atlas_route")||"single";
if(!ROUTES[routeMode])routeMode="single";
let routeMetric=localStorage.getItem("atlas_metric")||"equilibrio";
function renderRoute(){
  $("route-name").textContent=ROUTES[routeMode].name.split(" ")[0];
  $("route-menu").innerHTML="<div style=\"padding:8px 12px 2px;font-weight:700;font-size:13px\">Selección de ruteo</div>"+
    Object.entries(ROUTES).map(([k,r])=>`<div class="m-item ${k===routeMode?"sel":""}" onclick="pickRoute('${k}')"><div class="info"><b>${r.ic} ${r.name}</b><small>${r.desc}</small></div><span class="check">✓</span></div>`).join("")+
    `<div style="border-top:1px solid var(--border);margin:6px 4px 0;padding:10px 12px;font-size:12px"><b>Métrica del ruteo inteligente:</b><br>`+
    ["velocidad","equilibrio","calidad"].map(m=>`<label style="margin-right:14px"><input type="radio" name="rmetric" ${routeMetric===m?"checked":""} onclick="setMetric('${m}')"> ${m}</label>`).join("")+`</div>`;
}
function setMetric(m){ routeMetric=m; localStorage.setItem("atlas_metric",m); pushCloud(); }
function toggleRoute(e){ e.stopPropagation(); $("model-menu").classList.remove("open"); $("route-menu").classList.toggle("open"); renderRoute(); }
document.addEventListener("click",e=>{ const rm=$("route-menu"); if(rm&&!rm.contains(e.target))rm.classList.remove("open"); });
function pickRoute(k){ routeMode=k; localStorage.setItem("atlas_route",k); renderRoute(); renderMenu(); $("route-menu").classList.remove("open"); pushCloud(); }
function errHint(pk, emsg){
  emsg=(emsg||"")+"";
  const lbl=(typeof PROVIDERS!=="undefined"&&PROVIDERS[pk]&&PROVIDERS[pk].label)||"este proveedor";
  if(/insufficient\s*balance|insufficient_quota|insufficient funds|no balance|arrears|exceeded your current quota|payment required|paid subscription|subscription is required|requires? a paid|paid plan|billing/i.test(emsg))
    return "\n\n\ud83d\udca1 Tu cuenta de "+lbl+" no tiene saldo (su API es paga). Cargá crédito, o probá el modelo equivalente GRATIS en OpenRouter (preset OpenRouter, modelos «:free») o en Groq (Llama / DeepSeek).";
  if(/tokens per minute|request too large|\bTPM\b|rate.?limit|rate limit|429|too many requests/i.test(emsg))
    return "\n\n\ud83d\udca1 Límite del plan gratuito o pedido muy grande (por ej. un documento adjunto). Esperá un minuto, desactivá documentos de Knowledge que no uses, o para textos largos usá Gemini / Hugging Face / OpenAI (ventana grande).";
  if(/context window|prompt tokens|context length|maximum context|context_length|exceed/i.test(emsg))
    return "\n\n\ud83d\udca1 El texto supera la ventana de contexto del modelo. Elegí un modelo con más contexto o reducí los documentos activos.";
  if(/VectorInt/i.test(emsg))
    return "\n\n\ud83d\udca1 Modelo local desactualizado en caché. En Conexiones API → ARTLAS Local, tocá «\ud83d\uddd1 Borrar caché del modelo» y recargá.";
  if(/invalid.*api.?key|unauthorized|\b401\b|invalid_api_key|authentication|no auth/i.test(emsg))
    return "\n\n\ud83d\udca1 API key inválida o faltante. Revisá tu clave en \ud83d\udd11 Conexiones API.";
  if(pk==="webllm"||pk==="ollama"||pk==="basic")
    return "\n\nReintentá o recargá el modelo local en Conexiones API.";
  return "\n\nVerificá tu conexión / API key en \ud83d\udd11 Conexiones API.";
}
function connectedProviders(){ return ["anthropic","openai","gemini","groq","hf","other","deepseek","kimi","zai","felo","webllm","basic"].filter(connected); }
function basicSyncMulti(){ cfg.basic=cfg.basic||{}; cfg.basic.multi=[...document.querySelectorAll(".bs-multi:checked")].map(x=>x.value); save(); renderMenu(); }
function taskCount(){
  const provs=connectedProviders();
  let picks=provs.filter(p=>p!=="basic");
  const gm=connected("groq")&&cfg.groq&&cfg.groq.multi&&cfg.groq.multi.length>1;
  const om=connected("other")&&cfg.other&&cfg.other.multi&&cfg.other.multi.length>1;
  if(picks.length<2&&!gm&&!om) picks=provs;
  return picks.reduce((n,pk)=>{
    if(pk==="groq") return n+((cfg.groq&&cfg.groq.multi&&cfg.groq.multi.length)||1);
    if(pk==="other") return n+((cfg.other&&cfg.other.multi&&cfg.other.multi.length)||1);
    if(pk==="basic") return n+((cfg.basic&&cfg.basic.multi&&cfg.basic.multi.length)||1);
    return n+1;
  },0);
}
function levelOf(pk){ const e=Object.entries(MODELS).find(([k,m])=>m.prov===pk); return e?e[0]:"free"; }
function smartPick(txt){
  const t=(txt||"").toLowerCase(); let want=null;
  if(/investig|paper|arxiv|estado del arte|cient/.test(t)) want=["gemini","anthropic","openai"];
  else if(/c\u00f3digo|codigo|script|python|sql|debug|program/.test(t)) want=["anthropic","openai","groq"];
  else if(/resum|qu\u00e9 es|que es|r\u00e1pid|defin/.test(t)) want=["groq","gemini","basic"];
  const pref = routeMetric==="velocidad"?["groq","gemini","basic","openai","anthropic","hf","other"]
             : routeMetric==="calidad" ?["anthropic","openai","gemini","hf","other","groq","basic"]
             : ["openai","gemini","anthropic","groq","hf","other","basic"];
  const order=(want||[]).concat(pref);
  const pk=order.find(connected)||"basic";
  return levelOf(pk);
}

/* ================= ENVÍO ================= */
async function send(){
  const txt=inp.value.trim(); if((!txt&&!atts.length)||busy)return;
  if(atts.some(a=>a.status)){ alert("Un momento: todavía estoy leyendo un adjunto (⏳)."); return; }
  const myAtts=[...atts]; atts.length=0; renderAtts();
  inp.value=""; inp.style.height="auto"; $("sugg").style.display="none";
  const displayTxt=(txt||"(adjunto)")+(myAtts.length?"\n"+myAtts.map(a=>"\ud83d\udcce "+a.name).join("\n"):"");
  if(!curId){ const id=Date.now()+""; chats.unshift({id,title:(txt||myAtts[0].name).slice(0,38),model:curModel,msgs:[],sys:customSys,web:agentWebPending}); curId=id; agentWebPending=false; }
  const c=cur(); c.msgs.push({role:"user",content:displayTxt}); save();
  $("empty").style.display="none"; $("msgs").style.display="flex";
  addRow("user",displayTxt); scrollDown(); renderChats();
  busy=true; $("send").disabled=true;

  let apiTxt=txt||"Analiz\u00e1 el contenido adjunto.";
  myAtts.filter(a=>a.kind==="txt").forEach(a=>{ apiTxt+=`\n\n[Archivo adjunto: ${a.name}]\n${a.text}`; });
  const imgs=myAtts.filter(a=>a.kind==="img");
  const sysArr=[];
  const _hasDocs = c.sys && c.sys.indexOf("CONOCIMIENTO DEL AGENTE")>=0;
  if(c.web && txt){
    let _needWeb=true;
    if(_hasDocs){
      const dzr=addRow("assistant","","📚 Leyendo los documentos del agente…"); dzr.querySelector(".content").innerHTML='<span class="typing"></span>'; scrollDown();
      const decP=["groq","gemini","openai","anthropic","hf","other"].find(connected)||"basic";
      const decPrompt="Pregunta del usuario:\n\""+txt+"\"\n\nBasándote ÚNICA y EXCLUSIVAMENTE en los DOCUMENTOS del agente (el conocimiento cargado en tu contexto), ¿podés responder de forma completa y correcta esa pregunta?\nRespondé UNA sola palabra, sin nada más:\nDOCS_OK  = la respuesta está en los documentos.\nNECESITO_WEB  = NO está en los documentos y hace falta buscar en internet.";
      let dec=""; try{ dec=await callProvider(decP, cfg[decP]||{}, [{role:"user",content:decPrompt}], c.sys); }catch(e){ dec=""; }
      dzr.remove();
      if(/NECESITO[_ ]?WEB/i.test(dec)) _needWeb=true;
      else if(/DOCS[_ ]?OK/i.test(dec)) _needWeb=false;
      else _needWeb=!docsCoverQuery(c.sys, txt);
      if(_needWeb){ const nzr=addRow("assistant","","📚 No está en los documentos → voy a navegar…"); setTimeout(()=>nzr.remove(),1400); }
      else { const ozr=addRow("assistant","","📚 La respuesta está en los documentos · sin navegar"); setTimeout(()=>ozr.remove(),1400); }
    }
    if(_needWeb){
      const tzr=addRow("assistant","","🔎 Buscando en la web (varios sitios)…"); tzr.querySelector(".content").innerHTML='<span class="typing"></span>'; scrollDown();
      let wr=""; try{ wr=await agentWebSearch(txt); }catch(e){}
      tzr.remove();
      if(wr) sysArr.push("===== RESULTADOS DE BÚSQUEDA WEB EN VIVO (varios sitios) para: \""+txt+"\" =====\n"+wr+"\n\nUSÁ estos resultados reales para responder y citá las URLs relevantes. No inventes fuentes.");
      else sysArr.push("Nota: la búsqueda web en vivo no devolvió resultados esta vez. Respondé con tu conocimiento y aclará que no pudiste verificar en línea.");
    } else {
      sysArr.push("Nota: la respuesta está en los DOCUMENTOS del agente, así que respondé con ellos y NO fue necesario navegar.");
    }
  }
  if(webMode){
    if(txt) window.open("https://www.google.com/search?q="+encodeURIComponent(txt),"_blank");
    sysArr.push("El usuario activ\u00f3 el modo b\u00fasqueda web: la consulta ya se abri\u00f3 en el buscador en otra pesta\u00f1a. Vos no ten\u00e9s acceso a internet en tiempo real; respond\u00e9 con tu mejor conocimiento y aclaralo brevemente si el tema requiere datos actuales.");
    webMode=false; renderMode();
  }
  const provs=connectedProviders();
  let mode=routeMode;
  const groqMulti=connected("groq")&&cfg.groq&&cfg.groq.multi&&cfg.groq.multi.length>1;
  const otherMulti=connected("other")&&cfg.other&&cfg.other.multi&&cfg.other.multi.length>1;
  const basicMulti=connected("basic")&&cfg.basic&&cfg.basic.multi&&cfg.basic.multi.length>1;
  if((mode==="multi"||mode==="forest")&&provs.length<2&&!groqMulti&&!otherMulti&&!basicMulti){ mode="single"; }
  if(mode==="smart"){
    let lvl=smartPick(txt);
    if(lvl&&MODELS[lvl].prov==="groq"&&(((c.sys||"").length>15000)||kb.some(d=>d.on)||atts.length)){
      const p=["gemini","openai","anthropic","hf","other"].find(connected); if(p) lvl=levelOf(p);
    }
    if(lvl){ curModel=lvl; save(); renderMenu(); } mode="single";
  }
  let picks=[];
  if(mode!=="single"){ picks=provs.filter(p=>p!=="basic"); if(picks.length<2&&!groqMulti&&!otherMulti) picks=provs; }
  const SMALLCTX=["groq","webllm"];
  const tightCtx = mode==="single" ? SMALLCTX.includes(MODELS[curModel].prov) : picks.some(p=>SMALLCTX.includes(p));
  const veryTight = mode==="single" ? MODELS[curModel].prov==="webllm" : picks.includes("webllm");
  { const sysCap=veryTight?6000:(tightCtx?18000:1e9); if(c.sys) sysArr.unshift(c.sys.length>sysCap?c.sys.slice(0,sysCap)+"\n[Conocimiento recortado por el l\u00edmite de contexto del modelo local \u2014 para conocimiento extenso us\u00e1 Gemini, OpenAI, Claude o HF]":c.sys); }
  const kbCtx=kbSys(veryTight?2500:(tightCtx?8000:60000)); if(kbCtx) sysArr.push(kbCtx);
  if(typeof atlasLang!=="undefined"&&atlasLang==="en") sysArr.push("Always respond in English, regardless of the language of the question.");
  const baseSys=sysArr.filter(Boolean).join("\n\n")||null;
  if(veryTight&&apiTxt.length>4000) apiTxt=apiTxt.slice(0,4000)+"\n\n[Adjunto recortado por el l\u00edmite del modelo local.]";
  else if(tightCtx&&apiTxt.length>12000) apiTxt=apiTxt.slice(0,12000)+"\n\n[Adjunto recortado autom\u00e1ticamente por el l\u00edmite de tokens por minuto (TPM) del plan gratuito de Groq. Para documentos largos us\u00e1 Gemini, OpenAI, Claude o Hugging Face.]";
  const history=c.msgs.map(x=>({role:x.role==="assistant"?"assistant":"user",content:x.content}));
  if(tightCtx){
    if(history.length>8) history.splice(0,history.length-8);
    history.forEach(hh=>{ if(typeof hh.content==="string"&&hh.content.length>6000) hh.content=hh.content.slice(0,6000)+" \u2026[recortado]"; });
  }
  history[history.length-1].content=apiTxt;

  try{
    if(mode==="single"){ await askOne(c,history,baseSys,imgs); }
    else{
      const tasks=picks.flatMap(pk=>{
        if(pk==="groq"){ const ms=(cfg.groq&&cfg.groq.multi&&cfg.groq.multi.length)?cfg.groq.multi:[provModel("groq")]; return ms.map(m=>({pk,model:m})); }
        if(pk==="other"){ const ms=(cfg.other&&cfg.other.multi&&cfg.other.multi.length)?cfg.other.multi:[provModel("other")]; return ms.map(m=>({pk,model:m})); }
        if(pk==="basic"){ const ms=(cfg.basic&&cfg.basic.multi&&cfg.basic.multi.length)?cfg.basic.multi:[provModel("basic")]; return ms.map(m=>({pk,model:m})); }
        return [{pk,model:provModel(pk)}];
      });
      const typing=addRow("assistant","",(mode==="multi"?"\u26a1 Simult\u00e1neo":"\ud83c\udf33 Consenso")+" \u00b7 consultando "+tasks.length+" modelos\u2026");
      typing.querySelector(".content").innerHTML='<span class="typing"></span>'; scrollDown();
      const results=await Promise.all(tasks.map(async t=>{
        try{ return {pk:t.pk,model:t.model,ok:true,text:await callProvider(t.pk,{...(cfg[t.pk]||{}),model:t.model},history.map(x=>({...x})),baseSys,imgs)}; }
        catch(e){ return {pk:t.pk,model:t.model,ok:false,text:(e.message||e)+""}; }
      }));
      typing.remove();
      if(mode==="multi"){
        results.forEach(r=>{
          const meta=(r.ok?"\u26a1 ":"\u26a0\ufe0f ")+provShort(r.pk)+" \u00b7 "+(r.model||provModel(r.pk));
          const content=r.ok?r.text:"\u26a0\ufe0f Error: "+r.text+errHint(r.pk,r.text);
          addRow("assistant",content,meta);
          c.msgs.push({role:"assistant",content,meta});
        });
      }else{
        results.forEach((r,i)=>{
          const meta="\ud83c\udf33 Respuesta "+(i+1)+" \u00b7 "+provShort(r.pk)+" \u00b7 "+(r.model||provModel(r.pk))+(r.ok?"":" \u00b7 error");
          const content=r.ok?r.text:"\u26a0\ufe0f "+r.text+errHint(r.pk,r.text);
          addRow("assistant",content,meta);
          c.msgs.push({role:"assistant",content,meta});
        });
        const good=results.filter(r=>r.ok);
        let final,meta;
        if(!good.length){ final="\u26a0\ufe0f Ning\u00fan modelo pudo responder. Revis\u00e1 tus conexiones API."; meta="\ud83c\udf33 Consenso"; }
        else if(good.length===1){ final=good[0].text; meta="\ud83c\udf33 Consenso (solo respondi\u00f3 "+PROVIDERS[good[0].pk].label+")"; }
        else{
          const merger=["anthropic","openai","gemini","groq","hf","basic"].find(connected)||good[0].pk;
          const prompt="Pregunta del usuario:\n"+apiTxt+"\n\nRespuestas de "+good.length+" modelos de IA distintos:\n\n"+good.map((r,i)=>"--- Modelo "+(i+1)+" ("+PROVIDERS[r.pk].label+" "+(r.model||"")+") ---\n"+r.text).join("\n\n")+"\n\nGener\u00e1 LA MEJOR respuesta de consenso: combin\u00e1 lo correcto de cada una, resolv\u00e9 contradicciones a favor de la mayor\u00eda o la m\u00e1s fundamentada, y respond\u00e9 directo al usuario. Al final agreg\u00e1 una secci\u00f3n breve titulada **Comparaci\u00f3n** se\u00f1alando en qu\u00e9 coincidieron y en qu\u00e9 difirieron los modelos.";
          try{ final=await callProvider(merger,cfg[merger]||{},[{role:"user",content:prompt}],baseSys); }
          catch(e){ final=good[0].text; }
          meta="\ud83c\udf33 CONSENSO FINAL de "+good.length+" modelos ("+good.map(r=>r.pk==="groq"?"Groq:"+(r.model||"").split("/").pop():r.pk==="other"?(r.model||"").split("/").pop():r.pk==="basic"?"Gratis:"+(r.model||""):PROVIDERS[r.pk].label).join(" + ")+")";
        }
        addRow("assistant",final,meta);
        c.msgs.push({role:"assistant",content:final,meta});
      }
      save(); scrollDown();
    }
  }finally{ busy=false; $("send").disabled=false; }
}
async function askOne(c,history,baseSys,imgs){
  const m=MODELS[curModel], pk=m.prov, via=`${m.name} \u2192 ${PROVIDERS[pk].label} \u00b7 ${provModel(pk)}`;
  const typing=addRow("assistant","",via); typing.querySelector(".content").innerHTML='<span class="typing"></span>'; scrollDown();
  const sys=[baseSys,m.sys].filter(Boolean).join("\n\n")||null;
  let reply, meta=via;
  try{
    if(connected(pk)) reply=await callProvider(pk,cfg[pk]||{},history,sys,imgs);
    else{ await new Promise(r=>setTimeout(r,700)); meta=m.name+" \u00b7 modo simulado"; reply=simReply(history[history.length-1].content,curModel); }
  }catch(e){
    const emsg=(e.message||e).toString();
    const hint=errHint(pk,emsg);
    typing.querySelector(".content").innerHTML=`<span class="err">\u26a0\ufe0f ${PROVIDERS[pk].label}: ${emsg.slice(0,220)}${hint}</span>`;
    typing.querySelector(".via").textContent=meta; scrollDown(); return;
  }
  typing.querySelector(".content").innerHTML=md(reply);
  typing.querySelector(".via").textContent=meta;
  c.msgs.push({role:"assistant",content:reply,meta}); save(); scrollDown();
}

/* ================= ARTEFACTOS ================= */
const ART_SYS="Sos un ingeniero de software y diseñador frontend de élite. Constru\u00ed una P\u00c1GINA/APP web COMPLETA y REALMENTE FUNCIONAL en UN SOLO archivo HTML con CSS y JS embebidos. FUNCIONALIDAD (CR\u00cdTICO, es lo m\u00e1s importante): la l\u00f3gica DEBE funcionar de verdad — implement\u00e1 los algoritmos correctos y COMPLETOS, sin funciones vac\u00edas, sin TODO, sin placeholders. Para herramientas t\u00e9cnicas/de ingenier\u00eda (calculadora IP/subneteo, conversores de base o unidades, c\u00e1lculos de red, presupuesto de enlace, finanzas, etc.) implement\u00e1 la matem\u00e1tica EXACTA. Ej. subneteo: convert\u00ed IP y m\u00e1scara a enteros de 32 bits, calcul\u00e1 direcci\u00f3n de red (AND), broadcast, wildcard, primer y \u00faltimo host, cantidad de hosts utilizables (2^(32-prefijo)-2), y notaci\u00f3n CIDR; soport\u00e1 prefijos /0 a /32. VERIFIC\u00c1 con un ejemplo antes de terminar. Valid\u00e1 las entradas y mostr\u00e1 errores claros; manej\u00e1 casos borde. Cada bot\u00f3n/acci\u00f3n produce el resultado correcto. DISE\u00d1O: moderno y prolijo (variables CSS, buena tipograf\u00eda con Google Fonts, grid/flex, tarjetas, gradientes sutiles, micro-interacciones). Pod\u00e9s usar por CDN Tailwind, Google Fonts, \u00edconos y Chart.js. RESPONSIVE (m\u00f3vil/tablet/escritorio) y accesible. Datos de ejemplo realistas precargados. Extensa: apunt\u00e1 a 400-900 l\u00edneas, priorizando que TODO funcione. Solo dependencias por CDN p\u00fablico. Devolv\u00e9 \u00daNICAMENTE el HTML completo desde <!DOCTYPE html>, sin explicaciones ni markdown.";
let artHtml=null, artHistory=[], artName="artefacto", artUsedPk=null, artUsedModel=null;
function artPk(){ const cur=MODELS[curModel]&&MODELS[curModel].prov; if(cur&&connected(cur))return cur; return ["anthropic","openai","gemini","hf","other","groq","basic"].find(connected)||"basic"; }
function artClean(t){ t=(t||"").trim().replace(/^```html?\n?/i,"").replace(/```\s*$/,""); const i=t.indexOf("<!DOCTYPE"); if(i>0)t=t.slice(i); return t; }
function artShow(){ const f=$("art-preview"); f.style.display="block"; f.srcdoc=artHtml; $("art-actions").style.display="block"; $("art-iter").disabled=false; $("art-prompt").value=""; }
async function artGenerate(){
  const p=$("art-prompt").value.trim(); if(!p){ $("art-prompt").focus(); return; }
  artName=p.slice(0,40); $("art-note").textContent="Generando\u2026 (puede tardar un minuto)"; $("art-gen").disabled=true;
  try{
    const pk=artPk(); artUsedPk=pk; artUsedModel=provModel(pk);
    const t=await callProvider(pk,cfg[pk]||{},[{role:"user",content:"Constru\u00ed: "+p}],enSys(ART_SYS),[],pk==="groq"?5500:8000);
    artHtml=artClean(t); artHistory=[{role:"user",content:"Constru\u00ed: "+p},{role:"assistant",content:artHtml}];
    artShow(); $("art-note").textContent="\u2713 Generado con "+PROVIDERS[pk].label+" \u00b7 "+artUsedModel+" \u2014 escrib\u00ed cambios y toc\u00e1 \ud83d\udd01";
  }catch(e){ $("art-note").textContent="\u26a0\ufe0f "+(e.message||e); }
  $("art-gen").disabled=false;
}
async function artIterate(){
  const p=$("art-prompt").value.trim();
  if(!artHtml){ alert("Primero gener\u00e1 un artefacto."); return; }
  if(!p){ alert("Escrib\u00ed el cambio que quer\u00e9s en el mismo cuadro."); $("art-prompt").focus(); return; }
  $("art-note").textContent="Aplicando cambios\u2026"; $("art-iter").disabled=true;
  try{
    const pk=(artUsedPk&&connected(artUsedPk))?artUsedPk:artPk();
    const model=(pk===artUsedPk&&artUsedModel)?artUsedModel:provModel(pk);
    const msgs=[...artHistory.slice(-2),{role:"user",content:"Aplic\u00e1 este cambio y devolv\u00e9 el HTML COMPLETO actualizado (no fragmentos): "+p}];
    const t=await callProvider(pk,{...(cfg[pk]||{}),model},msgs,enSys(ART_SYS),[],pk==="groq"?5500:8000);
    artHtml=artClean(t); artHistory.push({role:"user",content:p},{role:"assistant",content:artHtml});
    artShow(); $("art-note").textContent="\u2713 Actualizado con "+PROVIDERS[pk].label+" \u00b7 "+model;
  }catch(e){ $("art-note").textContent="\u26a0\ufe0f "+(e.message||e); $("art-iter").disabled=false; }
}
function artDownload(){
  if(!artHtml)return;
  const blob=new Blob([artHtml],{type:"text/html"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob);
  a.download=(artName||"artefacto").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")+".html"; a.click();
}
async function artPublish(){
  if(!artHtml){ alert("Primero gener\u00e1 un artefacto."); return; }
  const b64=btoa(unescape(encodeURIComponent(artHtml)));
  if(b64.length>1400000){ $("art-msg").textContent="Muy grande para link \u2014 us\u00e1 Descargar."; return; }
  let base=null;
  if(location.protocol==="http:"||location.protocol==="https:") base=location.href.split("#")[0].split("?")[0].replace(/[^\/]*$/,"");
  const url=(base||"https://TU-SITIO.netlify.app/")+"view.html#"+b64;
  $("art-pub").style.display="block";
  $("art-pub-url").value=url;
  $("art-msg").textContent=base?("Link listo ("+Math.round(url.length/1024)+" KB)"):"Est\u00e1s en un archivo local: el link va a funcionar en tu sitio publicado (reemplaz\u00e1 TU-SITIO).";
  try{ await navigator.clipboard.writeText(url); $("art-msg").textContent+=" \u00b7 \u2713 copiado"; }catch(e){}
}
function artCopyUrl(){
  const el=$("art-pub-url"); el.select(); el.setSelectionRange(0,el.value.length);
  let ok=false;
  try{ ok=document.execCommand("copy"); }catch(e){}
  if(navigator.clipboard){ navigator.clipboard.writeText(el.value).then(()=>{ $("art-msg").textContent="\u2713 link copiado"; }).catch(()=>{ $("art-msg").textContent=ok?"\u2713 link copiado":"Seleccion\u00e1 el texto y copi\u00e1 con Ctrl+C"; }); }
  else $("art-msg").textContent=ok?"\u2713 link copiado":"Seleccion\u00e1 el texto y copi\u00e1 con Ctrl+C";
}
async function artStorePut(doc){ const d=await idbOpen(); return new Promise((res,rej)=>{ const tx=d.transaction("artifacts","readwrite"); tx.objectStore("artifacts").put(doc); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
async function artStoreDel(name){ const d=await idbOpen(); return new Promise((res,rej)=>{ const tx=d.transaction("artifacts","readwrite"); tx.objectStore("artifacts").delete(name); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
async function artStoreAll(){ const d=await idbOpen(); return new Promise((res,rej)=>{ const rq=d.transaction("artifacts").objectStore("artifacts").getAll(); rq.onsuccess=()=>res(rq.result||[]); rq.onerror=()=>rej(rq.error); }); }
let artSaved=[];
async function artSave(){
  if(!artHtml)return;
  const doc={name:artName+" \u00b7 "+new Date().toLocaleString(),html:artHtml,date:Date.now()};
  await artStorePut(doc); $("art-msg").textContent="\u2713 guardado"; setTimeout(()=>$("art-msg").textContent="",2500);
  artListLoad();
}
async function artListLoad(){
  try{ artSaved=(await artStoreAll()).sort((a,b)=>b.date-a.date); }catch(e){ artSaved=[]; }
  $("art-list").innerHTML=artSaved.length?artSaved.map((a2,ix)=>`<div class="kb-item"><span class="nm">\ud83e\udde9 ${esc(a2.name)}</span>
    <button class="btn" style="padding:4px 12px;font-size:12px" onclick="artOpen(${ix})">Abrir</button>
    <button class="btn" style="padding:4px 10px;font-size:12px" onclick="artStoreDel(artSaved[${ix}].name).then(artListLoad)">\u2715</button></div>`).join(""):'<div class="note">Todav\u00eda no guardaste artefactos.</div>';
}
function artOpen(ix){
  const a2=artSaved[ix]; if(!a2)return;
  artHtml=a2.html; artName=a2.name.split(" \u00b7 ")[0]; artUsedPk=null; artUsedModel=null; artHistory=[{role:"user",content:"Artefacto existente: "+artName},{role:"assistant",content:artHtml}];
  artShow(); $("art-note").textContent="\u2713 Abierto: "+a2.name;
}

/* ================= ANALÍTICAS (v30 — multi-archivo, hasta 8 gráficos y 6 KPIs) ================= */
let anFiles=[];              // [{name, rows}]
let anRows=[], anMeta=[], anCharts=[], anFileName="";
let anChartDefs=[], anKpiDefs=[], anSelCharts=[], anSelKpis=[], anLastEval="", anWebHtml="";
const AN_MAX_FILES=3, AN_MAX_CHARTS=8, AN_MAX_KPIS=6;
const AN_COLORS=["#1976d2","#10a37f","#e8a13c","#ef4146","#7b5bd6","#0d9db8","#c2185b","#5d8a2f","#8f6b4e","#546e7a"];
function anNum(v){ if(typeof v==="number")return v; if(v==null)return NaN; const n=Number(String(v).replace(/\s/g,"").replace(/,/g,".")); return n; }
function anFmt(n){ if(!isFinite(n))return "—"; if(Math.abs(n)>=1e6)return (n/1e6).toFixed(2)+" M"; if(Math.abs(n)>=1e3)return (n/1e3).toFixed(1)+" K"; return (Math.round(n*100)/100).toLocaleString(); }
function pearson(x,y){ const n=x.length; if(n<3)return 0; const mx=x.reduce((a,b)=>a+b,0)/n,my=y.reduce((a,b)=>a+b,0)/n; let sx=0,sy=0,sxy=0; for(let i=0;i<n;i++){const a=x[i]-mx,b=y[i]-my; sx+=a*a; sy+=b*b; sxy+=a*b;} return sx&&sy?sxy/Math.sqrt(sx*sy):0; }

async function anLoad(files){
  if(!files||!files.length)return;
  await loadScript("https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js");
  const list=[...files].slice(0,AN_MAX_FILES);
  if(files.length>AN_MAX_FILES) $("an-note").textContent="Máximo "+AN_MAX_FILES+" archivos — tomo los primeros "+AN_MAX_FILES+".";
  for(const f of list){
    if(anFiles.length>=AN_MAX_FILES){ break; }
    if(f.size>60*1024*1024){ alert(f.name+" supera 60 MB."); continue; }
    if(anFiles.some(x=>x.name===f.name)) continue;
    $("an-note").textContent="⏳ leyendo "+f.name+"…";
    try{
      const wb=window.XLSX.read(await f.arrayBuffer(),{type:"array"});
      let rows=window.XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:null});
      if(rows.length>50000) rows=rows.slice(0,50000);
      anFiles.push({name:f.name, rows});
    }catch(e){ $("an-note").textContent="⚠️ No pude leer "+f.name+": "+(e.message||e); }
  }
  $("an-file").value="";
  anRenderFileChips();
  anCombine();
}
function anRemoveFile(ix){ anFiles.splice(ix,1); anRenderFileChips(); if(anFiles.length) anCombine(); else { $("an-dash").style.display="none"; $("an-note").textContent="Subí uno o más archivos para empezar."; } }
function anRenderFileChips(){
  const host=$("an-files"); if(!host)return;
  host.innerHTML=anFiles.map((f,ix)=>`<span class="att-chip">📄 ${esc(f.name)} · ${f.rows.length.toLocaleString()} filas <span class="x" onclick="anRemoveFile(${ix})">✕</span></span>`).join("");
}
function anBuildMeta(rows){
  const meta=[]; if(!rows.length)return meta;
  const keys=Object.keys(rows[0]);
  keys.forEach(k=>{
    const vals=rows.map(r=>r[k]).filter(v=>v!=null&&v!=="");
    const nums=vals.map(anNum).filter(n=>!isNaN(n));
    const numeric=vals.length>0&&nums.length/vals.length>0.8;
    const m={k,numeric,missing:rows.length-vals.length};
    if(numeric){ m.nums=rows.map(r=>anNum(r[k])); const good=nums;
      m.sum=good.reduce((a,b)=>a+b,0); m.avg=m.sum/good.length;
      m.min=Math.min(...good.slice(0,20000)); m.max=Math.max(...good.slice(0,20000));
    }else{
      const cnt={}; vals.slice(0,20000).forEach(v=>{ const s=String(v).slice(0,40); cnt[s]=(cnt[s]||0)+1; });
      m.tops=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,12); m.uniq=Object.keys(cnt).length;
    }
    meta.push(m);
  });
  return meta;
}
function anCombine(){
  // combinar filas de todos los archivos (etiquetando el origen)
  anRows=[]; anFiles.forEach(f=>{ f.rows.forEach(r=>anRows.push(anFiles.length>1?{__archivo:f.name,...r}:r)); });
  anFileName=anFiles.map(f=>f.name).join(" + ");
  anMeta=anBuildMeta(anRows);
  $("an-note").textContent="✓ "+anFiles.length+" archivo"+(anFiles.length>1?"s":"")+" · "+anRows.length.toLocaleString()+" filas combinadas · "+anMeta.length+" columnas";
  anBuildCandidates();
  anRenderControls();
  anRenderDash();
  $("an-dash").style.display="block";
}
// compatibilidad: si hubiera un selector de hoja
function anSheet(){ anCombine(); }

function anAggBy(cat,num,fnAvg){
  const agg={},cnt={};
  anRows.forEach(r=>{ const key=String(r[cat]??"—").slice(0,30); const v=anNum(r[num]); if(!isNaN(v)){agg[key]=(agg[key]||0)+v;cnt[key]=(cnt[key]||0)+1;} });
  let arr=Object.keys(agg).map(k=>[k, fnAvg?agg[k]/cnt[k]:agg[k]]);
  return arr.sort((a,b)=>b[1]-a[1]).slice(0,10);
}
function anBuildCandidates(){
  anChartDefs=[]; anKpiDefs=[];
  const numCols=anMeta.filter(m=>m.numeric);
  const catCols=anMeta.filter(m=>!m.numeric&&m.tops&&m.uniq>1&&m.uniq<=2000);
  const c=catCols[0], n=numCols[0];
  // ---- KPIs candidatos (hasta 6 elegibles) ----
  anKpiDefs.push({id:"kpi-reg",label:"Registros",html:`<div style="font-size:11px;color:var(--muted)">REGISTROS</div><div style="font-size:22px;font-weight:800">${anRows.length.toLocaleString()}</div>`});
  numCols.slice(0,4).forEach((m,i)=>anKpiDefs.push({id:"kpi-num"+i,label:m.k+" · suma",html:`<div style="font-size:11px;color:var(--muted)">${esc(m.k).toUpperCase()} · SUMA</div><div style="font-size:22px;font-weight:800">${anFmt(m.sum)}</div><div style="font-size:11px;color:var(--muted)">prom ${anFmt(m.avg)} · máx ${anFmt(m.max)}</div>`}));
  if(catCols[0]) anKpiDefs.push({id:"kpi-cat0",label:catCols[0].k+" · categorías",html:`<div style="font-size:11px;color:var(--muted)">${esc(catCols[0].k).toUpperCase()} · CATEGORÍAS</div><div style="font-size:22px;font-weight:800">${catCols[0].uniq}</div>`});
  if(catCols[1]) anKpiDefs.push({id:"kpi-cat1",label:catCols[1].k+" · categorías",html:`<div style="font-size:11px;color:var(--muted)">${esc(catCols[1].k).toUpperCase()} · CATEGORÍAS</div><div style="font-size:22px;font-weight:800">${catCols[1].uniq}</div>`});
  if(anFiles.length>1) anKpiDefs.push({id:"kpi-files",label:"Archivos",html:`<div style="font-size:11px;color:var(--muted)">ARCHIVOS</div><div style="font-size:22px;font-weight:800">${anFiles.length}</div>`});
  // ---- Gráficos candidatos (hasta 8 elegibles) ----
  if(c&&n) anChartDefs.push({id:"ch-barsum",label:`${n.k} por ${c.k} (barras)`,make:()=>{ const t=anAggBy(c.k,n.k,false); return {type:"bar",data:{labels:t.map(x=>x[0]),datasets:[{data:t.map(x=>x[1]),backgroundColor:AN_COLORS}]},options:{plugins:{title:{display:true,text:`${n.k} por ${c.k} (top 10)`},legend:{display:false}}}}; }});
  else if(c) anChartDefs.push({id:"ch-count",label:`Conteo por ${c.k}`,make:()=>({type:"bar",data:{labels:c.tops.slice(0,10).map(t=>t[0]),datasets:[{data:c.tops.slice(0,10).map(t=>t[1]),backgroundColor:AN_COLORS}]},options:{plugins:{title:{display:true,text:`Conteo por ${c.k}`},legend:{display:false}}}})});
  if(n) anChartDefs.push({id:"ch-line",label:`${n.k} — evolución`,make:()=>{ const step=Math.max(1,Math.floor(anRows.length/200)); const pts=[]; for(let i=0;i<anRows.length;i+=step){ const v=anNum(anRows[i][n.k]); if(!isNaN(v))pts.push({x:i+1,y:v}); } return {type:"line",data:{datasets:[{data:pts,borderColor:"#1976d2",backgroundColor:"rgba(25,118,210,.12)",fill:true,pointRadius:0,tension:.25}]},options:{plugins:{title:{display:true,text:n.k+" — evolución"},legend:{display:false}},scales:{x:{type:"linear"}}}}; }});
  const c3=catCols[1]||catCols[0];
  if(c3) anChartDefs.push({id:"ch-dough",label:`Distribución de ${c3.k}`,make:()=>{ const top=c3.tops.slice(0,6); const rest=c3.tops.slice(6).reduce((a,t)=>a+t[1],0); return {type:"doughnut",data:{labels:top.map(t=>t[0]).concat(rest?["Otros"]:[]),datasets:[{data:top.map(t=>t[1]).concat(rest?[rest]:[]),backgroundColor:AN_COLORS}]},options:{plugins:{title:{display:true,text:"Distribución de "+c3.k}}}}; }});
  if(c&&n) anChartDefs.push({id:"ch-avg",label:`Promedio de ${n.k} por ${c.k}`,make:()=>{ const t=anAggBy(c.k,n.k,true); return {type:"bar",data:{labels:t.map(x=>x[0]),datasets:[{data:t.map(x=>x[1]),backgroundColor:"#10a37f"}]},options:{indexAxis:"y",plugins:{title:{display:true,text:"Promedio de "+n.k+" por "+c.k},legend:{display:false}}}}; }});
  if(numCols.length>=2){
    const a=numCols[0],b=numCols[1];
    anChartDefs.push({id:"ch-scatter",label:`${a.k} vs ${b.k} (dispersión)`,make:()=>{ const pts=[]; for(let i=0;i<Math.min(anRows.length,3000);i++){ const x=anNum(anRows[i][a.k]),y=anNum(anRows[i][b.k]); if(!isNaN(x)&&!isNaN(y))pts.push({x,y}); } return {type:"scatter",data:{datasets:[{data:pts,backgroundColor:"rgba(123,91,214,.5)"}]},options:{plugins:{title:{display:true,text:`${a.k} vs ${b.k}`},legend:{display:false}}}}; }});
  }
  if(numCols.length>=3){
    anChartDefs.push({id:"ch-radar",label:"Perfil de métricas (radar)",make:()=>{ const cols=numCols.slice(0,6); const maxs=cols.map(m=>m.max||1); return {type:"radar",data:{labels:cols.map(m=>m.k),datasets:[{label:"Promedio (norm.)",data:cols.map((m,i)=>maxs[i]?(m.avg/maxs[i]):0),backgroundColor:"rgba(25,118,210,.2)",borderColor:"#1976d2"}]},options:{plugins:{title:{display:true,text:"Perfil de métricas (promedio normalizado)"}}}}; }});
  }
  if(catCols.length>=2&&n){
    const c1=catCols[0],c2=catCols[1];
    anChartDefs.push({id:"ch-stack",label:`${n.k}: ${c1.k} × ${c2.k} (apiladas)`,make:()=>{
      const cats1=c1.tops.slice(0,8).map(t=>t[0]), cats2=c2.tops.slice(0,5).map(t=>t[0]);
      const grid={}; cats1.forEach(a=>grid[a]={}); 
      anRows.forEach(r=>{ const a=String(r[c1.k]??"—").slice(0,30),b=String(r[c2.k]??"—").slice(0,30),v=anNum(r[n.k]); if(cats1.includes(a)&&cats2.includes(b)&&!isNaN(v))grid[a][b]=(grid[a][b]||0)+v; });
      const ds=cats2.map((b,i)=>({label:b,data:cats1.map(a=>grid[a][b]||0),backgroundColor:AN_COLORS[i%AN_COLORS.length]}));
      return {type:"bar",data:{labels:cats1,datasets:ds},options:{plugins:{title:{display:true,text:`${n.k}: ${c1.k} × ${c2.k}`}},scales:{x:{stacked:true},y:{stacked:true}}}}; }});
  }
  if(n) anChartDefs.push({id:"ch-hist",label:`Histograma de ${n.k}`,make:()=>{ const good=n.nums.filter(x=>!isNaN(x)); const min=Math.min(...good.slice(0,20000)),max=Math.max(...good.slice(0,20000)); const bins=12,w=(max-min)/bins||1; const h=new Array(bins).fill(0); good.forEach(v=>{ let b=Math.floor((v-min)/w); if(b<0)b=0; if(b>=bins)b=bins-1; h[b]++; }); const labels=h.map((_,i)=>anFmt(min+i*w)); return {type:"bar",data:{labels,datasets:[{data:h,backgroundColor:"#e8a13c"}]},options:{plugins:{title:{display:true,text:"Histograma de "+n.k},legend:{display:false}}}}; }});
  // ---- candidatos adicionales (para elegir de un pool mayor) ----
  numCols.slice(0,5).forEach((m,i)=>{
    anKpiDefs.push({id:"kpi-avg"+i,label:m.k+" · promedio",html:`<div style="font-size:11px;color:var(--muted)">${esc(m.k).toUpperCase()} · PROMEDIO</div><div style="font-size:22px;font-weight:800">${anFmt(m.avg)}</div><div style="font-size:11px;color:var(--muted)">min ${anFmt(m.min)} · máx ${anFmt(m.max)}</div>`});
    anKpiDefs.push({id:"kpi-max"+i,label:m.k+" · máximo",html:`<div style="font-size:11px;color:var(--muted)">${esc(m.k).toUpperCase()} · MÁXIMO</div><div style="font-size:22px;font-weight:800">${anFmt(m.max)}</div>`});
  });
  { const missTot=anMeta.reduce((s,m)=>s+(m.missing||0),0); const cells=anRows.length*Math.max(anMeta.length,1);
    anKpiDefs.push({id:"kpi-miss",label:"Datos faltantes %",html:`<div style="font-size:11px;color:var(--muted)">DATOS FALTANTES</div><div style="font-size:22px;font-weight:800">${cells?(100*missTot/cells).toFixed(1):0}%</div>`}); }
  catCols.slice(0,3).forEach((cc,i)=>{
    anChartDefs.push({id:"ch-count"+i,label:`Conteo por ${cc.k}`,make:()=>({type:"bar",data:{labels:cc.tops.slice(0,10).map(t=>t[0]),datasets:[{data:cc.tops.slice(0,10).map(t=>t[1]),backgroundColor:AN_COLORS}]},options:{plugins:{title:{display:true,text:`Conteo por ${cc.k}`},legend:{display:false}}}})});
    anChartDefs.push({id:"ch-pie"+i,label:`Torta de ${cc.k}`,make:()=>{ const top=cc.tops.slice(0,7); const rest=cc.tops.slice(7).reduce((a,t)=>a+t[1],0); return {type:"pie",data:{labels:top.map(t=>t[0]).concat(rest?["Otros"]:[]),datasets:[{data:top.map(t=>t[1]).concat(rest?[rest]:[]),backgroundColor:AN_COLORS}]},options:{plugins:{title:{display:true,text:"Torta de "+cc.k}}}}; }});
  });
  numCols.slice(0,4).forEach((m,i)=>{
    anChartDefs.push({id:"ch-hist"+i,label:`Histograma de ${m.k}`,make:()=>{ const good=m.nums.filter(x=>!isNaN(x)); const min=Math.min(...good.slice(0,20000)),max=Math.max(...good.slice(0,20000)); const bins=12,w=(max-min)/bins||1; const h=new Array(bins).fill(0); good.forEach(v=>{ let b=Math.floor((v-min)/w); if(b<0)b=0; if(b>=bins)b=bins-1; h[b]++; }); return {type:"bar",data:{labels:h.map((_,j)=>anFmt(min+j*w)),datasets:[{data:h,backgroundColor:AN_COLORS[i%AN_COLORS.length]}]},options:{plugins:{title:{display:true,text:"Histograma de "+m.k},legend:{display:false}}}}; }});
  });
  // selección por defecto
  anSelKpis=anKpiDefs.slice(0,AN_MAX_KPIS).map(k=>k.id);
  anSelCharts=anChartDefs.slice(0,Math.min(AN_MAX_CHARTS,anChartDefs.length)).map(c=>c.id);
}
function anRenderControls(){
  const host=$("an-controls"); if(!host)return;
  const kpiBoxes=anKpiDefs.map(k=>`<label class="an-pick"><input type="checkbox" ${anSelKpis.includes(k.id)?"checked":""} onchange="anToggleKpi('${k.id}')"> ${esc(k.label)}</label>`).join("");
  const chBoxes=anChartDefs.map(c=>`<label class="an-pick"><input type="checkbox" ${anSelCharts.includes(c.id)?"checked":""} onchange="anToggleChart('${c.id}')"> ${esc(c.label)}</label>`).join("");
  host.innerHTML=`<div class="card" style="padding:12px"><b style="font-size:12.5px">📊 KPIs sugeridos — elegí hasta ${AN_MAX_KPIS} (<span id="an-kpi-count">${anSelKpis.length}</span> elegidos)</b><div class="an-picks">${kpiBoxes}</div></div>
    <div class="card" style="padding:12px;margin-top:10px"><b style="font-size:12.5px">📈 Gráficos sugeridos — elegí hasta ${AN_MAX_CHARTS} (<span id="an-ch-count">${anSelCharts.length}</span> elegidos)</b><div class="an-picks">${chBoxes}</div></div>`;
}
function anToggleKpi(id){
  if(anSelKpis.includes(id)) anSelKpis=anSelKpis.filter(x=>x!==id);
  else{ if(anSelKpis.length>=AN_MAX_KPIS){ alert("Máximo "+AN_MAX_KPIS+" KPIs."); anRenderControls(); return; } anSelKpis.push(id); }
  anRenderControls(); anRenderKpis();
}
function anToggleChart(id){
  if(anSelCharts.includes(id)) anSelCharts=anSelCharts.filter(x=>x!==id);
  else{ if(anSelCharts.length>=AN_MAX_CHARTS){ alert("Máximo "+AN_MAX_CHARTS+" gráficos."); anRenderControls(); return; } anSelCharts.push(id); }
  anRenderControls(); anRenderCharts();
}
function anRenderKpis(){
  const host=$("an-kpis"); if(!host)return;
  host.innerHTML=anSelKpis.map(id=>{ const k=anKpiDefs.find(x=>x.id===id); return k?`<div class="card" style="padding:14px">${k.html}</div>`:""; }).join("");
}
async function anRenderCharts(){
  await loadScript("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js");
  const host=$("an-charts"); if(!host)return;
  anCharts.forEach(c=>{ try{c.destroy();}catch(e){} }); anCharts=[];
  host.innerHTML=anSelCharts.map(id=>`<div class="card" style="min-height:280px"><canvas id="cv-${id}"></canvas></div>`).join("");
  anSelCharts.forEach(id=>{ const def=anChartDefs.find(x=>x.id===id); const el=$("cv-"+id); if(def&&el){ try{ anCharts.push(new Chart(el.getContext("2d"), def.make())); }catch(e){} } });
}
function anRenderDash(){ anRenderKpis(); anRenderCharts(); }

function anSummary(){
  const cols=anMeta.map(m=>m.numeric
    ?`${m.k} (numérica): suma ${anFmt(m.sum)}, prom ${anFmt(m.avg)}, min ${anFmt(m.min)}, máx ${anFmt(m.max)}, faltantes ${m.missing}`
    :`${m.k} (categórica): ${m.uniq} valores únicos, top: ${(m.tops||[]).slice(0,5).map(t=>t[0]+"("+t[1]+")").join(", ")}, faltantes ${m.missing}`);
  const sample=anRows.slice(0,25).map(r=>{ const o={}; Object.keys(r).forEach(k=>o[k]=String(r[k]??"").slice(0,40)); return o; });
  return "Dataset: "+anFileName+" ("+anFiles.length+" archivo/s) · "+anRows.length+" filas.\nColumnas:\n- "+cols.join("\n- ")+"\n\nMuestra de filas:\n"+JSON.stringify(sample);
}
async function anLLM(prompt,label){
  if(!anRows.length){ alert("Primero subí un archivo."); return ""; }
  $("an-llm-note").textContent="⏳ "+label+"…";
  try{
    const pk=artPk();
    const t=await callProvider(pk,cfg[pk]||{},[{role:"user",content:prompt}],enSys("Sos un analista de datos senior. Respondé en español, claro, ejecutivo y accionable, citando números concretos del dataset."),[],pk==="groq"?4000:5000);
    anLastEval=t; $("an-report").innerHTML=md(t);
    $("an-llm-note").textContent="✓ con "+PROVIDERS[pk].label;
    return t;
  }catch(e){ $("an-llm-note").textContent="⚠️ "+(e.message||e); return ""; }
}
function anAnalyze(){
  const foco=(document.getElementById("an-prompt")?document.getElementById("an-prompt").value.trim():"");
  const base="Analizá y EVALUÁ este dataset combinado y generá: 1) Lectura general. 2) Hallazgos clave con números. 3) Evaluación de resultados (qué está bien / mal / llama la atención). 4) KPIs sugeridos. 5) Recomendaciones accionables priorizadas.";
  const ins=foco?("ENFOQUE/INSTRUCCIONES DEL USUARIO (prioritario): "+foco+"\n\n"+base):base;
  return anLLM(ins+"\n\n"+anSummary(),"analizando y evaluando");
}
function anAnalyzeChange(){
  if(!anRows.length){ alert("Primero subí un archivo."); return; }
  const foco=(document.getElementById("an-prompt")?document.getElementById("an-prompt").value.trim():"");
  if(!foco){ alert("Escribí en el cuadro de arriba qué cambio o enfoque querés en el análisis."); return; }
  if(!anLastEval){ return anAnalyze(); }
  return anLLM("Análisis previo del dataset:\n\n"+anLastEval+"\n\nPEDIDO DEL USUARIO (ajustá o ampliá el análisis según esto): "+foco+"\n\nDatos:\n"+anSummary(),"aplicando cambios al análisis");
}
function anMine(){
  if(!anRows.length){ alert("Primero subí un archivo."); return; }
  const numCols=anMeta.filter(m=>m.numeric).slice(0,8);
  const corrs=[];
  for(let i=0;i<numCols.length;i++)for(let k=i+1;k<numCols.length;k++){
    const pairs=[];
    for(let r=0;r<Math.min(anRows.length,10000);r++){ const a=anNum(anRows[r][numCols[i].k]),b=anNum(anRows[r][numCols[k].k]); if(!isNaN(a)&&!isNaN(b))pairs.push([a,b]); }
    if(pairs.length>10){ const rho=pearson(pairs.map(p=>p[0]),pairs.map(p=>p[1])); if(Math.abs(rho)>0.3) corrs.push(`${numCols[i].k} vs ${numCols[k].k}: r=${rho.toFixed(2)}`); }
  }
  const outs=[];
  numCols.forEach(m=>{ const good=m.nums.filter(n=>!isNaN(n)); if(good.length<10)return;
    const sd=Math.sqrt(good.reduce((a,b)=>a+(b-m.avg)*(b-m.avg),0)/good.length); if(!sd)return;
    const o=good.filter(v=>Math.abs((v-m.avg)/sd)>3); if(o.length) outs.push(`${m.k}: ${o.length} outliers (ej: ${o.slice(0,3).map(anFmt).join(", ")})`);
  });
  const miss=anMeta.filter(m=>m.missing>0).map(m=>`${m.k}: ${(100*m.missing/anRows.length).toFixed(1)}% faltante`);
  const signals="SEÑALES CALCULADAS (estadística real):\nCorrelaciones (|r|>0.3): "+(corrs.join(" · ")||"ninguna relevante")+"\nOutliers: "+(outs.join(" · ")||"sin outliers fuertes")+"\nDatos faltantes: "+(miss.join(" · ")||"sin faltantes")+"\n\n";
  anLLM("MINERÍA DE DATOS: usando las señales estadísticas y el resumen, detectá patrones ocultos, segmentos con comportamiento diferencial, anomalías y oportunidades. Indicá qué correlaciones parecen causales y cuáles espurias.\n\n"+signals+anSummary(),"minando patrones");
}
// ---- imágenes de los gráficos actuales ----
function anChartImages(){ return anCharts.map(c=>{ try{return c.toBase64Image();}catch(e){return null;} }).filter(Boolean); }
function anKpiHtmlBlock(){ return anSelKpis.map(id=>{ const k=anKpiDefs.find(x=>x.id===id); return k?`<div class="kpi">${k.html}</div>`:""; }).join(""); }
function anBuildDoc(kind){
  const imgs=anChartImages();
  const evalHtml=anLastEval?md(anLastEval):"<p><i>Ejecutá «Análisis y recomendaciones» para incluir la evaluación.</i></p>";
  const title=(kind==="web"?"Dashboard ARTLAS — ":"Reporte ARTLAS — ")+esc(anFileName);
  const css=`body{font-family:-apple-system,'Segoe UI',system-ui,sans-serif;margin:0;background:#f5f7fa;color:#12223a}
    .wrap{max-width:1100px;margin:0 auto;padding:28px}
    h1{font-size:26px;margin:0 0 4px} .meta{color:#6b7a90;font-size:13px;margin-bottom:22px}
    .kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;margin-bottom:24px}
    .kpi{background:#fff;border:1px solid #e3e9f0;border-radius:12px;padding:14px}
    .charts{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px}
    .charts img{width:100%;background:#fff;border:1px solid #e3e9f0;border-radius:12px;padding:8px;box-sizing:border-box}
    .eval{background:#fff;border:1px solid #e3e9f0;border-radius:12px;padding:20px;margin-top:24px;line-height:1.7}
    h2{font-size:18px;border-bottom:2px solid #1976d2;padding-bottom:6px;display:inline-block;margin-top:0}
    .ft{color:#8496aa;font-size:12px;text-align:center;margin-top:30px}`;
  return `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title><style>${css}</style></head>
<body><div class="wrap">
<h1>${title}</h1>
<div class="meta">Generado por AR.T.L.A.S. · ${new Date().toLocaleString()} · ${anFiles.length} archivo(s) · ${anRows.length.toLocaleString()} filas</div>
<div class="kpis">${anKpiHtmlBlock()}</div>
<h2>Gráficos</h2>
<div class="charts">${imgs.map(s=>`<img src="${s}">`).join("")||"<p>Sin gráficos seleccionados.</p>"}</div>
<div class="eval"><h2>Evaluación y recomendaciones</h2>${evalHtml}</div>
<div class="ft">AR.T.L.A.S. — Argentine Transformer for Learning and Advanced Semantics · by MMFC</div>
</div></body></html>`;
}
function anDownloadHtml(html,fn){ const blob=new Blob([html],{type:"text/html"}); const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=fn; a.click(); }
async function anReport(){
  if(!anRows.length){ alert("Primero subí un archivo."); return; }
  $("an-llm-note").textContent="📄 armando reporte…";
  if(!anLastEval) await anAnalyze();
  const html=anBuildDoc("report");
  anDownloadHtml(html, (anFileName||"reporte").replace(/[^a-z0-9]+/gi,"-").slice(0,40)+"-reporte.html");
  $("an-llm-note").textContent="✓ Reporte descargado";
}
async function anWebpage(){
  if(!anRows.length){ alert("Primero subí un archivo."); return; }
  $("an-llm-note").textContent="🌐 armando página web…";
  if(!anLastEval) await anAnalyze();
  anWebHtml=anBuildDoc("web");
  anDownloadHtml(anWebHtml, (anFileName||"dashboard").replace(/[^a-z0-9]+/gi,"-").slice(0,40)+"-dashboard.html");
  // publicar (link compartible vía view.html)
  try{
    const b64=btoa(unescape(encodeURIComponent(anWebHtml)));
    if(b64.length<1400000){
      let base=(location.protocol==="http:"||location.protocol==="https:")?location.href.split("#")[0].split("?")[0].replace(/[^\/]*$/,""):"https://TU-SITIO.netlify.app/";
      const url=base+"view.html#"+b64;
      $("an-pub").style.display="block"; $("an-pub-url").value=url;
      try{ await navigator.clipboard.writeText(url); }catch(e){}
      $("an-llm-note").textContent="✓ Página web descargada y link de publicación listo";
    } else $("an-llm-note").textContent="✓ Página web descargada (muy grande para link — usá el archivo)";
  }catch(e){ $("an-llm-note").textContent="✓ Página web descargada"; }
}

/* ================= VERSIÓN ESCRITORIO ================= */
async function buildDesktop(){
  const note=$("desk-note");
  if(location.protocol==="file:"){ note.textContent="Ya estás usando la versión de escritorio. Esta descarga se hace desde el sitio publicado."; return; }
  if(typeof JSZip==="undefined"){ note.textContent="No se pudo cargar el empaquetador. Recargá la página."; return; }
  note.textContent="Armando paquete cifrado…";
  try{
    let [ah,aj,rec]=await Promise.all([fetch("app.html",{cache:"no-store"}).then(r=>r.text()),fetch("app.js",{cache:"no-store"}).then(r=>r.text()),fetch("app-recursos.js",{cache:"no-store"}).then(r=>r.ok?r.text():"").catch(()=>"")]);
    try{ if(typeof v68Unwrap==="function") aj=v68Unwrap(aj); }catch(e){}   // v6.8: app.js se publica protegido
    if(rec) aj=rec+"\n"+aj;   // íconos, RAG local y manual: van dentro del paquete de escritorio
    let logoData=null;
    try{ const bl=await fetch("logo.png").then(r=>{ if(!r.ok)throw 0; return r.blob(); });
      logoData=await new Promise(res=>{ const fr=new FileReader(); fr.onload=()=>res(fr.result); fr.readAsDataURL(bl); });
    }catch(e){}
    const styleCss=(ah.match(/<style>([\s\S]*?)<\/style>/)||[])[1]||"";
    let bodyInner=(ah.match(/<body>([\s\S]*?)<\/body>/)||[])[1]||"";
    bodyInner=bodyInner.replace(/<script[\s\S]*?<\/script>/g,"");
    const splash='<div id="dsplash" style="position:fixed;inset:0;background:#fff;z-index:400;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:34px">'
      +(logoData?'<img src="'+logoData+'" style="width:min(430px,84vw);height:auto" alt="AR.T.L.A.S.">':'<h1 style="color:#0d2b5e;font-size:52px;letter-spacing:8px">AR.T.L.A.S.</h1>')
      +'<button onclick="document.getElementById(&quot;dsplash&quot;).remove()" style="background:linear-gradient(90deg,#1976d2,#0d2b5e);color:#fff;border:none;border-radius:30px;padding:14px 46px;font-size:16px;font-weight:700;cursor:pointer;box-shadow:0 6px 20px rgba(21,101,192,.35)">Ingresar →</button>'
      +'<small style="color:#8f8f8f;font-size:11px">Argentine Transformer for Learning and Advanced Semantics · by MMFC</small></div>';
    bodyInner=splash+bodyInner;
    const min=aj.replace(/^[ \t]+/gm,"").replace(/\n{2,}/g,"\n");
    // --- cifrado XOR + base64 (ofuscación anti-copia) ---
    const KEY="ARTLAS-"+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2)+"-MMFC";
    const xr=s=>{ let o=""; for(let i=0;i<s.length;i++) o+=String.fromCharCode(s.charCodeAt(i)^KEY.charCodeAt(i%KEY.length)); return o; };
    const enc=s=>btoa(xr(unescape(encodeURIComponent(s))));
    const E_STYLE=enc(styleCss), E_BODY=enc(bodyInner), E_JS=enc(min);
    const shell="<!DOCTYPE html><html lang=\"es\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>AR.T.L.A.S.</title>"
      +"<script src=\"https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js\"><\/script>"
      +"<script src=\"https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js\"><\/script>"
      +"<script>var _K="+JSON.stringify(KEY)+";function _dx(b){var d=atob(b),o=\"\";for(var i=0;i<d.length;i++)o+=String.fromCharCode(d.charCodeAt(i)^_K.charCodeAt(i%_K.length));return decodeURIComponent(escape(o));}"
      +"document.write(\"<style>\"+_dx("+JSON.stringify(E_STYLE)+")+\"<\\/style>\");<\/script></head><body>"
      +"<script>document.body.innerHTML=_dx("+JSON.stringify(E_BODY)+");var _s=document.createElement('script');_s.textContent=_dx("+JSON.stringify(E_JS)+");document.body.appendChild(_s);"
      +"document.addEventListener(\"contextmenu\",function(e){e.preventDefault();});"
      +"document.addEventListener(\"keydown\",function(e){var k=(e.key||\"\").toLowerCase();if(k===\"f12\"||(e.ctrlKey&&e.shiftKey&&(k===\"i\"||k===\"j\"||k===\"c\"))||(e.ctrlKey&&k===\"u\")){e.preventDefault();}});<\/script></body></html>";
    const zip=new JSZip();
    zip.file("ARTLAS.html",shell);
    try{ const _ib=atob(ARTLAS_ICO_B64); const _ia=new Uint8Array(_ib.length); for(let i=0;i<_ib.length;i++)_ia[i]=_ib.charCodeAt(i); zip.file("ARTLAS.ico",_ia); }catch(e){}
    try{ zip.file("Crear acceso directo.bat", atob(DESK_SHORTCUT_BAT_B64)); }catch(e){}
    zip.file("LEEME.txt","AR.T.L.A.S. __ARTLAS_VER__ — Versión escritorio (by MMFC)\r\n\r\n1. Descomprimí el zip (dejá todos los archivos juntos en una carpeta).\r\n2. (Opcional) Doble click en «Crear acceso directo.bat» para tener el icono de ARTLAS en el Escritorio.\r\n3. Abrí ARTLAS.html (o el acceso directo con el logo) con doble click (Chrome o Edge).\r\n4. Configurá tus API keys en Conexiones API, o iniciá sesión para traerlas de la nube.\r\n\r\nNota: si Windows bloquea el .bat al descomprimir, clic derecho al zip → Propiedades → Desbloquear, y descomprimí de nuevo.\r\n\r\nDiseñado por el Prof. Mario M. Figueroa de la Cruz");
    const blob=await zip.generateAsync({type:"blob"});
    const dl=document.createElement("a"); dl.href=URL.createObjectURL(blob); dl.download="ARTLAS-__ARTLAS_VER__-escritorio.zip"; dl.click();
    note.textContent="✓ Descargado con código cifrado. Abrí ARTLAS.html en Chrome o Edge.";
  }catch(e){ note.textContent="⚠️ Error: "+(e.message||e); }
}

/* ================= BACKEND (Netlify Functions) ================= */
/* Si el sitio está desplegado con el backend, todas las llamadas a las APIs
   pasan por /api/proxy (sin problemas de CORS). Si no existe, cae
   automáticamente a la llamada directa desde el navegador. */
let BACKEND=null; // null = desconocido · true = disponible · false = no disponible
async function apiFetch(url,opts){
  const isLocalTarget=/localhost|127\.0\.0\.1|192\.168\./.test(url);
  const isHttp=location.protocol==="http:"||location.protocol==="https:";
  if(!isLocalTarget && isHttp && BACKEND!==false && !(typeof window!=="undefined"&&window.ARTLAS_DIRECT_ONLY)){
    try{
      const r=await fetch("/api/proxy",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({url,method:(opts&&opts.method)||"POST",headers:(opts&&opts.headers)||{},body:(opts&&opts.body)||null})});
      if(r.status===404||r.status===405&&!(r.headers.get("content-type")||"").includes("json")){ BACKEND=false; }
      else { BACKEND=true; return r; }
    }catch(e){ BACKEND=false; }
  }
  return fetch(url,opts);
}

/* ================= APIs ================= */
async function callProvider(pk,c,messages,sys,imgs,maxTok){
  const model=(c&&c.model)||PROVIDERS[pk].defModel;
  imgs=imgs||[];
  messages=messages.map(m=>({...m}));
  const last=messages[messages.length-1];
  if(pk==="openai"){
    if(imgs.length&&last) last.content=[{type:"text",text:last.content},...imgs.map(i=>({type:"image_url",image_url:{url:i.dataUrl}}))];
    const body={model,messages:[...(sys?[{role:"system",content:sys}]:[]),...messages]};
    const r=await apiFetch("https://api.openai.com/v1/chat/completions",{method:"POST",
      headers:{"Content-Type":"application/json","Authorization":"Bearer "+c.key},body:JSON.stringify(body)});
    const j=await r.json(); if(!r.ok)throw new Error(j.error?.message||r.status);
    return j.choices[0].message.content;
  }
  if(pk==="anthropic"){
    if(imgs.length&&last) last.content=[...imgs.map(i=>({type:"image",source:{type:"base64",media_type:i.mime,data:i.dataUrl.split(",")[1]}})),{type:"text",text:last.content}];
    const body={model,max_tokens:maxTok||4096,messages,...(sys?{system:sys}:{})};
    const r=await apiFetch("https://api.anthropic.com/v1/messages",{method:"POST",
      headers:{"Content-Type":"application/json","x-api-key":c.key,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},
      body:JSON.stringify(body)});
    const j=await r.json(); if(!r.ok)throw new Error(j.error?.message||r.status);
    return j.content.map(b=>b.text||"").join("");
  }
  if(pk==="gemini"){
    const contents=messages.map((m,ix)=>{
      const parts=[{text:typeof m.content==="string"?m.content:""}];
      if(ix===messages.length-1&&imgs.length) imgs.forEach(i=>parts.push({inline_data:{mime_type:i.mime,data:i.dataUrl.split(",")[1]}}));
      return {role:m.role==="assistant"?"model":"user",parts};
    });
    const body={contents,...(sys?{systemInstruction:{parts:[{text:sys}]}}:{}),...(maxTok?{generationConfig:{maxOutputTokens:maxTok}}:{})};
    const r=await apiFetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${c.key}`,
      {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const j=await r.json(); if(!r.ok)throw new Error(j.error?.message||r.status);
    return j.candidates[0].content.parts.map(p=>p.text||"").join("");
  }
  if(OA_PROVIDERS[pk]){
    const url=(OA_PROVIDERS[pk].url||"").replace(/\/$/,"");
    if(!c.key) throw new Error("Configurá tu API key de "+PROVIDERS[pk].label+" en Conexiones API.");
    if(imgs.length&&last) last.content=[{type:"text",text:last.content},...imgs.map(i=>({type:"image_url",image_url:{url:i.dataUrl}}))];
    const body={model:model||PROVIDERS[pk].defModel,messages:[...(sys?[{role:"system",content:sys}]:[]),...messages],...(maxTok?{max_tokens:maxTok}:{})};
    const r=await apiFetch(url+"/chat/completions",{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+c.key},body:JSON.stringify(body)});
    const j=await r.json(); if(!r.ok)throw new Error(j.error?.message||j.message||r.status);
    return j.choices[0].message.content;
  }
  if(pk==="other"){
    const url=(c.url||"").replace(/\/$/,"");
    if(!url||!c.key) throw new Error("Configurá URL base y API key en Conexiones API → Otras API Key");
    if(imgs.length&&last) last.content=[{type:"text",text:last.content},...imgs.map(i=>({type:"image_url",image_url:{url:i.dataUrl}}))];
    const body={model:model||"deepseek-chat",messages:[...(sys?[{role:"system",content:sys}]:[]),...messages],...(maxTok?{max_tokens:maxTok}:{})};
    const r=await apiFetch(url+"/chat/completions",{method:"POST",
      headers:{"Content-Type":"application/json","Authorization":"Bearer "+c.key},body:JSON.stringify(body)});
    const j=await r.json(); if(!r.ok)throw new Error(j.error?.message||j.message||r.status);
    return j.choices[0].message.content;
  }
  if(pk==="hf"){
    if(imgs.length&&last) last.content=[{type:"text",text:last.content},...imgs.map(i=>({type:"image_url",image_url:{url:i.dataUrl}}))];
    const body={model,messages:[...(sys?[{role:"system",content:sys}]:[]),...messages],max_tokens:maxTok||2048};
    const r=await apiFetch("https://router.huggingface.co/v1/chat/completions",{method:"POST",
      headers:{"Content-Type":"application/json","Authorization":"Bearer "+c.key},body:JSON.stringify(body)});
    const j2=await r.json(); if(!r.ok)throw new Error(j2.error?.message||j2.error||r.status);
    return j2.choices[0].message.content;
  }
  if(pk==="groq"){
    const body={model,messages:[...(sys?[{role:"system",content:sys}]:[]),...messages],
      temperature:c.temp??0.7,max_tokens:maxTok||(c.tokens??1024),top_p:c.topp??0.9};
    const r=await apiFetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",
      headers:{"Content-Type":"application/json","Authorization":"Bearer "+c.key},body:JSON.stringify(body)});
    const j=await r.json(); if(!r.ok)throw new Error(j.error?.message||r.status);
    return j.choices[0].message.content;
  }
  if(pk==="webllm"){
    if(!webllmEngine||!webllmReady) throw new Error("Cargá primero el modelo local en Conexiones API → ARTLAS Local (navegador).");
    const wmsgs=[...(sys?[{role:"system",content:sys}]:[]),...messages.map(m=>({role:(m.role==="assistant"?"assistant":"user"),content:typeof m.content==="string"?m.content:""}))];
    const out=await webllmEngine.chat.completions.create({messages:wmsgs,temperature:0.7,max_tokens:maxTok||800});
    return out.choices[0].message.content;
  }
  if(pk==="basic"){
    const sysMsgs=[...(sys?[{role:"system",content:sys}]:[]),...messages];
    const useHack=(model==="hackclub");
    // Backends gratuitos SIN API key. Si el elegido falla, prueba el otro automáticamente.
    const endpoints=useHack
      ?[{u:"https://ai.hackclub.com/chat/completions",m:null},{u:"https://text.pollinations.ai/openai",m:"openai"}]
      :[{u:"https://text.pollinations.ai/openai",m:model||"openai"},{u:"https://ai.hackclub.com/chat/completions",m:null}];
    for(const ep of endpoints){
      try{
        const body=ep.m?{model:ep.m,messages:sysMsgs}:{messages:sysMsgs};
        const r=await apiFetch(ep.u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
        if(r.ok){ const j=await r.json(); const t=j.choices?.[0]?.message?.content; if(t) return t; }
      }catch(e){ /* prueba el siguiente backend */ }
    }
    // Intento 2 (fallback): endpoint GET simple de Pollinations (texto plano)
    const flat=[...(sys?[{role:"system",content:"[Instrucciones] "+sys}]:[]),...messages]
      .map(m=>(m.role==="assistant"?"Asistente":"Usuario")+": "+(typeof m.content==="string"?m.content:"")).join("\n\n")
      + "\n\nAsistente:";
    const r2=await apiFetch("https://text.pollinations.ai/"+encodeURIComponent(flat.slice(-6000)),{method:"GET"});
    if(!r2.ok) throw new Error("Los servicios gratuitos sin key no responden ahora. Prob\u00e1: (1) el modelo \"Hack Club AI\" en B\u00e1sico gratis, (2) una API key GRATUITA de Groq (console.groq.com/keys) o Google Gemini (aistudio.google.com), o (3) el preset OpenRouter con un modelo \u00b7 GRATIS.");
    const txt=await r2.text();
    if(!txt || txt.trim().startsWith("<")) throw new Error("El servicio gratuito comunitario respondi\u00f3 con un error. Conect\u00e1 una API key gratuita de Groq (console.groq.com/keys) en \ud83d\udd11 Conexiones API y us\u00e1 AR.T.L.A.S. OSS.");
    return txt;
  }
  if(pk==="ollama"){
    if(imgs.length&&last) last.images=imgs.map(i=>i.dataUrl.split(",")[1]);
    const url=(c.url||"http://localhost:11434").replace(/\/$/,"");
    const body={model,stream:false,messages:[...(sys?[{role:"system",content:sys}]:[]),...messages]};
    const r=await fetch(url+"/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const j=await r.json(); if(!r.ok)throw new Error(j.error||r.status);
    return j.message.content;
  }
  throw new Error("Proveedor desconocido");
}
function simReply(txt,key){
  const m=MODELS[key]; let out="";
  if(m.sys) out+=`**Razonamiento** (simulado): analizo la consulta, evalúo enfoques y estructuro la mejor respuesta.\n\n`;
  out+=`Respuesta simulada de **${m.name}**.\n\nEste nivel se enruta a **${PROVIDERS[m.prov].label}** (\`${provModel(m.prov)}\`), pero todavía no configuraste la API key. Tocá 🔑 **Conexiones API**, pegá tu clave y esta misma conversación pasará a responder con el modelo real.`;
  return out;
}

/* ================= WORKFLOWS ================= */
document.addEventListener("click",e=>{ if(e.target.classList&&e.target.classList.contains("chk")&&e.target.closest("#a-caps")){ e.target.classList.toggle("on"); } });
let flows=JSON.parse(localStorage.getItem("atlas_flows")||"null")||[
 {name:"Informe técnico",steps:[
  {title:"Investigar",prompt:"Listá los puntos clave, datos, conceptos y estado del arte sobre: {{entrada}}",model:"auto"},
  {title:"Estructurar",prompt:"Organizá esta información en un índice de secciones lógico para un informe técnico:\n\n{{entrada}}",model:"auto"},
  {title:"Redactar",prompt:"Redactá el informe técnico completo, formal y claro en español, siguiendo esta estructura y contenido:\n\n{{entrada}}",model:"auto"}]}
];
let wfSteps=[];
function wfSaveLS(){ localStorage.setItem("atlas_flows",JSON.stringify(flows)); }
function wfModelOpts(sel){ return '<option value="auto"'+(sel==="auto"?" selected":"")+'>Modelo actual</option>'+Object.entries(MODELS).map(([k,m])=>`<option value="${k}"${sel===k?" selected":""}>${m.name}</option>`).join(""); }
function renderWfSteps(){
  $("wf-steps").innerHTML=wfSteps.map((s,ix)=>`<div class="agent-card">
    <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px"><b style="white-space:nowrap">Paso ${ix+1}</b>
      <input type="text" style="flex:1;min-width:80px;border:1px solid var(--border2);border-radius:8px;padding:6px 9px;font-size:12.5px" value="${esc(s.title)}" onchange="wfSteps[${ix}].title=this.value">
      <select style="border:1px solid var(--border2);border-radius:8px;padding:6px;font-size:11.5px;max-width:150px" onchange="wfSteps[${ix}].model=this.value">${wfModelOpts(s.model)}</select>
      <span style="cursor:pointer;color:var(--muted)" onclick="wfSteps.splice(${ix},1);renderWfSteps()">✕</span></div>
    <textarea style="width:100%;border:1px solid var(--border2);border-radius:8px;padding:8px;font-size:12.5px;min-height:56px;font-family:inherit" onchange="wfSteps[${ix}].prompt=this.value">${esc(s.prompt)}</textarea>
  </div>`).join("");
}
function wfAddStep(){ wfSteps.push({title:"Paso "+(wfSteps.length+1),prompt:"{{entrada}}",model:"auto"}); renderWfSteps(); }
function wfSave(){
  const name=$("wf-name").value.trim()||"Workflow sin nombre";
  if(!wfSteps.length){ alert("Agregá al menos un paso."); return; }
  const f={name,steps:JSON.parse(JSON.stringify(wfSteps))};
  const ix=flows.findIndex(x=>x.name===name);
  if(ix>=0)flows[ix]=f; else flows.unshift(f);
  wfSaveLS(); renderFlows(); $("wf-msg").textContent="✓ guardado"; setTimeout(()=>$("wf-msg").textContent="",2000);
}
function renderFlows(){
  $("wf-list").innerHTML=flows.map((f,ix)=>`<div class="kb-item"><span class="nm"><b>⛓️ ${esc(f.name)}</b> <small>· ${f.steps.length} paso${f.steps.length>1?"s":""}</small></span>
    <button class="btn" style="padding:4px 12px;font-size:12px" onclick="runFlow(${ix})">▶ Ejecutar</button>
    <button class="btn" style="padding:4px 10px;font-size:12px" onclick="wfEdit(${ix})">✎</button>
    <button class="btn" style="padding:4px 10px;font-size:12px" onclick="flows.splice(${ix},1);wfSaveLS();renderFlows()">✕</button></div>`).join("")||'<div class="note">No hay workflows guardados.</div>';
}
function wfEdit(ix){ const f=flows[ix]; if(!f)return; $("wf-name").value=f.name; wfSteps=JSON.parse(JSON.stringify(f.steps)); renderWfSteps(); }
async function runFlow(ix){
  const f=flows[ix]; if(!f)return;
  let data=$("wf-input").value.trim();
  if(!data){ alert("Escribí la entrada inicial del workflow."); $("wf-input").focus(); return; }
  const out=$("wf-out"); out.innerHTML="";
  for(let i=0;i<f.steps.length;i++){
    const s=f.steps[i];
    const lvl=(s.model&&s.model!=="auto"&&MODELS[s.model])?s.model:curModel;
    let pk=MODELS[lvl].prov; if(!connected(pk)) pk=connectedProviders()[0]||"basic";
    const prompt=s.prompt.includes("{{entrada}}")?s.prompt.split("{{entrada}}").join(data):s.prompt+"\n\nEntrada:\n"+data;
    const box=document.createElement("div"); box.className="agent-card";
    box.innerHTML=`<b>Paso ${i+1}: ${esc(s.title)}</b> <span class="tag">${PROVIDERS[pk].label}</span><div class="content" style="font-size:13px;margin-top:6px;white-space:pre-wrap">⏳ ejecutando…</div>`;
    out.appendChild(box); box.scrollIntoView({behavior:"smooth",block:"end"});
    try{
      const r=await callProvider(pk,cfg[pk]||{},[{role:"user",content:prompt}],MODELS[lvl].sys||null);
      data=r; box.querySelector(".content").innerHTML=md(r);
    }catch(e){ box.querySelector(".content").innerHTML='<span class="err">⚠️ '+esc((e.message||e)+"")+'</span>'; return; }
  }
  const fin=document.createElement("div"); fin.className="note"; fin.textContent="✓ Workflow completado.";
  out.appendChild(fin);
}
function wfInit(){ if(flows[0]){ $("wf-name").value=flows[0].name; wfSteps=JSON.parse(JSON.stringify(flows[0].steps)); } renderWfSteps(); renderFlows(); }

/* ================= AGENTS (GPT personalizado / Gema) ================= */
let agents=[]; let agDocs=[]; let agEditingName=null;
async function agentPut(a){ const d=await idbOpen(); return new Promise((res,rej)=>{ const tx=d.transaction("agents","readwrite"); tx.objectStore("agents").put(a); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
async function agentRemove(name){ const d=await idbOpen(); return new Promise((res,rej)=>{ const tx=d.transaction("agents","readwrite"); tx.objectStore("agents").delete(name); tx.oncomplete=res; tx.onerror=()=>rej(tx.error); }); }
async function agentsLoadAll(){ const d=await idbOpen(); return new Promise((res,rej)=>{ const rq=d.transaction("agents").objectStore("agents").getAll(); rq.onsuccess=()=>res(rq.result||[]); rq.onerror=()=>rej(rq.error); }); }
async function agentsInit(){
  try{ const old=JSON.parse(localStorage.getItem("atlas_agents")||"[]"); if(old.length){ for(const a of old) await agentPut(a); localStorage.removeItem("atlas_agents"); } }catch(e){}
  try{ agents=await agentsLoadAll(); }catch(e){ agents=[]; }
  if(!agents.length) agents=[{name:"Investigador Científico",type:"Investigador",goal:"Buscar papers sobre optimización de redes 5G con ML, comparar resultados y generar estado del arte.",caps:["Memoria","Herramientas","Planificación"],docs:[]}];
  renderAgents();
}
function agUpload(files){
  [...files].forEach(f=>{
    if(agDocs.length>=5){ alert("Máximo 5 documentos por agente."); return; }
    if(f.size>10*1024*1024){ alert(f.name+": máximo 10 MB por documento."); return; }
    const doc={name:f.name,text:"",status:"⏳"}; agDocs.push(doc); renderAgDocs();
    extractText(f).then(t=>{ doc.text=t.slice(0,300000); doc.status=""; renderAgDocs(); })
      .catch(e=>{ const ix=agDocs.indexOf(doc); if(ix>=0)agDocs.splice(ix,1); renderAgDocs(); alert("No pude leer "+f.name+": "+(e.message||e)); });
  });
  $("ag-file").value="";
}
function renderAgDocs(){ $("ag-docs").innerHTML=agDocs.map((d,ix)=>`<span class="att-chip">📄 ${esc(d.name)}${d.status?" "+d.status:""} <span class="x" onclick="agDocs.splice(${ix},1);renderAgDocs()">✕</span></span>`).join(""); }
function renderAgents(){
  $("a-list").innerHTML=agents.map((a,ix)=>`<div class="agent-card"><b>⚙️ ${esc(a.name)}</b> <span class="tag">${esc(a.type)}</span>
    <div class="tags">${(a.caps||[]).map(c=>`<span class="tag">${esc(c)}</span>`).join("")}${(a.docs&&a.docs.length)?`<span class="tag">📚 ${a.docs.length} doc${a.docs.length>1?"s":""}</span>`:""}</div>
    ${a.goal?`<div style="font-size:12px;color:var(--muted);margin-top:6px;line-height:1.5">${esc(a.goal).slice(0,140)}${a.goal.length>140?"…":""}</div>`:""}
    <div style="margin-top:10px">
      <button class="btn dark" style="padding:6px 14px;font-size:12px" onclick="agentChat(${ix})">💬 Chatear</button>
      <button class="btn" style="padding:6px 14px;font-size:12px;margin-left:6px" onclick="runAgent(${ix})">▶ Demo</button>
      <button class="btn" style="padding:6px 12px;font-size:12px;margin-left:6px" onclick="agentEdit(${ix})">✏️ Editar</button>
      <button class="btn" style="padding:6px 12px;font-size:12px;margin-left:6px" onclick="agentShare(${ix})">📤 Exportar</button>
      <button class="btn" style="padding:6px 12px;font-size:12px;margin-left:6px" onclick="agentDel(${ix})">🗑 Borrar agente</button>
    </div></div>`).join("")||`<div class="note">Todavía no creaste agentes.</div>`;
}
function createAgent(){
  if(agDocs.some(d=>d.status)){ alert("Un momento: todavía estoy leyendo un documento (⏳)."); return; }
  const caps=[...document.querySelectorAll("#a-caps .chk.on")].map(c=>c.textContent.trim());
  const a={name:$("a-name").value.trim()||"Agente sin nombre",type:$("a-type").value,goal:$("a-goal").value.trim(),caps,docs:agDocs.map(d=>({name:d.name,text:d.text}))};
  if(agEditingName){ const old=agEditingName; agEditingName=null; const i=agents.findIndex(x=>x.name===old); if(i>=0) agents.splice(i,1); if(old!==a.name){ try{agentRemove(old);}catch(e){} } const b=document.getElementById("a-create-btn"); if(b) b.textContent="＋ Crear agente"; }
  agents.unshift(a); agentPut(a); agDocs=[]; renderAgDocs(); renderAgents();
}
function agentEdit(ix){
  const a=agents[ix]; if(!a)return;
  $("a-name").value=a.name||""; $("a-type").value=a.type||"Investigador"; $("a-goal").value=a.goal||"";
  document.querySelectorAll("#a-caps .chk").forEach(c=>{ c.classList.toggle("on",(a.caps||[]).includes(c.textContent.trim())); });
  agDocs=(a.docs||[]).map(d=>({name:d.name,text:d.text||"",status:""})); renderAgDocs();
  agEditingName=a.name;
  const b=document.getElementById("a-create-btn"); if(b) b.textContent="💾 Guardar cambios";
  try{ document.getElementById("a-name").scrollIntoView({behavior:"smooth",block:"center"}); document.getElementById("a-name").focus(); }catch(e){}
}
function agentShare(ix){
  const a=agents[ix]; if(!a)return;
  const pack={atlas_agent:true,version:1,name:a.name,type:a.type,goal:a.goal,caps:a.caps||[],docs:a.docs||[]};
  const blob=new Blob([JSON.stringify(pack,null,2)],{type:"application/json"});
  const dl=document.createElement("a"); dl.href=URL.createObjectURL(blob);
  dl.download=(a.name||"agente").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")+".atlas-agent.json"; dl.click();
  try{ navigator.clipboard&&navigator.clipboard.writeText(JSON.stringify(pack)); }catch(e){}
  const log=$("a-log"); if(log) log.textContent="🔗 Agente \""+a.name+"\" exportado para compartir (.json descargado" + (navigator.clipboard?" y copiado al portapapeles":"") + ").";
}
function agentDel(ix){ const a=agents.splice(ix,1)[0]; if(a)agentRemove(a.name); renderAgents(); }
function buildAgentSys(a){
  let s=`Actuá como el agente "${a.name}" (tipo: ${a.type}).`;
  if(a.goal) s+=` Objetivo e instrucciones: ${a.goal}`;
  const hasDocs=a.docs&&a.docs.length;
  if(hasDocs) s+=" \u26a0 IMPORTANTE: respondé basándote PRINCIPALMENTE en el CONOCIMIENTO DEL AGENTE (los documentos cargados que están más abajo). Si la respuesta no figura en esos documentos, aclaralo explícitamente antes de complementar con conocimiento general. No inventes datos.";
  if(a.caps&&a.caps.length){ s+=` Capacidades declaradas: ${a.caps.join(", ")}.`;
    if(a.caps.includes("Gráficos")) s+=" Cuando ayude a comunicar, generá GRÁFICOS embebiendo un bloque HTML autocontenido con Chart.js (CDN de cdnjs) listo para copiar/abrir.";
    if(a.caps.includes("Navegación Web")) s+=" \u2705 Tenés NAVEGACIÓN WEB activa: antes de tu respuesta se ejecuta una búsqueda web real en varios sitios y sus resultados (títulos, URLs y extractos) se te inyectan más abajo bajo el rótulo RESULTADOS DE BÚSQUEDA WEB EN VIVO. Usá esos resultados reales, citá las URLs relevantes y NO inventes fuentes ni enlaces. Si los resultados no alcanzan, decilo. Priorizá SIEMPRE los documentos del agente si existen y complementá con la web.";
    if(a.caps.includes("Compartir")) s+=" Preparás tus salidas para compartir: entregá resúmenes exportables y, si corresponde, en formato listo para publicar (Markdown o HTML).";
  }
  if(hasDocs){
    s+="\n\n===== CONOCIMIENTO DEL AGENTE (fuente principal — usalo para responder) =====\n";
    let budget=40000;
    a.docs.forEach(d=>{ const t=(d.text||"").slice(0,Math.max(0,budget)); budget-=t.length; s+=`\n--- ${d.name} ---\n${t}\n`; });
  }
  return s;
}
function agentChat(ix){
  const a=agents[ix]; if(!a)return;
  goChat(); newChat();
  customSys=buildAgentSys(a);
  agentWebPending=!!(a.caps&&a.caps.includes("Navegación Web"));
  inp.placeholder=`Agente "${a.name}" activo — escribí tu mensaje…`;
  inp.focus();
}
function runAgent(ix){
  const a=agents[typeof ix==="number"?ix:0]||agents[0]; if(!a)return;
  const log=$("a-log"); log.textContent="";
  const steps=[`[PLAN] ${a.name}: descomponiendo objetivo en 4 sub-tareas`,
    "[TOOL] búsqueda → arXiv: 23 resultados · IEEE: 11 resultados",
    "[MEM ] guardando hallazgos en memoria del workspace",
    `[LLM ] síntesis con ${MODELS.dense.name} (${PROVIDERS.anthropic.label})`,
    "[EVAL] verificación de citas y consistencia … OK",
    "[DONE] estado del arte generado (demo) ✅"];
  steps.forEach((s,i)=>setTimeout(()=>{log.textContent+=s+"\n";log.scrollTop=log.scrollHeight;},i*550));
}

/* ================= ARQUITECTURA ================= */
function renderArch(){
  $("arch-provs").innerHTML = Object.entries(PROVIDERS).map(([k,p])=>{
    const on=connected(k);
    if(k==="ollama") return `<div class="arch-col">
      <div class="prov-node oss">${p.icon} Modelos OSS<span class="pst" style="color:${on?"var(--green)":"var(--amber)"}">${on?"● conectado":"○ simulado"}</span></div><div class="arch-line"></div>
      <div class="prov-node oss">Llama · Qwen · Mistral</div><div class="arch-line"></div>
      <div class="prov-node oss">Ollama / vLLM<br><small style="color:var(--muted);font-size:10px">inferencia local / self-hosted</small></div></div>`;
    return `<div class="arch-col"><div class="prov-node">${p.icon} ${p.label}<br><small style="color:var(--muted);font-size:10px">${p.sub}</small><span class="pst" style="color:${on?"var(--green)":"var(--amber)"}">${on?"● conectado · "+provModel(k):"○ simulado"}</span></div></div>`;
  }).join("");
  $("arch-map").innerHTML = Object.values(MODELS).map(m=>{
    const on=connected(m.prov);
    return `<div class="map-row"><b><span class="st ${on?"on":"off"}"></span> ${m.name}</b>
      <span>${PROVIDERS[m.prov].label} · <code>${provModel(m.prov)}</code></span>
      <span class="mmuted">— ${m.desc}</span></div>`;
  }).join("");
}

/* ================= PANTALLA INICIAL ================= */
function enterApp(){
  const s=$("splash"); if(!s)return;
  s.classList.add("hide");
  setTimeout(()=>{ s.remove(); inp.focus(); },650);
}
document.addEventListener("keydown",e=>{ if(e.key==="Enter"&&document.getElementById("splash"))enterApp(); });

/* ================= USUARIO (Supabase) ================= */
const SUPA_URL="https://dtvxsndbqiqkiwdvprqz.supabase.co";
const SUPA_KEY="sb_publishable_TrivMLry4-Ur7he73q4CkQ_KYmCZ5dm";
let supa=null;
try{ if(typeof window!=="undefined"&&window.supabase&&window.supabase.createClient) supa=window.supabase.createClient(SUPA_URL,SUPA_KEY); }catch(e){ supa=null; console.warn("Supabase no disponible:",e&&e.message); }
let user=null;
function openUser(){ if(!supa){ alert("El servicio de usuarios no carg\u00f3 (sin conexi\u00f3n). Reintent\u00e1 m\u00e1s tarde."); return; } updateUserUI(); $("user-overlay").classList.add("open"); }
function closeUser(){ $("user-overlay").classList.remove("open"); }
function updateUserUI(){
  $("user-label").textContent=user?user.email:"Iniciar sesi\u00f3n";
  if($("user-forms")){ $("user-forms").style.display=user?"none":"block"; $("user-logged").style.display=user?"block":"none"; }
  if(user&&$("u-mail-show")) $("u-mail-show").textContent=user.email;
}
function umsg(t,ok){ const el=$("u-msg"); el.textContent=t; el.style.color=ok?"var(--green)":"var(--red)"; }
async function doSignup(){
  const email=$("u-email").value.trim(), pass=$("u-pass").value;
  if(!email||pass.length<6){ umsg("Ingres\u00e1 email v\u00e1lido y contrase\u00f1a de 6+ caracteres."); return; }
  const {error}=await supa.auth.signUp({email,password:pass});
  if(error) umsg(error.message);
  else umsg("\u2713 Cuenta creada. Revis\u00e1 tu email y confirm\u00e1 la direcci\u00f3n antes de ingresar.",true);
}
async function doLogin(){
  const email=$("u-email").value.trim(), pass=$("u-pass").value;
  const {data,error}=await supa.auth.signInWithPassword({email,password:pass});
  if(error){ umsg(error.message); return; }
  user=data.user; updateUserUI(); umsg("\u2713 Sesi\u00f3n iniciada",true);
  await loadCloud(); setTimeout(closeUser,700);
}
async function doLogout(){
  await pushCloud(); // asegurar que lo último quede en la nube
  await supa.auth.signOut(); user=null; updateUserUI();
  if(confirm("\u00bfBorrar tus API keys de ESTE navegador?\n\nRecomendado en computadoras compartidas. Tus keys quedan guardadas en tu cuenta y vuelven solas al iniciar sesi\u00f3n.")){
    cfg={}; curModel="free"; save(); renderMenu(); if(curView==="arch")renderArch();
    umsg("Sesi\u00f3n cerrada \u00b7 keys borradas de este navegador",true);
  } else umsg("Sesi\u00f3n cerrada (las keys siguen en este navegador)",true);
}
async function pushCloud(){
  if(!supa||!user)return;
  try{
    await supa.from("atlas_profiles").upsert({id:user.id,cfg:{cfg,curModel,routeMode,routeMetric},updated_at:new Date().toISOString()});
    if($("user-sync"))$("user-sync").textContent="\u2601 sincronizado "+new Date().toLocaleTimeString();
  }catch(e){}
}
async function loadCloud(){
  if(!supa||!user)return;
  try{
    const {data}=await supa.from("atlas_profiles").select("cfg").eq("id",user.id).maybeSingle();
    if(data&&data.cfg){
      const d=data.cfg;
      if(d.cfg) cfg={...cfg,...d.cfg};
      if(d.curModel&&MODELS[d.curModel]) curModel=d.curModel;
      if(d.routeMode&&ROUTES[d.routeMode]) routeMode=d.routeMode;
      if(d.routeMetric) routeMetric=d.routeMetric;
      save(); renderMenu(); renderRoute();
      if($("user-sync"))$("user-sync").textContent="\u2601 configuraci\u00f3n cargada desde la nube";
    } else pushCloud();
  }catch(e){}
}
async function initUser(){
  if(!supa)return;
  try{ const {data}=await supa.auth.getSession();
    if(data&&data.session){ user=data.session.user; updateUserUI(); loadCloud(); }
  }catch(e){}
}

/* ================= INIT ================= */
function atlasBoot(){
  if(window.__atlasBooted) return; window.__atlasBooted=true;
  try{ if(!connected(MODELS[curModel].prov)){ const p=["anthropic","openai","gemini","groq","hf","other"].find(connected); curModel=p?levelOf(p):"free"; save(); } }catch(e){ console.error("boot-guard",e); }
  [renderNav,renderMenu,renderChats,updKbBadge,renderRoute,initUser,kbInit,agentsInit,wfInit].forEach(function(fn){ try{ fn(); }catch(e){ console.error("init "+(fn&&fn.name),e); } });
  if(chats.length){ try{ openChat(chats[0].id); }catch(e){} }
}
try{ atlasBoot(); }catch(e){ console.error("atlasBoot",e); }


/* ==================================================================
   ==================  I18N  (Español / English)  ===================
   Arranque por defecto en español. Botón 🌐 para pasar todo a inglés.
   Traduce interfaz (estática y dinámica), voz y respuestas del modelo.
   ================================================================== */
let atlasLang = localStorage.getItem("atlas_lang")||"es";
const I18N_ES2EN = {
  /* ---- Sidebar / chrome ---- */
  "✏️ Nueva conversación":"✏️ New chat",
  "Motores":"Engines","Módulos":"Modules","Conversaciones":"Conversations",
  "Iniciar sesión":"Sign in","🔑 Conexiones API":"🔑 API Connections",
  "🧭 Ruteo:":"🧭 Routing:","Único":"Single",
  "¿En qué puedo ayudarte?":"How can I help you?",
  "Explicame la arquitectura de una red 5G standalone":"Explain the architecture of a 5G standalone network",
  "Escribí un script Python para analizar un CSV de tráfico":"Write a Python script to analyze a traffic CSV",
  "Buscá papers sobre ML aplicado a telecomunicaciones":"Find papers on ML applied to telecommunications",
  "Resumime qué es RAG en 3 párrafos":"Summarize what RAG is in 3 paragraphs",
  "AR.T.L.A.S. puede cometer errores. Verificá la información importante.":"AR.T.L.A.S. can make mistakes. Verify important information.",
  /* titles / placeholders */
  "Cambiar de modelo":"Switch model","Selección de ruteo":"Routing selection",
  "Conexiones API":"API Connections","Más opciones":"More options",
  "Dictado por voz":"Voice dictation","Enviar":"Send",
  "Escribí un mensaje a AR.T.L.A.S.…":"Type a message to AR.T.L.A.S.…",
  "Ej: optimización de redes 5G con machine learning":"E.g.: 5G network optimization with machine learning",
  "Ej: calculadora de presupuesto de enlace de radio (link budget) con sliders y resultado en vivo":"E.g.: radio link budget calculator with sliders and live result",
  "mínimo 6 caracteres":"minimum 6 characters",
  /* + menu */
  "Adjuntar fotos y archivos":"Attach photos and files","Subir desde la computadora":"Upload from computer",
  "Buscar en la web":"Search the web","Noticias e información en tiempo real":"Real-time news and information",
  "Investigar a fondo":"Deep research","Obtené un informe detallado":"Get a detailed report",
  "Accedé a repositorios, issues y código":"Access repositories, issues and code",
  /* Workflows */
  "Automatizaciones en cadena: la salida de cada paso alimenta al siguiente. Usá {{entrada}} en el prompt para insertar el texto inicial o el resultado del paso anterior. Cada paso puede usar una LLM distinta.":"Chained automations: each step's output feeds the next. Use {{entrada}} in the prompt to insert the initial text or the previous step's result. Each step can use a different LLM.",
  "Editor de workflow":"Workflow editor","Nombre":"Name","＋ Agregar paso":"＋ Add step",
  "💾 Guardar workflow":"💾 Save workflow","Mis workflows":"My workflows","Entrada inicial":"Initial input",
  /* Agents */
  "Creá agentes como un GPT personalizado o una Gema: con instrucciones y conocimiento propios, listos para chatear con cualquier LLM conectada.":"Create agents like a custom GPT or a Gem: with their own instructions and knowledge, ready to chat with any connected LLM.",
  "Nuevo agente":"New agent","Tipo":"Type",
  "Investigador":"Researcher","Personal":"Personal","Empresarial":"Business","Universitario":"University",
  "Soporte":"Support","Ventas":"Sales","Autónomo":"Autonomous",
  "Objetivo e instrucciones":"Goal and instructions",
  "Buscar papers sobre optimización de redes 5G con ML, comparar resultados y generar estado del arte.":"Find papers on 5G network optimization with ML, compare results and generate a state of the art.",
  "Capacidades":"Capabilities","Memoria":"Memory","Herramientas":"Tools","Planificación":"Planning",
  "APIs externas":"External APIs","Colaborativo":"Collaborative",
  "Conocimiento del agente (PDF, Word, Excel, texto — hasta 5 documentos de 10 MB)":"Agent knowledge (PDF, Word, Excel, text — up to 5 documents of 10 MB)",
  "⬆ Agregar documentos":"⬆ Add documents","＋ Crear agente":"＋ Create agent",
  "Agentes activos":"Active agents","— sin ejecuciones —":"— no runs —",
  /* Arch */
  "🗺️ Arquitectura del Orquestador":"🗺️ Orchestrator Architecture",
  "Flujo de una consulta: el orquestador enruta cada petición al proveedor óptimo según el nivel ARTLAS seleccionado. El punto verde indica proveedor conectado con API real.":"Query flow: the orchestrator routes each request to the optimal provider based on the selected ARTLAS level. The green dot indicates a provider connected with a real API.",
  "👤 Usuario":"👤 User","Interfaz Web":"Web Interface","Orquestador IA":"AI Orchestrator",
  "selección de modelo · routing · fallback · memoria":"model selection · routing · fallback · memory",
  "Mapeo nivel → proveedor":"Level → provider mapping",
  /* Artifacts */
  "🧩 Artefactos":"🧩 Artifacts","Artefactos":"Artifacts",
  "Describí la app o página que querés y ARTLAS la construye como HTML autocontenido: vista previa en vivo, iteración por prompts, descarga y publicación con link compartible.":"Describe the app or page you want and ARTLAS builds it as self-contained HTML: live preview, prompt iteration, download and publishing with a shareable link.",
  "✨ Generar artefacto":"✨ Generate artifact","🔁 Pedir cambios":"🔁 Request changes",
  "⬇ Descargar HTML":"⬇ Download HTML","🌐 Publicar (copiar link)":"🌐 Publish (copy link)",
  "💾 Guardar":"💾 Save","Guardar":"Save","Cancelar":"Cancel",
  "Link del artefacto publicado (servido desde tu sitio):":"Published artifact link (served from your site):",
  "📋 Copiar":"📋 Copy","↗ Abrir":"↗ Open","Mis artefactos":"My artifacts",
  "Todavía no guardaste artefactos.":"You haven't saved any artifacts yet.",
  /* Analytics */
  "📈 Analíticas":"📈 Analytics","Analíticas":"Analytics",
  "Subí un Excel o CSV (hasta 60 MB) y ARTLAS arma el dashboard automáticamente: KPIs, gráficos, análisis con recomendaciones y minería de patrones ocultos.":"Upload an Excel or CSV (up to 60 MB) and ARTLAS builds the dashboard automatically: KPIs, charts, analysis with recommendations and hidden-pattern mining.",
  "⬆ Subir archivo (Excel / CSV — hasta 60 MB)":"⬆ Upload file (Excel / CSV — up to 60 MB)",
  "🧠 Análisis y recomendaciones":"🧠 Analysis and recommendations",
  "⛏️ Data Mining (patrones ocultos)":"⛏️ Data Mining (hidden patterns)",
  /* Desktop */
  "🖥️ Versión escritorio":"🖥️ Desktop version","Versión escritorio":"Desktop version",
  "⬇ Descargar AR.T.L.A.S. Escritorio (.zip)":"⬇ Download AR.T.L.A.S. Desktop (.zip)",
  /* User */
  "👤 Usuario AR.T.L.A.S.":"👤 AR.T.L.A.S. User",
  "Con tu cuenta, tus API keys y preferencias se guardan en la nube (Supabase) y te siguen en cualquier dispositivo o navegador.":"With your account, your API keys and preferences are saved in the cloud (Supabase) and follow you on any device or browser.",
  "Contraseña":"Password","Ingresar":"Sign in","Crear cuenta":"Create account",
  "Sesión iniciada como":"Signed in as","☁ Sincronizar ahora":"☁ Sync now","Cerrar sesión":"Sign out",
  "Conectá cada proveedor con tu propia API key. Las claves se guardan solo en este navegador (localStorage). Sin clave, el modelo responde en modo simulado.":"Connect each provider with your own API key. Keys are stored only in this browser (localStorage). Without a key, the model replies in simulated mode.",
  /* Módulos: títulos (los ingleses quedan igual) */
  "Image":"Image","Code":"Code","Web Design":"Web Design","Presentations":"Presentations",
  "MCP":"MCP","Knowledge":"Knowledge","Research":"Research","Cowork":"Cowork",
  /* Módulos: intros */
  "Generá imágenes con IA. Escribí tu prompt, copialo y abrilo en el generador que prefieras — algunos reciben el prompt directo por URL.":"Generate images with AI. Write your prompt, copy it and open it in the generator you prefer — some receive the prompt directly via URL.",
  "Asistente de programación. Usá el chat de ARTLAS con un perfil experto en código (con tu API conectada), o abrí las herramientas especializadas.":"Programming assistant. Use ARTLAS chat with a code-expert profile (with your API connected), or open the specialized tools.",
  "Generá sitios web. Con tu API conectada, ARTLAS genera el HTML y lo previsualiza acá mismo. O usá los generadores externos especializados.":"Generate websites. With your API connected, ARTLAS generates the HTML and previews it right here. Or use the specialized external generators.",
  "Generá presentaciones. Escribí el tema, copialo y abrilo en el generador que prefieras.":"Generate presentations. Write the topic, copy it and open it in the generator you prefer.",
  "Model Context Protocol: el estándar abierto para conectar LLMs con herramientas externas. Explorá registros de servidores MCP listos para usar.":"Model Context Protocol: the open standard for connecting LLMs with external tools. Explore registries of ready-to-use MCP servers.",
  "Subí documentos (PDF, Word, Excel, texto — hasta 50 MB) y activalos para que el chat de ARTLAS los use como contexto en sus respuestas.":"Upload documents (PDF, Word, Excel, text — up to 50 MB) and enable them so ARTLAS chat uses them as context in its answers.",
  "Investigación científica. Buscá en las bases académicas directamente, o usá ARTLAS Deep Research con tu API conectada.":"Scientific research. Search academic databases directly, or use ARTLAS Deep Research with your API connected.",
  "Trabajo colaborativo: exportá tus conversaciones y GPTs para compartir con tu equipo, o importá las de otros.":"Collaborative work: export your conversations and GPTs to share with your team, or import others'.",
  /* Routes */
  "Responde solo el modelo seleccionado arriba":"Only the model selected above responds",
  "Inteligente":"Smart","El orquestador elige el mejor LLM según tu consulta y la métrica elegida":"The orchestrator picks the best LLM based on your query and the chosen metric",
  "Simultáneo":"Simultaneous","Hasta 3 LLMs conectadas responden en paralelo, una debajo de otra":"Up to 3 connected LLMs answer in parallel, one below the other",
  "Consenso (Random Forest)":"Consensus (Random Forest)","Varias LLMs responden y otra sintetiza la mejor respuesta de consenso":"Several LLMs answer and another synthesizes the best consensus response",
  /* Model descriptions */
  "Modelo básico gratuito — funciona sin API key":"Free basic model — works without an API key",
  "Open source acelerado (Llama 3.3 70B vía Groq)":"Accelerated open source (Llama 3.3 70B via Groq)",
  "Modelos locales privados (Ollama en tu PC)":"Private local models (Ollama on your PC)",
  "Qwen · Kimi · DeepSeek · Z.AI — vía endpoint OpenAI-compatible":"Qwen · Kimi · DeepSeek · Z.AI — via OpenAI-compatible endpoint",
  "Modelos OSS de Hugging Face — Llama, Qwen, Mistral, DeepSeek y miles más":"OSS models from Hugging Face — Llama, Qwen, Mistral, DeepSeek and thousands more",
  "Respuestas veloces para consultas y resúmenes":"Fast answers for queries and summaries",
  "Balance velocidad / calidad para uso diario":"Speed / quality balance for daily use",
  "Máxima precisión y contexto largo":"Maximum precision and long context",
  "Razonamiento explícito paso a paso":"Explicit step-by-step reasoning",
  "Problemas complejos: planifica y evalúa alternativas":"Complex problems: plans and evaluates alternatives",
  "Investigación: estructura, compara y cita fuentes":"Research: structures, compares and cites sources",
  /* Connection card labels (OpenRouter/HF/other) */
  "Proveedor (preset)":"Provider (preset)","URL base (OpenAI-compatible)":"Base URL (OpenAI-compatible)",
  "Modelo":"Model","Modelo (editable)":"Model (editable)","API key":"API key",
  "Elegí el LLM (una sola API key)":"Choose the LLM (a single API key)","Elegí el modelo":"Choose the model",
  "API key (token HF)":"API key (HF token)","Estado":"Status",
  "En Simultáneo / Consenso usar (varios modelos con la misma key):":"For Simultaneous / Consensus use (several models with the same key):",
  "— recordá poner el 🧭 Ruteo (arriba) en Simultáneo o Consenso para que respondan varios.":"— remember to set 🧭 Routing (top) to Simultaneous or Consensus so several respond.",
  "En Simultáneo / Consenso usar:":"For Simultaneous / Consensus use:",
  /* alerts / status */
  "Tu navegador no soporta dictado por voz. Probá con Chrome o Edge.":"Your browser doesn't support voice dictation. Try Chrome or Edge.",
  "Máximo 5 adjuntos por mensaje.":"Maximum 5 attachments per message.",
  "Un momento: todavía estoy leyendo un adjunto (⏳).":"One moment: I'm still reading an attachment (⏳).",
  "Un momento: todavía estoy leyendo un documento (⏳).":"One moment: I'm still reading a document (⏳).",
  "Primero generá un artefacto.":"Generate an artifact first.",
  "Escribí el cambio que querés en el mismo cuadro.":"Write the change you want in the same box.",
  "Primero subí un archivo.":"Upload a file first.",
  "Agregá al menos un paso.":"Add at least one step.",
  "Escribí la entrada inicial del workflow.":"Write the workflow's initial input.",
  "Máximo 5 documentos por agente.":"Maximum 5 documents per agent.",
  "Generando… (puede tardar un minuto)":"Generating… (may take a minute)",
  "Aplicando cambios…":"Applying changes…",
  "Armando paquete…":"Building package…",
  "La hoja no tiene datos.":"The sheet has no data.",
  "probando…":"testing…","✓ conectado":"✓ connected","⏳ cargando…":"⏳ loading…",
  "🔄 Actualizar lista":"🔄 Refresh list","✓ copiado":"✓ copied","✓ exportado":"✓ exported",
  "✓ guardado":"✓ saved","✓ Workflow completado.":"✓ Workflow completed.",
  "Ya estás usando la versión de escritorio. Esta descarga se hace desde el sitio publicado.":"You're already using the desktop version. This download is made from the published site."
};
/* mapa inverso EN→ES para volver a español */

/* --- v29: notas de proveedores en inglés (keyed por proveedor) --- */
const I18N_NOTES_EN = {
  openai:"Get your key at platform.openai.com → API keys. Models: gpt-4o, gpt-4o-mini, o3-mini…",
  anthropic:"Key at console.anthropic.com. Models: claude-sonnet-4-5, claude-haiku-4-5, claude-opus-4-8…",
  gemini:"Free key at aistudio.google.com → Get API key. Models: gemini-2.0-flash, gemini-2.5-pro…",
  groq:"Ultra-fast inference of open source models on a free plan. Get your <a href='https://console.groq.com/keys' target='_blank'>free API Key</a> at console.groq.com. Full model list at console.groq.com/docs/models — if one hits a rate limit, switch to another.",
  hf:"Access to thousands of open source models (Llama, Qwen, Mistral, DeepSeek, GLM…) via the Inference API. Free token at <a href='https://huggingface.co/settings/tokens' target='_blank'>huggingface.co/settings/tokens</a> (Read type). Example models: meta-llama/Llama-3.3-70B-Instruct · Qwen/Qwen2.5-72B-Instruct · deepseek-ai/DeepSeek-V3 · mistralai/Mistral-Small-24B-Instruct-2501",
  basic:"AR.T.L.A.S. default model — works without an API key, ideal to start right away. Uses the free community service Pollinations.ai (no guarantee of availability or privacy: don't send sensitive data).",
  ollama:"Requires Ollama running on your PC (ollama.com). Leave empty to disable; configure URL and model. If the browser blocks the connection, start Ollama with OLLAMA_ORIGINS=* .",
  webllm:"Download and run a small model INSIDE your browser, no install. Requires a WebGPU browser (recent Chrome or Edge). First time it downloads the model (~0.3–2 GB) and caches it. Works alongside the other models in routing (Simultaneous/Consensus).",
  other:"Any provider with an OpenAI-compatible endpoint: pick a preset or enter your base URL. ⚠️ Some providers block direct calls from the browser (CORS); if you get a connection error, use the OpenRouter preset — it groups Qwen, Kimi, DeepSeek and GLM in a single key and always works from the web (openrouter.ai/keys)."
};
function i18nNote(k,def){ return (atlasLang==="en"&&I18N_NOTES_EN[k])?I18N_NOTES_EN[k]:def; }
Object.assign(I18N_ES2EN, {
  "🔑 Conectar APIs…":"🔑 Connect APIs…",
  "Configurá tus claves de OpenAI, Gemini, Anthropic u Ollama":"Configure your OpenAI, Gemini, Anthropic or Ollama keys",
  "modo simulado (configurar API)":"simulated mode (configure API)",
  "Estás en modo simulado. Tocá ⚙️ para conectar tus API keys de OpenAI, Gemini, Claude u Ollama.":"You're in simulated mode. Tap ⚙️ to connect your OpenAI, Gemini, Claude or Ollama API keys.",
  "Simulado — sin API key":"Simulated — no API key",
  "● Activo por defecto — no requiere API key":"● Active by default — no API key required",
  "Métrica del ruteo inteligente:":"Smart routing metric:",
  "velocidad":"speed","equilibrio":"balance","calidad":"quality",
  "Ej: infografía isométrica de una red 5G con antenas, núcleo de red y dispositivos IoT, estilo flat design, colores azul y verde…":"E.g.: isometric infographic of a 5G network with antennas, core network and IoT devices, flat design style, blue and green colors…",
  "Ej: pitch deck de 10 slides para una startup de análisis de datos en telecomunicaciones: problema, solución, mercado, modelo de negocio, roadmap…":"E.g.: 10-slide pitch deck for a data-analytics startup in telecommunications: problem, solution, market, business model, roadmap…",
  /* descripciones de herramientas externas */
  "Generación integrada en ChatGPT. Recibe tu prompt por URL.":"Integrated generation in ChatGPT. Receives your prompt via URL.",
  "DALL·E gratis con cuenta Microsoft. Recibe tu prompt por URL.":"Free DALL·E with a Microsoft account. Receives your prompt via URL.",
  "Imagen 3 de Google, gratuito con cuenta Google.":"Google's Imagen 3, free with a Google account.",
  "Arte y renders de alta calidad, plan gratuito diario.":"High-quality art and renders, daily free plan.",
  "Excelente para texto dentro de imágenes y logos.":"Great for text inside images and logos.",
  "Modelos open source de generación de imágenes.":"Open source image-generation models.",
  "Autocompletado y chat dentro de tu editor.":"Autocomplete and chat inside your editor.",
  "Editor con IA integrada para proyectos completos.":"Editor with built-in AI for complete projects.",
  "IDE online con agente que crea apps completas.":"Online IDE with an agent that builds complete apps.",
  "Notebooks Python gratis con GPU y Gemini integrado.":"Free Python notebooks with GPU and built-in Gemini.",
  "Entorno web instantáneo para JS/TS.":"Instant web environment for JS/TS.",
  "Editor agéntico gratuito de Codeium.":"Codeium's free agentic editor.",
  "Genera interfaces React/Tailwind desde texto.":"Generates React/Tailwind interfaces from text.",
  "Apps web full-stack generadas por IA.":"Full-stack web apps generated by AI.",
  "De idea a app web publicada, sin código.":"From idea to a published web app, no code.",
  "Sitios con diseño profesional generados por IA.":"Professionally designed sites generated by AI.",
  "Diseño web visual con asistencia de IA.":"Visual web design with AI assistance.",
  "Presentaciones, documentos y webs desde un prompt. El mejor para empezar.":"Presentations, documents and sites from a prompt. Best to start with.",
  "Diseños y presentaciones con IA, enorme biblioteca.":"AI designs and presentations, huge library.",
  "Slides con diseño automático inteligente.":"Slides with smart automatic design.",
  "Decks tipo ChatGPT-para-presentaciones.":"ChatGPT-for-presentations style decks.",
  "Convierte texto en slides dentro de Google Slides.":"Turns text into slides inside Google Slides.",
  "Documentación oficial del protocolo y guías de inicio.":"Official protocol documentation and getting-started guides.",
  "Repositorio con servidores MCP de referencia.":"Repository with reference MCP servers.",
  "Directorio comunitario con miles de servidores MCP.":"Community directory with thousands of MCP servers.",
  "Registro e instalación de servidores MCP en un click.":"MCP server registry and one-click install.",
  "Catálogo curado con métricas de calidad.":"Curated catalog with quality metrics.",
  "Sube PDFs y fuentes; Google genera resúmenes y podcasts.":"Upload PDFs and sources; Google generates summaries and podcasts.",
  "Conversá con cualquier PDF.":"Chat with any PDF.",
  "Colecciones de archivos + búsqueda con IA.":"File collections + AI search.",
  "Respuestas con citas de fuentes en tiempo real.":"Answers with real-time source citations.",
  "Asistente de revisión sistemática de papers.":"Systematic paper-review assistant.",
  "Responde preguntas con evidencia de papers.":"Answers questions with evidence from papers.",
  "Lee y explica papers con IA.":"Reads and explains papers with AI.",
  "Workspace colaborativo con IA integrada.":"Collaborative workspace with built-in AI.",
  "Comunicación de equipo, integrable con LLMs.":"Team communication, integrable with LLMs.",
  "Colaboración con Copilot integrado.":"Collaboration with built-in Copilot.",
  "Versionado y colaboración para el código de ARTLAS.":"Versioning and collaboration for ARTLAS's code."
});

Object.assign(I18N_ES2EN, {
  "Subí hasta 3 archivos Excel/CSV (60 MB c/u), combiná los datos y armá un dashboard con hasta 8 gráficos y 6 KPIs. Evaluá los resultados con IA y generá un Reporte o una Página web descargables.":"Upload up to 3 Excel/CSV files (60 MB each), combine the data and build a dashboard with up to 8 charts and 6 KPIs. Evaluate the results with AI and generate a downloadable Report or Web page.",
  "⬆ Subir archivos (Excel / CSV — hasta 3 × 60 MB)":"⬆ Upload files (Excel / CSV — up to 3 × 60 MB)",
  "📄 Generar Reporte":"📄 Generate Report","🌐 Generar Página web":"🌐 Generate Web page",
  "Link de la página publicada (servida desde tu sitio):":"Published page link (served from your site):",
  "Gráficos":"Charts","Navegación Web":"Web navigation","Compartir":"Share","🔗 Compartir":"🔗 Share",
  "KPIs (hasta 6) —":"KPIs (up to 6) —","Gráficos (hasta 8) —":"Charts (up to 8) —",
  "Armando paquete cifrado…":"Building encrypted package…",
  "🧠 Análisis y recomendaciones":"🧠 Analysis and recommendations",
  "⛏️ Data Mining (patrones ocultos)":"⛏️ Data Mining (hidden patterns)",
  "Subí uno o más archivos para empezar.":"Upload one or more files to start."
});
Object.assign(I18N_ES2EN, {
  "🔗 Link prueba":"🔗 Test link","📤 Exportar":"📤 Export"
});
Object.assign(I18N_ES2EN, {"En Simultáneo / Consenso usar (modelos gratis, sin API key):":"For Simultaneous / Consensus use (free models, no API key):"});
const I18N_EN2ES = {};
for (const k in I18N_ES2EN){ if(!(I18N_ES2EN[k] in I18N_EN2ES)) I18N_EN2ES[I18N_ES2EN[k]] = k; }

function i18nNorm(t){ return (t||"").replace(/ /g," ").replace(/\s+/g," ").trim(); }
let i18nBusy=false;
const I18N_SKIP = "#msgs,#art-preview";
function i18nSweep(root, dir){
  const map = dir==="es2en" ? I18N_ES2EN : I18N_EN2ES;
  i18nBusy=true;
  // nodos de texto
  const w=document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
  const jobs=[];
  let n; while(n=w.nextNode()){
    const p=n.parentElement; if(!p) continue;
    if(p.closest && p.closest(I18N_SKIP)) continue;
    const key=i18nNorm(n.nodeValue);
    if(key && map[key]!=null){
      const lead=/^\s/.test(n.nodeValue)?" ":""; const trail=/\s$/.test(n.nodeValue)?" ":"";
      jobs.push([n, lead+map[key]+trail]);
    }
  }
  jobs.forEach(([node,val])=>{ node.nodeValue=val; });
  // atributos placeholder / title
  const els = root.querySelectorAll?root.querySelectorAll("[placeholder],[title]"):[];
  els.forEach(el=>{
    if(el.closest && el.closest(I18N_SKIP)) return;
    ["placeholder","title"].forEach(a=>{
      if(!el.hasAttribute(a)) return;
      const key=i18nNorm(el.getAttribute(a));
      if(key && map[key]!=null) el.setAttribute(a, map[key]);
    });
  });
  i18nBusy=false;
}
function setVoiceLang(){ try{ if(typeof rec!=="undefined" && rec) rec.lang = atlasLang==="en"?"en-US":"es-AR"; }catch(e){} }
function updateLangBtn(){ const b=document.getElementById("lang-btn"); if(b) b.innerHTML = atlasLang==="en"?"🌐 ES":"🌐 EN"; }
function applyLangInitial(){
  document.documentElement.lang = atlasLang;
  if(atlasLang==="en") i18nSweep(document.body,"es2en");
  updateLangBtn();
}
function toggleLang(){
  atlasLang = atlasLang==="en" ? "es" : "en";
  localStorage.setItem("atlas_lang", atlasLang);
  document.documentElement.lang = atlasLang;
  i18nSweep(document.body, atlasLang==="en" ? "es2en" : "en2es");
  updateLangBtn(); setVoiceLang();
  try{ var ov=document.getElementById("overlay"); if(ov&&ov.classList.contains("open")) openSettings(); }catch(e){}
}
/* traducir contenido renderizado dinámicamente cuando está en inglés */
const i18nObserver = new MutationObserver(muts=>{
  if(atlasLang!=="en" || i18nBusy) return;
  for(const m of muts){
    if(m.type==="childList"){
      m.addedNodes.forEach(nd=>{
        if(nd.nodeType===1){ if(nd.closest && nd.closest(I18N_SKIP)) return; i18nSweep(nd,"es2en"); }
        else if(nd.nodeType===3){
          const p=nd.parentElement; if(p&&p.closest&&p.closest(I18N_SKIP))return;
          const key=i18nNorm(nd.nodeValue);
          if(key&&I18N_ES2EN[key]!=null){ i18nBusy=true; nd.nodeValue=I18N_ES2EN[key]; i18nBusy=false; }
        }
      });
    }
  }
});
function i18nStart(){
  applyLangInitial();
  i18nObserver.observe(document.body,{childList:true,subtree:true,characterData:false});
}
if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", i18nStart);
else i18nStart();

function enSys(base){ return (typeof atlasLang!=="undefined"&&atlasLang==="en")?(base+"\n\nWrite in English."):base; }


/* ============ NAV MÓVIL (drawer) ============ */
function toggleNav(force){
  try{ const open=(typeof force==="boolean")?force:!document.body.classList.contains("nav-open"); document.body.classList.toggle("nav-open",open); }catch(e){}
}
document.addEventListener("click",function(e){
  try{
    if(!window.matchMedia||!window.matchMedia("(max-width:820px)").matches) return;
    const sb=document.getElementById("sidebar"); if(!sb||!sb.contains(e.target)) return;
    if(e.target.closest(".side-btn,.chat-item")) document.body.classList.remove("nav-open");
  }catch(_){}
});
