
/* =====================================================================
   AR.T.L.A.S. · Módulo 95 · AR.T.L.A.S. OS — IA LOCAL Y MOTOR DEL ASISTENTE
   Dos caminos para correr modelos en la propia máquina, junto a las APIs:
     · En el navegador (WebLLM · WebGPU): sin instalar nada; usa webllmLoad() de la base.
     · En la PC con Ollama, a través del núcleo (sin configurar CORS).
   Motor del asistente:
     auto        → el router de AR.T.L.A.S. (smartPick) elige entre las APIs conectadas
     local       → local primero; si no hay modelo local, el router
     solo-local  → privado y sin internet; si no hay modelo local, avisa
     <proveedor> → siempre ese proveedor
   Privacidad: con «contenidos solo en local», el texto de los archivos nunca
   se envía a una API externa.
   ===================================================================== */
const AOS_WEBLLM_REC=[
  ["Qwen2.5-0.5B-Instruct-q4f16_1-MLC","Qwen2.5 0.5B","≈0,4 GB",aosL("Ultra liviano: comandos simples y equipos modestos","Ultra light: simple commands, modest hardware")],
  ["Llama-3.2-1B-Instruct-q4f16_1-MLC","Llama 3.2 1B","≈0,9 GB",aosL("Rápido, buen español básico","Fast, decent multilingual")],
  ["Qwen2.5-1.5B-Instruct-q4f16_1-MLC","Qwen2.5 1.5B","≈1,1 GB",aosL("Recomendado para el asistente del OS","Recommended for the OS assistant")],
  ["Qwen2.5-3B-Instruct-q4f16_1-MLC","Qwen2.5 3B","≈2 GB",aosL("Más capaz; necesita GPU con 4 GB","More capable; needs a 4 GB GPU")],
  ["Phi-3.5-mini-instruct-q4f16_1-MLC","Phi 3.5 mini","≈2,2 GB",aosL("Razonamiento y código","Reasoning and code")]
];
const AOS_OLLAMA_REC=[
  ["qwen2.5:1.5b","≈1 GB",aosL("Liviano, muy bueno con herramientas","Light, good with tools")],
  ["llama3.2:3b","≈2 GB",aosL("Equilibrado","Balanced")],
  ["phi4-mini","≈2,5 GB",aosL("Razonamiento","Reasoning")],
  ["gemma3:4b","≈3,3 GB",aosL("Multilingüe, entiende imágenes","Multilingual, vision")],
  ["qwen2.5:7b","≈4,7 GB",aosL("El más capaz de la lista; 8 GB de RAM o más","Most capable here; 8 GB+ RAM")],
  ["qwen2.5-coder:7b","≈4,7 GB",aosL("Programación","Coding")]
];
function aosMotor(){ return v60LS("atlas_os_motor","auto"); }
function aosPriv(){ return v60LS("atlas_os_priv","0")==="1"; }
function aosLocalPk(){ try{ if(webllmReady) return "webllm"; }catch(e){} try{ if(connected("ollama")) return "ollama"; }catch(e){} return null; }
function aosIsLocal(pk){ return pk==="webllm"||pk==="ollama"; }
function aosPkLabel(pk){
  if(!pk) return aosL("sin motor","no engine");
  if(pk==="webllm") return aosL("Local · ","Local · ")+String((cfg.webllm&&cfg.webllm.model)||webllmModel||"").replace(/-q4f.*$/,"").replace(/-Instruct|-instruct/,"");
  if(pk==="ollama") return "Ollama · "+((cfg.ollama&&cfg.ollama.model)||PROVIDERS.ollama.defModel);
  try{ return provShort(pk); }catch(e){ return pk; }
}
function aosMotorPick(text){
  const m=aosMotor(), loc=aosLocalPk();
  if(m==="solo-local"){ if(!loc) throw new Error(aosL("Elegiste «solo local» pero no hay un modelo local cargado. Abrí Modelos IA.","You chose «local only» but no local model is loaded. Open AI Models.")); return loc; }
  if(m==="local"&&loc) return loc;
  if(m!=="auto"&&m!=="local"){ try{ if(connected(m)) return m; }catch(e){} }
  let pk="basic"; try{ const lvl=smartPick(text||""); pk=(MODELS[lvl]&&MODELS[lvl].prov)||"basic"; if(!connected(pk)) pk="basic"; }catch(e){}
  return pk;
}
function aosMotorInfo(){
  const m=aosMotor(); let pk=null; try{ pk=aosMotorPick(""); }catch(e){}
  const pre=m==="auto"?aosL("Router","Router"):m==="local"?aosL("Local primero","Local first"):m==="solo-local"?aosL("Solo local","Local only"):aosL("Fijo","Fixed");
  return {pk,local:aosIsLocal(pk),label:pre+": "+aosPkLabel(pk)};
}

/* ---------- app Modelos IA ---------- */
aosRegister("modelos",{title:()=>aosL("Modelos IA","AI models"),sub:()=>aosL("Locales y por API · motor del asistente","Local and API · assistant engine"),icon:"chip",desk:true,order:60,w:780,h:600,kw:"modelos ia local llm ollama webgpu motor router",
  render(win){ win.body.innerHTML=`<div class="aos-pad aosm"></div>`; aosmPaint(win); },
  reopen(win){ aosmPaint(win); }
});
async function aosmPaint(win){
  const B=win.body.querySelector(".aosm"); if(!B) return;
  const m=aosMotor(); let provs=[]; try{ provs=connectedProviders().filter(p=>p!=="webllm"); }catch(e){}
  const gpu=("gpu" in navigator);
  const opt=(v,t,d)=>`<label class="aos-card" style="display:flex;gap:10px;align-items:flex-start;cursor:pointer;padding:10px 12px;${m===v?"border-color:#1976d2;background:#f4f8fd":""}"><input type="radio" name="aosm-m" value="${v}" ${m===v?"checked":""} style="margin-top:3px"><span><b style="color:#0d2b5e;font-size:13px">${t}</b><br><span style="font-size:12px;color:#6b7a90">${d}</span></span></label>`;
  B.innerHTML=`<div class="aos-h">${aosL("Motor del asistente","Assistant engine")}</div>
  <p class="aos-sub">${aosL("AR.T.L.A.S. OS combina modelos locales, que corren en tu equipo, con las APIs que ya conectaste. Elegí cómo se reparte el trabajo.","AR.T.L.A.S. OS combines local models running on your device with the APIs you've connected. Choose how work is split.")}</p>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:8px;margin-bottom:10px">
    ${opt("auto",aosL("Automático (router)","Automatic (router)"),aosL("El router de AR.T.L.A.S. elige la mejor API para cada pedido.","The AR.T.L.A.S. router picks the best API per request."))}
    ${opt("local",aosL("Local primero","Local first"),aosL("Usa el modelo local si está cargado; si no, el router.","Uses the local model when loaded; otherwise the router."))}
    ${opt("solo-local",aosL("Solo local","Local only"),aosL("Privado y sin internet. Nada sale de tu equipo.","Private and offline. Nothing leaves your device."))}
    <label class="aos-card" style="display:flex;gap:10px;align-items:flex-start;padding:10px 12px;${!["auto","local","solo-local"].includes(m)?"border-color:#1976d2;background:#f4f8fd":""}"><input type="radio" name="aosm-m" value="fijo" ${!["auto","local","solo-local"].includes(m)?"checked":""} style="margin-top:3px"><span style="flex:1"><b style="color:#0d2b5e;font-size:13px">${aosL("Proveedor fijo","Fixed provider")}</b><br>
      <select class="aos-in aosm-fix" style="margin-top:5px;width:100%;font-size:12px;padding:4px 6px">${provs.map(p=>`<option value="${p}" ${m===p?"selected":""}>${aosEsc(aosPkLabel(p))}</option>`).join("")||`<option value="">${aosL("Conectá APIs en la plataforma","Connect APIs in the platform")}</option>`}</select></span></label>
  </div>
  <label style="display:flex;gap:8px;align-items:center;font-size:12.5px;color:#0d2b5e;margin-bottom:6px"><input type="checkbox" class="aosm-priv" ${aosPriv()?"checked":""}> ${aosL("El contenido de mis archivos solo lo procesa un modelo local","My file contents are only processed by a local model")}</label>
  <div style="font-size:12px;color:#6b7a90;margin-bottom:18px">${aosL("Ahora: ","Now: ")}<b class="aosm-now" style="color:#0d2b5e">${aosEsc(aosMotorInfo().label)}</b></div>

  <div class="aos-h">${aosL("En el navegador (WebGPU)","In the browser (WebGPU)")}</div>
  <p class="aos-sub">${gpu?aosL("Se descargan una sola vez y quedan guardados. Funcionan sin internet y sin instalar nada.","Downloaded once and cached. Work offline with nothing to install."):`<span style="color:#b26a00">${aosL("Este navegador no tiene WebGPU. Usá Chrome o Edge actualizados, o Ollama con el núcleo.","This browser lacks WebGPU. Use an up-to-date Chrome or Edge, or Ollama via the core.")}</span>`}</p>
  <div style="display:grid;gap:6px;margin-bottom:6px">${AOS_WEBLLM_REC.map(([id,n,sz,d])=>{ const on=(typeof webllmReady!=="undefined"&&webllmReady&&webllmModel===id);
    return `<div class="aos-card" style="display:flex;align-items:center;gap:10px;padding:9px 12px"><span style="flex:1"><b style="font-size:13px;color:#0d2b5e">${n}</b> <span class="aos-pill">${sz}</span>${on?` <span class="aos-pill ok">${aosL("cargado","loaded")}</span>`:""}<br><span style="font-size:12px;color:#6b7a90">${d}</span></span>
      ${on?`<button class="aos-btn sm" data-wu="1">${aosL("Descargar de memoria","Unload")}</button>`:`<button class="aos-btn sm ${id.startsWith("Qwen2.5-1.5B")?"pri":""}" data-wl="${id}" ${gpu?"":"disabled"}>${aosL("Cargar","Load")}</button>`}</div>`; }).join("")}</div>
  <div style="font-size:12px;color:#6b7a90;margin-bottom:18px;min-height:16px"><span id="webllm-status" class="aosm-wst"></span></div>

  <div class="aos-h">${aosL("En tu PC con Ollama","On your PC with Ollama")}</div>
  <div class="aosm-oll"><p class="aos-sub">${aosL("Consultando…","Checking…")}</p></div>`;
  B.querySelectorAll('input[name="aosm-m"]').forEach(r=>r.onchange=()=>{ const v=r.value==="fijo"?(B.querySelector(".aosm-fix").value||"auto"):r.value; v60LSset("atlas_os_motor",v); aosmPaint(win); aosPaintStatus(); });
  B.querySelector(".aosm-fix").onchange=e=>{ if(e.target.value){ v60LSset("atlas_os_motor",e.target.value); aosmPaint(win); aosPaintStatus(); } };
  B.querySelector(".aosm-priv").onchange=e=>{ v60LSset("atlas_os_priv",e.target.checked?"1":"0"); aosToast(e.target.checked?aosL("Tus archivos solo se procesan en local","Your files are processed locally only"):aosL("Privacidad estándar","Standard privacy"),"ok"); };
  B.querySelectorAll("[data-wl]").forEach(b=>b.onclick=()=>aosmWebllm(win,b.dataset.wl));
  B.querySelectorAll("[data-wu]").forEach(b=>b.onclick=async()=>{ try{ if(webllmEngine&&webllmEngine.unload) await webllmEngine.unload(); }catch(e){} webllmEngine=null; webllmReady=false; try{ renderMenu(); }catch(e){} aosmPaint(win); aosPaintStatus(); });
  aosmOllama(win);
}
async function aosmWebllm(win,id){
  cfg.webllm=cfg.webllm||{}; cfg.webllm.model=id; save();
  aosToast(aosL("Descargando el modelo. La primera vez puede tardar unos minutos.","Downloading the model. The first time may take a few minutes."),"",6000);
  win.body.querySelectorAll("[data-wl]").forEach(b=>b.disabled=true);
  try{ await webllmLoad(); }catch(e){}
  const ok=(typeof webllmReady!=="undefined"&&webllmReady);
  aosToast(ok?aosL("Modelo local listo","Local model ready"):aosL("No se pudo cargar el modelo local","Couldn't load the local model"),ok?"ok":"err");
  if(ok&&aosMotor()==="auto") { v60LSset("atlas_os_motor","local"); }
  aosmPaint(win); aosPaintStatus();
}
async function aosmOllama(win){
  const box=win.body.querySelector(".aosm-oll"); if(!box) return;
  if(!aosNucOk()){ box.innerHTML=`<p class="aos-sub">${aosL("Ollama corre modelos más grandes con la CPU o GPU de tu PC. AR.T.L.A.S. lo administra a través del núcleo local.","Ollama runs larger models on your PC's CPU or GPU. AR.T.L.A.S. manages it through the local core.")}</p><button class="aos-btn" onclick="aosLaunch('config')">${aosL("Configurar el núcleo local","Set up the local core")}</button>`; return; }
  let st; try{ st=await aosNuc("ia.estado"); }catch(e){ box.innerHTML=`<p class="aos-sub">${aosEsc(e.message)}</p>`; return; }
  if(!st.activo){ box.innerHTML=`<p class="aos-sub">${aosEsc(st.error)} <a href="https://ollama.com/download" target="_blank" rel="noopener">ollama.com/download</a></p><button class="aos-btn sm" onclick="aosmOllama(aosWin('${win.id}'))">${aosL("Volver a comprobar","Check again")}</button>`; return; }
  const using=v60LS("atlas_os_oll","")==="1"&&connected("ollama"), curM=(cfg.ollama&&cfg.ollama.model)||"";
  const have=new Set(st.modelos.map(x=>x.nombre));
  box.innerHTML=`<p class="aos-sub"><span class="aos-pill ok">Ollama ${aosEsc(st.version||"")}</span> ${st.cargados&&st.cargados.length?aosL("En memoria: ","In memory: ")+aosEsc(st.cargados.join(", ")):""}</p>
   ${st.modelos.length?`<table class="aos-tbl" style="margin-bottom:12px"><thead><tr><th>${aosL("Modelo instalado","Installed model")}</th><th>${aosL("Tamaño","Size")}</th><th></th></tr></thead><tbody>${st.modelos.map(x=>`<tr><td><b>${aosEsc(x.nombre)}</b> <span style="color:#8f8f8f;font-size:11px">${aosEsc([x.parametros,x.cuant].filter(Boolean).join(" · "))}</span>${using&&curM===x.nombre?` <span class="aos-pill ok">${aosL("en uso","in use")}</span>`:""}</td><td>${aosFmtBytes(x.tam)}</td><td style="white-space:nowrap"><button class="aos-btn sm pri" data-ou="${aosEsc(x.nombre)}">${aosL("Usar","Use")}</button> <button class="aos-btn sm dan" data-od="${aosEsc(x.nombre)}">${aosL("Borrar","Delete")}</button></td></tr>`).join("")}</tbody></table>`:`<p class="aos-sub">${aosL("Todavía no hay modelos instalados.","No models installed yet.")}</p>`}
   <div style="font-size:12.5px;font-weight:600;color:#0d2b5e;margin-bottom:6px">${aosL("Descargar un modelo","Download a model")}</div>
   <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:6px">${AOS_OLLAMA_REC.filter(r=>!have.has(r[0])&&!have.has(r[0]+":latest")).map(([n,sz,d])=>`<div class="aos-card" style="padding:8px 10px;display:flex;align-items:center;gap:8px"><span style="flex:1"><b style="font-size:12.5px">${n}</b> <span class="aos-pill">${sz}</span><br><span style="font-size:11.5px;color:#6b7a90">${d}</span></span><button class="aos-btn sm" data-op="${n}">${aosL("Descargar","Download")}</button></div>`).join("")}</div>
   <div style="display:flex;gap:6px;margin-top:8px"><input class="aos-in aosm-on" placeholder="${aosEsc(aosL("otro modelo, p. ej. mistral:7b","another model, e.g. mistral:7b"))}" style="flex:1;font-size:12.5px"><button class="aos-btn sm" data-op="?">${aosL("Descargar","Download")}</button></div>
   <div class="aosm-prog" style="margin-top:8px;font-size:12px;color:#6b7a90"></div>`;
  box.querySelectorAll("[data-ou]").forEach(b=>b.onclick=()=>{ v60LSset("atlas_os_oll","1"); cfg.ollama=cfg.ollama||{}; cfg.ollama.model=b.dataset.ou; cfg.ollama.url=aosNucOllamaUrl(); cfg.ollama.enabled=true; save(); try{ renderMenu(); }catch(e){} if(aosMotor()==="auto") v60LSset("atlas_os_motor","local"); aosToast(aosL("El asistente usa ","The assistant now uses ")+b.dataset.ou,"ok"); aosmPaint(win); aosPaintStatus(); });
  box.querySelectorAll("[data-od]").forEach(b=>b.onclick=async()=>{ if(!confirm(aosL("¿Borrar el modelo ","Delete model ")+b.dataset.od+"?")) return; try{ await aosNuc("ia.borrar",{modelo:b.dataset.od}); aosmOllama(win); }catch(e){ aosToast(e.message,"err"); } });
  box.querySelectorAll("[data-op]").forEach(b=>b.onclick=()=>{ const n=b.dataset.op==="?"?box.querySelector(".aosm-on").value.trim():b.dataset.op; if(n) aosmPull(win,n); });
}
async function aosmPull(win,n){
  const pr=()=>win.body.querySelector(".aosm-prog");
  try{
    const {job}=await aosNuc("ia.descargar",{modelo:n});
    const tick=async()=>{ let j; try{ j=await aosNuc("ia.progreso",{job}); }catch(e){ return; }
      const p=j.total?Math.round(100*j.completado/j.total):0; const el=pr();
      if(el) el.innerHTML=`<b>${aosEsc(n)}</b> · ${aosEsc(j.estado)}${j.total?` · ${p}% (${aosFmtBytes(j.completado)} / ${aosFmtBytes(j.total)})`:""}<div class="aos-bar-meter" style="margin-top:4px"><i style="width:${p}%"></i></div>`;
      if(j.estado==="listo"){ aosToast(n+aosL(" listo para usar"," ready to use"),"ok"); aosmOllama(win); return; }
      if(j.estado==="error"){ aosToast(j.error||"error","err"); return; }
      if(aosWin(win.id)) setTimeout(tick,1200);
    }; tick();
  }catch(e){ aosToast(e.message,"err"); }
}
