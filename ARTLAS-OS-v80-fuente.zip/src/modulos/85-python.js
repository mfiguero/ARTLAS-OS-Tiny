
/* =====================================================================
   AR.T.L.A.S. · Módulo PYTHON EN EL NAVEGADOR (Pyodide)
   - Los bloques ```python de las respuestas traen «▶ Ejecutar».
   - Corre en un Web Worker aislado: sin DOM, sin localStorage (las claves
     nunca quedan al alcance del código) y sin IndexedDB.
   - Captura print(), el valor final y los gráficos de matplotlib.
   - Límite de tiempo por ejecución; si se excede, el worker se reinicia.
   ===================================================================== */
const V67PY={w:null,seq:0,pend:{},booted:false,alive:false,limit:60000,bootLimit:180000,aliveLimit:10000,strategies:null,tried:[],fails:[]};
/* Estrategias para crear el worker, en orden; si una no arranca se prueba la siguiente:
   1) archivo del mismo sitio (python-worker.js) · 2) módulo desde blob · 3) worker clásico desde blob */
function v67PyStrategies(){
  if(V67PY.strategies) return V67PY.strategies;
  // en file:// (escritorio o carpeta abierta desde el disco) los workers no pueden descargar Python: va directo al iframe aislado
  if(location.protocol!=="http:"&&location.protocol!=="https:") return ["iframe"];
  return ["file","blob-module","blob-classic","iframe"];
}
/* iframe aislado (sandbox sin «allow-same-origin»): sin acceso a la página, a localStorage ni a IndexedDB.
   Se comporta como un Worker para el resto del módulo. */
function v67IframeWorker(){
  const ifr=document.createElement("iframe");
  ifr.setAttribute("sandbox","allow-scripts"); ifr.setAttribute("aria-hidden","true"); ifr.tabIndex=-1;
  ifr.style.cssText="position:absolute;width:0;height:0;border:0;visibility:hidden";
  ifr.srcdoc='<!doctype html><meta charset="utf-8"><script>'+v67WorkerSrc("iframe").replace(/<\/script/gi,"<\\/script")+'<\/script>';
  let ready=false; const queue=[];
  const W={onmessage:null,onerror:null,
    postMessage:d=>{ if(ready&&ifr.contentWindow) ifr.contentWindow.postMessage(d,"*"); else queue.push(d); },
    terminate:()=>{ removeEventListener("message",h); try{ ifr.remove(); }catch(e){} }};
  const h=e=>{ if(e.source!==ifr.contentWindow) return; const d=e.data||{};
    if(d.phase==="alive"&&!ready){ ready=true; queue.splice(0).forEach(x=>ifr.contentWindow.postMessage(x,"*")); }
    if(W.onmessage) W.onmessage({data:d}); };
  addEventListener("message",h);
  document.body.appendChild(ifr);
  return W;
}
function v67PyMake(kind){
  if(kind==="iframe") return v67IframeWorker();
  if(kind==="file") return new Worker("python-worker.js?v="+encodeURIComponent(V60.ver),{type:"module",name:"artlas-python"});
  const classic=kind==="blob-classic";
  const url=URL.createObjectURL(new Blob([v67WorkerSrc(classic?"classic":"module")],{type:"text/javascript"}));
  return classic?new Worker(url,{name:"artlas-python"}):new Worker(url,{type:"module",name:"artlas-python"});
}
function v67PyWorker(){
  if(V67PY.w) return V67PY.w;
  const order=v67PyStrategies().filter(k=>!V67PY.tried.includes(k));
  if(!order.length) throw new Error(V67PY.fails.join(" · ")||"sin estrategias");
  const kind=order[0]; V67PY.tried.push(kind); V67PY.kind=kind; V67PY.alive=false;
  let w;
  try{ w=v67PyMake(kind); }
  catch(e){ V67PY.fails.push(kind+": "+((e&&e.message)||e)); return v67PyWorker(); }
  let dead=false;
  const next=(why)=>{   // esta estrategia no arrancó: probar la siguiente con los pedidos pendientes
    if(dead) return; dead=true;
    V67PY.fails.push(kind+": "+why);
    try{ w.terminate(); }catch(e){}
    if(V67PY.w===w) V67PY.w=null;
    const pend=Object.keys(V67PY.pend).map(id=>[id,V67PY.pend[id]]);
    let nw=null; try{ nw=v67PyWorker(); }catch(e){}
    pend.forEach(([id,p])=>{ if(nw){ clearTimeout(p.t); p.t=setTimeout(()=>v67PyKill(id,"boot"),V67PY.bootLimit); nw.postMessage({id:+id,code:p.code,stdin:p.stdin}); } else v67PyKill(id,"error",V67PY.fails.join(" · ")); });
  };
  const aliveT=setTimeout(()=>{ if(!V67PY.alive) next(v60L("no respondió","did not respond")); },V67PY.aliveLimit);
  w.onmessage=e=>{ const d=e.data||{};
    if(d.phase==="alive"){ V67PY.alive=true; V67PY.mode=d.kind; clearTimeout(aliveT); return; }
    const p=V67PY.pend[d.id]; if(!p) return;
    if(d.phase){ if(d.phase==="run"){ V67PY.booted=true; clearTimeout(p.t); p.t=setTimeout(()=>v67PyKill(d.id,"timeout"),V67PY.limit); } if(p.onPhase) p.onPhase(d); return; }
    if(d.boot&&v67PyStrategies().some(k=>!V67PY.tried.includes(k))){ next(String(d.err||"").slice(0,200)); return; }   // queda pendiente y pasa a la siguiente estrategia
    clearTimeout(p.t); delete V67PY.pend[d.id];
    if(d.boot){   // el worker arrancó pero Pyodide no cargó: se informa el motivo real
      try{ v67LogErr("python",("Python no arrancó ("+kind+"): "+(d.err||"")).slice(0,280),"",""); }catch(x){}
      try{ w.terminate(); }catch(x){} if(V67PY.w===w) V67PY.w=null; V67PY.tried=[];
      d.err=v60L("No se pudo descargar o iniciar Python.","Could not download or start Python.")+"\n"
        +v60L("Si usás un bloqueador de anuncios, un antivirus con filtro web o una red institucional, permití cdn.jsdelivr.net y volvé a intentar.","If you use an ad blocker, an antivirus web filter or an institutional network, allow cdn.jsdelivr.net and try again.")
        +"\n\n"+v60L("Detalle técnico: ","Technical detail: ")+(d.err||"");
    }
    p.res(d); };
  w.onerror=e=>{
    try{ e.preventDefault(); }catch(x){}
    const msg=((e&&e.message)||v60L("el worker no pudo cargarse","the worker failed to load"))+(e&&e.filename?" ("+String(e.filename).split("/").pop().split("?")[0]+":"+(e.lineno||0)+")":"");
    if(!V67PY.alive){ clearTimeout(aliveT); next(msg); return; }
    try{ v67LogErr("python","Python worker ("+kind+"): "+msg,"",""); }catch(x){}
    Object.keys(V67PY.pend).forEach(id=>v67PyKill(id,"error",msg));
  };
  V67PY.w=w; return w;
}
function v67PyKill(id,why,msg){
  const p=V67PY.pend[id]; if(!p) return;
  delete V67PY.pend[id]; clearTimeout(p.t);
  try{ V67PY.w&&V67PY.w.terminate(); }catch(e){} V67PY.w=null; V67PY.booted=false; V67PY.alive=false;
  V67PY.tried=V67PY.tried.filter(k=>k!==V67PY.kind);   // el próximo intento puede reusar la misma estrategia
  Object.keys(V67PY.pend).forEach(o=>{ const q=V67PY.pend[o]; delete V67PY.pend[o]; clearTimeout(q.t); q.res({ok:false,out:"",err:v60L("Python se reinició.","Python restarted."),figs:[]}); });
  let err;
  if(why==="timeout") err=v60L("Tiempo máximo excedido (","Time limit exceeded (")+Math.round(V67PY.limit/1000)+" s). "+v60L("Python se reinició.","Python was restarted.");
  else if(why==="boot") err=v60L("Python tardó demasiado en descargarse (más de ","Python took too long to download (over ")+Math.round(V67PY.bootLimit/1000)+" s). "+v60L("Probá de nuevo: la segunda vez suele ser más rápido.","Try again: the second time is usually faster.");
  else{
    err=v60L("No se pudo iniciar Python en este navegador.","Could not start Python in this browser.")+"\n"
      +v60L("Si usás un bloqueador de anuncios, un antivirus con filtro web o una red institucional, permití cdn.jsdelivr.net y volvé a intentar.","If you use an ad blocker, an antivirus web filter or an institutional network, allow cdn.jsdelivr.net and try again.")
      +(msg?"\n\n"+v60L("Detalle técnico: ","Technical detail: ")+msg:"");
    try{ v67LogErr("python",("Python no arrancó: "+(msg||"")).slice(0,280),"",""); }catch(x){}
    V67PY.tried=[]; V67PY.fails=[];
  }
  p.res({ok:false,out:"",figs:[],err});
}
/* API: ejecuta código Python → {ok,out,err,res,figs,ms} */
/* bibliotecas que no existen para Python en el navegador (Pyodide) */
const V67_PY_NOWEB=/^\s*(?:from|import)\s+(tensorflow|keras|torch|torchvision|torchaudio|jax|transformers|xgboost|lightgbm|cupy)\b/gm;
function v67PyUnsupported(code){ const f=new Set(); let m; V67_PY_NOWEB.lastIndex=0; while((m=V67_PY_NOWEB.exec(String(code||"")))) f.add(m[1]); return [...f]; }
function v67PyNoWebMsg(libs){
  const n=libs.map(x=>({tensorflow:"TensorFlow",keras:"Keras",torch:"PyTorch",torchvision:"PyTorch",torchaudio:"PyTorch",jax:"JAX",transformers:"Transformers",xgboost:"XGBoost",lightgbm:"LightGBM",cupy:"CuPy"}[x]||x)).filter((v,i,a)=>a.indexOf(v)===i).join(", ");
  return v60L("Este código usa "+n+", que no se puede ejecutar dentro del navegador: son bibliotecas muy grandes que necesitan aceleración nativa (GPU/CPU). Sí funcionan en el navegador numpy, pandas, scipy, scikit-learn y matplotlib.",
              "This code uses "+n+", which cannot run inside the browser: they are very large libraries that need native acceleration (GPU/CPU). numpy, pandas, scipy, scikit-learn and matplotlib do run in the browser.");
}
function v67PyRun(code,onPhase,stdin){
  const nw=v67PyUnsupported(code);
  if(nw.length) return Promise.resolve({ok:false,out:"",figs:[],noweb:nw,err:v67PyNoWebMsg(nw)});
  return new Promise(res=>{
    let w; try{ w=v67PyWorker(); }catch(e){ res({ok:false,out:"",figs:[],err:v60L("Este navegador no permite ejecutar Python aislado.","This browser cannot run isolated Python.")}); return; }
    const id=++V67PY.seq;
    const p={res,onPhase,code:String(code||""),stdin:stdin||[],t:setTimeout(()=>v67PyKill(id,"boot"),V67PY.booted?V67PY.limit+30000:V67PY.bootLimit)};
    V67PY.pend[id]=p;
    w.postMessage({id,code:String(code||""),stdin:stdin||[]});
  });
}
/* ---------- botón «▶ Ejecutar» en los bloques de código Python ---------- */
const V67_md=md;
md=function(t){
  let h=V67_md.apply(this,arguments);
  return h.replace(/<div class="v66-cbar"><span>(python|py|python3)<\/span>/gi,(all)=>all+`<button type="button" class="v67-run" onclick="v67Run(this)">▶ ${v60L("Ejecutar","Run")}</button><button type="button" class="v67-colab-mini" onclick="v67Colab(this)" title="${v60L("Copiar el código y abrirlo en Google Colab","Copy the code and open it in Google Colab")}">Colab ↗</button>`);
};
function v67Fmt(ms){ return (ms/1000).toFixed(1).replace(".",atlasLang==="en"?".":",")+" s"; }
function v67OutHtml(r){
  let h=`<div class="v67-ol">${v60L("Salida","Output")} <span class="v67-tag ${r.ok?"ok":"bad"}">${r.ok?"✓":"⚠"} ${r.ms!=null?v67Fmt(r.ms||0):""}</span></div>`;
  const txt=[r.out&&r.out.replace(/\n+$/,""), r.res&&("→ "+r.res), r.err&&r.err].filter(Boolean).join("\n");
  if(txt) h+=`<pre class="v67-pre${r.ok?"":" bad"}">${v66Esc(txt.slice(0,20000))}</pre>`;
  else if(!(r.figs&&r.figs.length)) h+=`<div class="v67-empty">${v60L("(sin salida — usá print() para ver resultados)","(no output — use print() to see results)")}</div>`;
  (r.figs||[]).slice(0,6).forEach(b=>{ h+=`<img class="v67-fig" alt="${v60L("Gráfico generado","Generated chart")}" src="data:image/png;base64,${b}">`; });
  return h;
}
async function v67Run(btn){
  const box=btn.closest(".v66-code"); if(!box) return;
  const code=box.querySelector("code").innerText;
  let out=box.querySelector(".v67-out");
  if(!out){ out=document.createElement("div"); out.className="v67-out"; box.appendChild(out); }
  /* el programa pide datos con input(): primero se cargan en un cuadro */
  let stdin=[];
  if(/\binput\s*\(/.test(code)&&!v67PyUnsupported(code).length){
    let sb=box.querySelector(".v67-stdin");
    if(!sb){
      sb=document.createElement("div"); sb.className="v67-stdin";
      sb.innerHTML=`<label>⌨️ ${v60L("Este programa pide datos con input(). Escribí las respuestas, una por línea, en el orden en que las pide:","This program asks for data with input(). Type the answers, one per line, in the order it asks:")}</label><textarea rows="3" spellcheck="false"></textarea><button type="button" class="v67-run">▶ ${v60L("Ejecutar con estos datos","Run with this data")}</button>`;
      sb.querySelector("button").onclick=()=>v67Run(btn);
      box.insertBefore(sb,out); out.innerHTML=""; sb.querySelector("textarea").focus(); return;
    }
    stdin=sb.querySelector("textarea").value.split("\n");
    if(stdin.length&&stdin[stdin.length-1]==="") stdin.pop();
  }
  btn.disabled=true;
  const first=!V67PY.booted;
  out.innerHTML=`<div class="v67-loading"><span class="v67-spin"></span><span>${first?v60L("Cargando Python en el navegador (solo la primera vez)…","Loading Python in the browser (first time only)…"):v60L("Ejecutando…","Running…")}</span></div>`;
  const lab=out.querySelector(".v67-loading span:last-child");
  const r=await v67PyRun(code,d=>{ if(!lab) return;
    if(d.phase==="packages") lab.textContent=v60L("Cargando paquetes: ","Loading packages: ")+d.names+"…";
    else if(d.phase==="run") lab.textContent=v60L("Ejecutando…","Running…")+(V67PY.mode==="iframe"?" "+v60L("(modo compatible)","(compatibility mode)"):""); },stdin);
  if(!r.ok&&/EOFError/.test(r.err||"")) r.err+="\n\n💡 "+v60L("El programa pidió más datos de los que cargaste en el cuadro de entrada.","The program asked for more data than you entered in the input box.");
  out.innerHTML=v67OutHtml(r);
  if(r.noweb){ out.insertAdjacentHTML("beforeend",`<div class="v67-colab"><button type="button" class="v67-colab-btn" onclick="v67Colab(this)">📋 ${v60L("Copiar el código y abrir Google Colab","Copy the code and open Google Colab")}</button><span>${v60L("En Colab: «Nuevo cuaderno» → pegá el código (Ctrl+V) → ▶.","In Colab: “New notebook” → paste the code (Ctrl+V) → ▶.")}</span></div>`); }
  btn.disabled=false; btn.innerHTML="▶ "+v60L("Ejecutar de nuevo","Run again");
}

/* abrir en Google Colab: copia el código y abre un cuaderno nuevo */
async function v67Colab(b){
  const box=b.closest(".v66-code"); const code=box?box.querySelector("code").innerText:"";
  const ok=await v66Clip(code);
  window.open("https://colab.research.google.com/#create=true","_blank","noopener");
  b.innerHTML=ok?"✓ "+v60L("Código copiado · se abrió Colab","Code copied · Colab opened"):"⚠ "+v60L("Copiá el código manualmente","Copy the code manually");
}
