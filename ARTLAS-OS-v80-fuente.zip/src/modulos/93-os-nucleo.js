
/* =====================================================================
   AR.T.L.A.S. · Módulo 93 · AR.T.L.A.S. OS — CLIENTE DEL NÚCLEO LOCAL
   Habla con el núcleo (nucleo/artlas-nucleo.mjs) en http://127.0.0.1:8770.
   El núcleo da lo que el navegador no puede: disco, aplicaciones, procesos,
   terminal con lista blanca y modelos locales (Ollama).
   Emparejamiento: código de 6 dígitos que muestra la consola del núcleo → token.
   ===================================================================== */
const AOSN={url:"http://127.0.0.1:8770", state:"off", equipo:"", permisos:null, last:0};
function aosNucUrl(){ return (v60LS("atlas_os_nuc_url","")||AOSN.url).replace(/\/$/,""); }
function aosNucToken(){ return v60LS("atlas_os_nuc_tok",""); }
async function aosNucPing(){
  try{
    const tok=aosNucToken();
    const r=await fetch(aosNucUrl()+"/estado",{headers:tok?{"Authorization":"Bearer "+tok}:{},signal:AbortSignal.timeout(1800)});
    const j=await r.json();
    AOSN.equipo=j.equipo||""; AOSN.permisos=j.permisos||null; AOSN.ver=j.ver||""; AOSN.edicion=j.edicion||"";
    AOSN.state=j.emparejado?"ok":"pair";
  }catch(e){ AOSN.state="off"; }
  AOSN.last=Date.now(); aosNucSyncOllama(); try{ if(AOS.on) aosPaintStatus(); }catch(e){} return AOSN.state;
}
async function aosNucPair(code){
  const r=await fetch(aosNucUrl()+"/emparejar",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({codigo:String(code||"").trim(),nombre:(navigator.userAgent||"").slice(0,60)})});
  const j=await r.json().catch(()=>({}));
  if(!r.ok||!j.token) throw new Error(j.error||("HTTP "+r.status));
  v60LSset("atlas_os_nuc_tok",j.token); await aosNucPing(); return j;
}
function aosNucForget(){ try{ localStorage.removeItem("atlas_os_nuc_tok"); }catch(e){} AOSN.state="pair"; aosNucSyncOllama(); }
async function aosNuc(op,args){
  if(AOSN.state!=="ok"&&Date.now()-AOSN.last>3000) await aosNucPing();
  if(AOSN.state==="off") throw new Error(aosL("El núcleo local no está abierto. Iniciá «Iniciar-Nucleo» en tu PC (Configuración → Núcleo local).","The local core isn't running. Start it on your PC (Settings → Local core)."));
  if(AOSN.state==="pair") throw new Error(aosL("Falta emparejar el núcleo local (Configuración → Núcleo local).","Pair the local core first (Settings → Local core)."));
  const r=await fetch(aosNucUrl()+"/rpc",{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+aosNucToken()},body:JSON.stringify({op,args:args||{}})});
  const j=await r.json().catch(()=>({ok:false,error:"HTTP "+r.status}));
  if(r.status===401){ AOSN.state="pair"; throw new Error(aosL("El núcleo pide emparejar de nuevo.","The core needs pairing again.")); }
  if(!j.ok) throw new Error(j.error||"Error del núcleo");
  return j.r;
}
function aosNucOk(){ return AOSN.state==="ok"; }
/* Ollama a través del núcleo: resuelve CORS sin configurar OLLAMA_ORIGINS.
   Solo se toca cfg.ollama si el usuario eligió «usar Ollama del núcleo» (atlas_os_oll=1). */
function aosNucOllamaUrl(){ const t=aosNucToken(); return t?aosNucUrl()+"/ollama/"+t:""; }
function aosNucSyncOllama(){
  try{
    if(v60LS("atlas_os_oll","")!=="1") return;
    cfg.ollama=cfg.ollama||{};
    if(AOSN.state==="ok"){ const u=aosNucOllamaUrl(); if(cfg.ollama.url!==u||!cfg.ollama.enabled){ cfg.ollama.url=u; cfg.ollama.enabled=true; save(); try{ renderMenu(); }catch(e){} } }
  }catch(e){}
}
