
/* =====================================================================
   =====================  AR.T.L.A.S. v6.6 — CHAT: IDENTIDAD, FORMATO, ACCIONES  ==
   (1) Identidad: en el chat todos los modelos se presentan como AR.T.L.A.S.
   (2) Formato real: intérprete Markdown propio (títulos, listas, tablas, citas,
       cursivas, código con resaltado y «Copiar código», enlaces). Todo el texto
       se escapa ANTES de interpretarse → no puede inyectar HTML.
   (3) Acciones por mensaje: Copiar · Regenerar (última respuesta) · Editar.
   ===================================================================== */
const V66={identity:false};

/* ---------- (1) identidad ---------- */
function v66IdentityText(){
  return atlasLang==="en"
    ? "IDENTITY: You are AR.T.L.A.S. (Argentine Transformer for Learning and Advanced Semantics), the artificial intelligence orchestration platform by AI-TECH, designed by Prof. Eng. Mario M. Figueroa de la Cruz. If asked your name or who you are, answer that you are AR.T.L.A.S. Never say you are ChatGPT, Claude, Gemini, Llama, Assistant or any other assistant; if asked which model produces the answer, you may explain that AR.T.L.A.S. orchestrates several models from different providers. Use Markdown (headings, lists, tables) when it improves clarity."
    : "IDENTIDAD: sos AR.T.L.A.S. (Argentine Transformer for Learning and Advanced Semantics), la plataforma de orquestación de inteligencia artificial de AI-TECH, diseñada por el Prof. Ing. Mario M. Figueroa de la Cruz. Si te preguntan tu nombre o quién sos, respondé que sos AR.T.L.A.S. Nunca digas que sos ChatGPT, Claude, Gemini, Llama, «Asistente» ni otro asistente; si te preguntan qué modelo genera la respuesta, podés aclarar que AR.T.L.A.S. orquesta varios modelos de distintos proveedores. Usá Markdown (títulos, listas, tablas) cuando ayude a la claridad.";
}
const V66_callProvider=callProvider;
callProvider=function(pk,c,messages,sys,imgs,maxTok){
  const a=[...arguments];
  if(V66.identity){ a[3]=v66IdentityText()+(sys?"\n\n"+sys:""); }
  return V66_callProvider.apply(this,a);
};
function v66IsAgentChat(){ const c=curId?cur():null; return c?!!c.sys:!!customSys; }   // los agentes conservan su propio nombre

/* ---------- (2) intérprete Markdown ---------- */
function v66Esc(s){ return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
const V66_KW="and|as|async|await|break|case|catch|class|const|continue|def|default|del|do|elif|else|except|export|extends|false|False|finally|for|from|function|if|import|in|is|lambda|let|new|None|not|null|or|pass|print|raise|return|self|static|struct|super|switch|this|throw|true|True|try|typeof|undefined|var|void|while|with|yield|SELECT|FROM|WHERE|JOIN|GROUP|BY|ORDER|INSERT|UPDATE|DELETE|CREATE|TABLE|AND|OR|NOT|NULL|public|private|int|float|double|string|bool|fn|pub|use|mut|impl|package|func|go|defer|echo|then|fi|done|esac";
function v66Highlight(code,lang){
  lang=(lang||"").toLowerCase();
  const hash=/^(py|python|bash|sh|shell|zsh|r|yaml|yml|toml|ruby|rb|perl|powershell|ps1|dockerfile|makefile|ini|conf)$/.test(lang);
  const sql=/^(sql|mysql|postgres|postgresql|sqlite|plsql)$/.test(lang);
  if(!lang||/^(text|txt|plain|plaintext|output|console|log|csv|md|markdown)$/.test(lang)) return v66Esc(code);
  const parts=[hash?"#[^\\n]*":"\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/", sql?"--[^\\n]*":null,
    "\"(?:\\\\.|[^\"\\\\\\n])*\"","'(?:\\\\.|[^'\\\\\\n])*'","`(?:\\\\.|[^`\\\\])*`",
    "\\b\\d+(?:\\.\\d+)?\\b","\\b(?:"+V66_KW+")\\b"].filter(Boolean);
  const rx=new RegExp(parts.join("|"),"g");
  let out="", last=0, m;
  while((m=rx.exec(code))){
    out+=v66Esc(code.slice(last,m.index));
    const t=m[0], c0=t[0];
    const cls=(c0==="#"||t.startsWith("//")||t.startsWith("/*")||t.startsWith("--"))?"c":(c0==='"'||c0==="'"||c0==="`")?"s":/^\d/.test(t)?"n":"k";
    out+='<span class="v66-'+cls+'">'+v66Esc(t)+"</span>";
    last=m.index+t.length; if(!t.length) rx.lastIndex++;
  }
  return out+v66Esc(code.slice(last));
}
function v66SafeUrl(u){ u=String(u||"").trim(); return /^(https?:\/\/|mailto:)/i.test(u)?u.replace(/"/g,"%22").replace(/\s/g,"%20"):""; }
function v66Inline(src){
  // src SIN escapar → se escapa acá, protegiendo antes código y enlaces
  const ph=[]; const keep=h=>"\u0000"+(ph.push(h)-1)+"\u0000";
  let s=String(src);
  s=s.replace(/`([^`\n]+)`/g,(_,c)=>keep("<code>"+v66Esc(c)+"</code>"));
  s=s.replace(/【(\d+)†([^】]*)】/g,(_,n,x)=>{ const u=v66SafeUrl((x.match(/https?:\/\/[^\s】]+/)||[])[0]); return keep(u?`<a href="${v66Esc(u)}" target="_blank" rel="noopener noreferrer">[${n}]</a>`:`[${n}]`); });
  s=s.replace(/!?\[([^\]\n]{1,300})\]\(\s*<?([^)\s>]+)>?(?:\s+"[^"]*")?\s*\)/g,(all,t,u)=>{ const su=v66SafeUrl(u); return su?keep(`<a href="${v66Esc(su)}" target="_blank" rel="noopener noreferrer">${v66InlineNoLinks(t)}</a>`):all; });
  s=s.replace(/(^|[\s(\[«“"'])((?:https?:\/\/)[^\s<>()"'\]]+[^\s<>()"'\].,;:!?»”])/g,(_,p,u)=>p+keep(`<a href="${v66Esc(v66SafeUrl(u))}" target="_blank" rel="noopener noreferrer">${v66Esc(u)}</a>`));
  s=v66Esc(s);
  s=v66Emph(s);
  return s.replace(/\u0000(\d+)\u0000/g,(_,i)=>ph[+i]);
}
function v66InlineNoLinks(t){ return v66Emph(v66Esc(t)); }
function v66Emph(s){
  s=s.replace(/\*\*\*(?=\S)([^*\n]+?)(?<=\S)\*\*\*/g,"<strong><em>$1</em></strong>");
  s=s.replace(/\*\*(?=\S)([^\n]+?)(?<=\S)\*\*/g,"<strong>$1</strong>");
  s=s.replace(/(^|[^\w])__(?=\S)([^\n]+?)(?<=\S)__(?!\w)/g,"$1<strong>$2</strong>");
  s=s.replace(/(^|[^*\w])\*(?=[^\s*])([^*\n]+?)(?<=[^\s*])\*(?![*\w])/g,"$1<em>$2</em>");
  s=s.replace(/(^|[^\w])_(?=[^\s_])([^_\n]+?)(?<=[^\s_])_(?!\w)/g,"$1<em>$2</em>");
  s=s.replace(/~~(?=\S)([^\n]+?)(?<=\S)~~/g,"<del>$1</del>");
  return s;
}
const V66_RX_LIST=/^(\s*)([-*+•]|\d{1,3}[.)])\s+(.*)$/;
const V66_RX_TSEP=/^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
function v66Cells(line){ let t=line.trim(); if(t.startsWith("|")) t=t.slice(1); if(t.endsWith("|")&&!t.endsWith("\\|")) t=t.slice(0,-1); return t.split(/(?<!\\)\|/).map(x=>x.trim().replace(/\\\|/g,"|")); }
function v66Blocks(lines){
  let html="", i=0;
  const isBlank=l=>!l.trim();
  while(i<lines.length){
    const l=lines[i];
    if(isBlank(l)){ i++; continue; }
    // bloque de código (marcador)
    let m=l.match(/^\u0001(\d+)\u0001$/); if(m){ html+=V66._codes[+m[1]]; i++; continue; }
    // títulos
    m=l.match(/^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/);
    if(m){ const n=Math.min(5,m[1].length+1); html+=`<h${n}>${v66Inline(m[2])}</h${n}>`; i++; continue; }
    // línea horizontal
    if(/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(l)){ html+="<hr>"; i++; continue; }
    // tabla
    if(l.includes("|")&&i+1<lines.length&&V66_RX_TSEP.test(lines[i+1])&&lines[i+1].includes("-")){
      const head=v66Cells(l), al=v66Cells(lines[i+1]).map(c=>/^:-+:$/.test(c)?"center":/-:$/.test(c)?"right":"");
      let t='<div class="v66-tbl"><table><thead><tr>'+head.map((c,k)=>`<th${al[k]?` style="text-align:${al[k]}"`:""}>${v66Inline(c)}</th>`).join("")+"</tr></thead><tbody>";
      i+=2;
      while(i<lines.length&&lines[i].includes("|")&&!isBlank(lines[i])){
        const cells=v66Cells(lines[i]);
        t+="<tr>"+head.map((_,k)=>`<td${al[k]?` style="text-align:${al[k]}"`:""}>${v66Inline(cells[k]==null?"":cells[k])}</td>`).join("")+"</tr>"; i++;
      }
      html+=t+"</tbody></table></div>"; continue;
    }
    // cita
    if(/^\s*>/.test(l)){ const q=[]; while(i<lines.length&&/^\s*>/.test(lines[i])){ q.push(lines[i].replace(/^\s*>\s?/,"")); i++; } html+="<blockquote>"+v66Blocks(q)+"</blockquote>"; continue; }
    // listas (con anidamiento por sangría)
    if(V66_RX_LIST.test(l)){
      const items=[];
      while(i<lines.length){
        const x=lines[i], lm=x.match(V66_RX_LIST);
        if(lm){ items.push({ind:lm[1].replace(/\t/g,"    ").length,ord:/\d/.test(lm[2]),start:parseInt(lm[2])||1,text:lm[3]}); i++; continue; }
        if(isBlank(x)){ const nx=lines[i+1]; if(nx!=null&&(V66_RX_LIST.test(nx)||/^\s{2,}\S/.test(nx))){ i++; continue; } break; }
        if(/^\s{2,}\S/.test(x)&&items.length){ items[items.length-1].text+="\n"+x.trim(); i++; continue; }
        break;
      }
      html+=v66List(items); continue;
    }
    // párrafo
    const p=[];
    while(i<lines.length&&!isBlank(lines[i])&&!/^\u0001\d+\u0001$/.test(lines[i])&&!/^\s{0,3}#{1,6}\s/.test(lines[i])&&!/^\s*>/.test(lines[i])&&!V66_RX_LIST.test(lines[i])&&!(lines[i].includes("|")&&i+1<lines.length&&V66_RX_TSEP.test(lines[i+1]))&&!(p.length&&/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(lines[i]))){ p.push(lines[i]); i++; }
    if(!p.length){ p.push(lines[i]); i++; }
    html+="<p>"+p.map(v66Inline).join("<br>")+"</p>";
  }
  return html;
}
function v66List(items){
  // árbol por sangría: un ítem es hijo del anterior si está al menos 2 espacios más adentro
  const root={kids:[],it:{ind:-99}}, stack=[root];
  items.forEach(it=>{
    const node={it,kids:[]};
    while(stack.length>1&&it.ind<stack[stack.length-1].it.ind+2) stack.pop();
    stack[stack.length-1].kids.push(node); stack.push(node);
  });
  const render=kids=>{
    let h="", i=0;
    while(i<kids.length){
      const ord=kids[i].it.ord, tag=ord?"ol":"ul", st=kids[i].it.start;
      h+="<"+tag+(ord&&st!==1?` start="${st}"`:"")+">";
      while(i<kids.length&&kids[i].it.ord===ord){ const k=kids[i]; h+="<li>"+k.it.text.split("\n").map(v66Inline).join("<br>")+(k.kids.length?render(k.kids):"")+"</li>"; i++; }
      h+="</"+tag+">";
    }
    return h;
  };
  return render(root.kids);
}
function v66Md(t){
  t=String(t==null?"":t).replace(/\r\n?/g,"\n");
  V66._codes=[];
  // bloques de código (también un bloque sin cerrar al final)
  t=t.replace(/(^|\n)[ \t]*(```|~~~)[ \t]*([\w+#.-]*)[^\n]*\n([\s\S]*?)(?:\n[ \t]*\2[ \t]*(?=\n|$)|$)/g,(all,pre,fence,lang,code)=>{
    const i=V66._codes.push(`<div class="v66-code"><div class="v66-cbar"><span>${v66Esc(lang||"código")}</span><button type="button" onclick="v66CopyCode(this)">📋 ${v60L("Copiar código","Copy code")}</button></div><pre><code>${v66Highlight(code.replace(/\n$/,""),lang)}</code></pre></div>`)-1;
    return pre+"\u0001"+i+"\u0001\n";
  });
  return '<div class="v66md">'+v66Blocks(t.split("\n"))+"</div>";
}
md=function(t){ try{ return v66Md(t); }catch(e){ console.error("v66 md",e); return '<div style="white-space:pre-wrap">'+v66Esc(t)+"</div>"; } };

/* ---------- copiar ---------- */
async function v66Clip(text){
  try{ await navigator.clipboard.writeText(text); return true; }
  catch(e){ try{ const ta=document.createElement("textarea"); ta.value=text; ta.style.cssText="position:fixed;left:-9999px"; document.body.appendChild(ta); ta.select(); const ok=document.execCommand("copy"); ta.remove(); return ok; }catch(x){ return false; } }
}
function v66Flash(b,ok){ const o=b.innerHTML; b.innerHTML=ok?"✓ "+v60L("Copiado","Copied"):"⚠ "+v60L("No se pudo copiar","Copy failed"); b.disabled=true; setTimeout(()=>{ b.innerHTML=o; b.disabled=false; },1400); }
async function v66CopyCode(b){ const c=b.closest(".v66-code").querySelector("code"); v66Flash(b,await v66Clip(c.innerText)); }

/* ---------- (3) acciones por mensaje ---------- */
function v66RealRows(){
  return [...document.querySelectorAll("#msgs > .row")].filter(r=>{
    if(r.classList.contains("v63-offer")) return false;
    const ct=r.querySelector(".content"); if(!ct||ct.querySelector(".typing")) return false;
    return !!(ct.textContent.trim()||ct.querySelector("img,table,pre"));
  });
}
function v66MsgOf(row){
  const c=curId?cur():null; if(!c) return null;
  const real=v66RealRows();
  if(real.length===c.msgs.length){ const i=real.indexOf(row); return i>=0?{c,i,m:c.msgs[i]}:null; }
  if(row.classList.contains("user")){   // los mensajes del usuario siempre se corresponden en orden
    const k=real.filter(r=>r.classList.contains("user")).indexOf(row);
    const idx=c.msgs.map((m,i)=>m.role==="user"?i:-1).filter(i=>i>=0)[k];
    return idx!=null?{c,i:idx,m:c.msgs[idx]}:null;
  }
  return {c,i:-1,m:null};
}
function v66Decorate(){
  const real=v66RealRows(); let lastBot=null;
  real.forEach(r=>{
    const user=r.classList.contains("user");
    if(!r.querySelector(".v66-acts")){
      const a=document.createElement("div"); a.className="v66-acts";
      a.innerHTML=user
        ? `<button type="button" onclick="v66Edit(this)">✏️ ${v60L("Editar","Edit")}</button><button type="button" onclick="v66Copy(this)">📋 ${v60L("Copiar","Copy")}</button>`
        : `<button type="button" onclick="v66Copy(this)">📋 ${v60L("Copiar","Copy")}</button><button type="button" class="v66-regen" onclick="v66Regen()">🔄 ${v60L("Regenerar","Regenerate")}</button>`;
      (user?r:(r.querySelector(".body")||r)).appendChild(a);
    }
    if(!user) lastBot=r;
  });
  document.querySelectorAll("#msgs > .row.v66-last").forEach(r=>r.classList.remove("v66-last"));
  const rows=[...document.querySelectorAll("#msgs > .row")].filter(r=>!r.classList.contains("v63-offer"));
  if(lastBot&&rows[rows.length-1]===lastBot) lastBot.classList.add("v66-last");   // «Regenerar» solo en la última respuesta
}
async function v66Copy(b){
  const row=b.closest(".row"), x=v66MsgOf(row);
  let text=(x&&x.m)?String(x.m.content||""):row.querySelector(".content").innerText;
  text=text.replace(/\n\n🔎 \*\*(Fuentes|Sources)\*\*[\s\S]*$/,"").trim()||text;
  v66Flash(b,await v66Clip(text));
}
function v66UserText(m){ return String(m.content||"").split("\n📎")[0].replace(/^\(adjunto\)$/,"").trim(); }
function v66Resend(c,idx,text){
  if(busy) return;
  const had=/\n📎/.test(String(c.msgs[idx]&&c.msgs[idx].content||""));
  c.msgs.splice(idx); save(); v63OfferClear();
  renderMsgs(); renderChats();
  inp.value=text; inp.dispatchEvent(new Event("input"));
  send();
  if(had) setTimeout(()=>{ try{ alert(v60L("Los archivos adjuntos de ese mensaje no se vuelven a enviar. Si los necesitás, adjuntalos de nuevo.","Attachments from that message are not resent. Attach them again if you need them.")); }catch(e){} },50);
}
function v66Regen(){
  if(busy) return;
  const c=curId?cur():null; if(!c) return;
  let u=-1; for(let i=c.msgs.length-1;i>=0;i--){ if(c.msgs[i].role==="user"){ u=i; break; } }
  if(u<0) return;
  const text=v66UserText(c.msgs[u]); if(!text) return;
  v66Resend(c,u,text);
}
function v66Edit(b){
  if(busy) return;
  const row=b.closest(".row"), x=v66MsgOf(row); if(!x||x.i<0) return;
  const ct=row.querySelector(".content"), acts=row.querySelector(".v66-acts");
  const box=document.createElement("div"); box.className="v66-edit";
  box.innerHTML=`<textarea rows="2"></textarea><div class="v66-eb"><button type="button" class="v66-cancel">${v60L("Cancelar","Cancel")}</button><button type="button" class="v66-ok">${v60L("Enviar","Send")}</button></div>`;
  const ta=box.querySelector("textarea"); ta.value=v66UserText(x.m);
  ct.style.display="none"; acts.style.display="none"; row.insertBefore(box,ct);
  const fit=()=>{ ta.style.height="auto"; ta.style.height=Math.min(ta.scrollHeight,260)+"px"; }; fit(); ta.addEventListener("input",fit);
  const close=()=>{ box.remove(); ct.style.display=""; acts.style.display=""; };
  box.querySelector(".v66-cancel").onclick=close;
  const go=()=>{ const t=ta.value.trim(); if(!t) return; close(); v66Resend(x.c,x.i,t); };
  box.querySelector(".v66-ok").onclick=go;
  ta.addEventListener("keydown",e=>{ if(e.key==="Enter"&&!e.shiftKey){ e.preventDefault(); go(); } else if(e.key==="Escape"){ close(); } });
  ta.focus(); ta.setSelectionRange(ta.value.length,ta.value.length);
}

/* ---------- enganches ---------- */
/* el texto del usuario se muestra tal cual (sin interpretar Markdown) */
const V66_addRow=addRow;
addRow=function(role,content,meta){
  const d=V66_addRow.apply(this,arguments);
  try{ if(role==="user"){ const ct=d.querySelector(".content"); if(ct) ct.textContent=String(content==null?"":content); } }catch(e){}
  return d;
};
v60Wrap("renderMsgs",()=>v66Decorate());
const V66_send=send;
send=async function(){
  V66.identity=!v66IsAgentChat();
  try{ return await V66_send.apply(this,arguments); }
  finally{ V66.identity=false; setTimeout(v66Decorate,0); }
};
const V66_retry=v63Retry;
v63Retry=async function(c){
  V66.identity=!(c&&c.sys);
  try{ return await V66_retry.apply(this,arguments); }
  finally{ V66.identity=false; setTimeout(v66Decorate,0); }
};
(function(){
  let pend=false; const box=$("msgs"); if(!box) return;
  new MutationObserver(()=>{ if(pend) return; pend=true; setTimeout(()=>{ pend=false; try{ v66Decorate(); }catch(e){} },120); }).observe(box,{childList:true});
})();
