/* AR.T.L.A.S. __ARTLAS_VER__ · service worker de la app instalable
   © MMFC · AI-TECH. Guarda la app para abrirla al instante y avisa cuando hay una versión nueva. */
const VER = "__ARTLAS_VER__";
const BID = "__ARTLAS_BID__";               // cambia en cada compilación → el navegador detecta la versión nueva
const CACHE = "artlas-" + VER + "-" + BID;
const CDN = "artlas-cdn";
const PRE = ["./app.html", "./app.js?v=__ARTLAS_NUM__.__ARTLAS_BID__", "./app-recursos.js?v=__ARTLAS_NUM__.__ARTLAS_BID__", "./python-worker.js?v=__ARTLAS_VER__",
  "./emblem.png", "./logo.png", "./logo-artlas.webp", "./manifest.webmanifest", "./icono-192.png", "./icono-512.png", "./apple-touch-icon.png"];
const CDN_OK = [/^https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/jszip\//, /^https:\/\/cdn\.jsdelivr\.net\/npm\/@supabase\/supabase-js@2\//];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => Promise.all(PRE.map(u => c.add(new Request(u, { cache: "reload" })).catch(() => null)))));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith("artlas-") && k !== CACHE && k !== CDN).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("message", e => {
  const d = e.data || {};
  if (d.type === "SKIP_WAITING") self.skipWaiting();
  if (d.type === "VER" && e.ports && e.ports[0]) e.ports[0].postMessage({ ver: VER });
});
self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) {
    // solo las dos librerías que la app necesita para arrancar (copia de respaldo)
    if (CDN_OK.some(r => r.test(req.url))) {
      e.respondWith(caches.open(CDN).then(c => fetch(req).then(r => { if (r && (r.ok || r.type === "opaque")) c.put(req, r.clone()); return r; }).catch(() => c.match(req))));
    }
    return;
  }
  if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/.netlify/") || url.pathname.endsWith("/sw.js")) return;
  if (req.cache === "no-store") return;   // descargas (paquete de escritorio): siempre de la red
  if (req.mode === "navigate") {
    // la página: primero la red (así siempre llega la última versión); sin conexión, la copia guardada
    e.respondWith(fetch(req).then(r => { if (r.ok && url.pathname.endsWith("/app.html")) { const cp = r.clone(); caches.open(CACHE).then(c => c.put("./app.html", cp)); } return r; })
      .catch(() => caches.match(req, { ignoreSearch: true }).then(r => r || caches.match("./app.html"))));
    return;
  }
  e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(r => {
    if (r.ok && /\.(js|png|webp|ico|webmanifest|json)$/.test(url.pathname)) { const cp = r.clone(); caches.open(CACHE).then(c => c.put(req, cp)); }
    return r;
  })));
});
