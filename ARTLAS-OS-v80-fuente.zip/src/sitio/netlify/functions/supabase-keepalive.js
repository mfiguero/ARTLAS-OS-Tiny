// AR.T.L.A.S. — Supabase keep-alive (función PROGRAMADA de Netlify)
// El plan gratuito de Supabase pausa el proyecto tras ~7 días de baja actividad.
// Supabase indica que "unas pocas solicitudes a la base por día" alcanzan para evitarlo.
// Esta función corre cada 12 h (ver netlify.toml) y hace:
//   1) GET /auth/v1/health          → servicio de autenticación
//   2) GET /rest/v1/atlas_profiles  → consulta mínima a la base (RLS devuelve vacío; no lee datos)
// Variables opcionales en Netlify: SUPABASE_URL, SUPABASE_ANON_KEY (por defecto, las de ARTLAS).
// Requiere Node 18+ (fetch global). Solo corre en el deploy publicado.

const URL_ = (process.env.SUPABASE_URL || "https://dtvxsndbqiqkiwdvprqz.supabase.co").replace(/\/+$/, "");
const KEY  = process.env.SUPABASE_ANON_KEY || "sb_publishable_TrivMLry4-Ur7he73q4CkQ_KYmCZ5dm";

exports.handler = async () => {
  const h = { apikey: KEY, Authorization: "Bearer " + KEY };
  const out = {};
  try { const r = await fetch(URL_ + "/auth/v1/health", { headers: h }); out.auth = r.status; } catch (e) { out.auth = "error: " + e.message; }
  try { const r = await fetch(URL_ + "/rest/v1/atlas_profiles?select=id&limit=1", { headers: h }); out.db = r.status; } catch (e) { out.db = "error: " + e.message; }
  out.at = new Date().toISOString();
  console.log("[ARTLAS keep-alive]", JSON.stringify(out));
  return { statusCode: 200, body: JSON.stringify(out) };
};
