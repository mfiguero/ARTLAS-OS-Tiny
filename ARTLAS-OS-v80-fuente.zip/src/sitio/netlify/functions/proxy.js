// AR.T.L.A.S. — Proxy ENDURECIDO
// Protecciones: (1) whitelist de dominios de proveedores de IA,
// (2) límite de peticiones por IP, (3) restricción opcional de origen (env ALLOWED_ORIGINS).
// Requiere Node 18+ (fetch global).

const ALLOWED_HOSTS = [
  "api.openai.com","api.anthropic.com","generativelanguage.googleapis.com",
  "api.groq.com","router.huggingface.co","openrouter.ai","api.deepseek.com",
  "api.moonshot.ai","api.moonshot.cn","api.z.ai","open.bigmodel.cn",
  "api.together.xyz","dashscope-intl.aliyuncs.com","dashscope.aliyuncs.com",
  "openapi.felo.ai","text.pollinations.ai","ai.hackclub.com",
  // v63: búsqueda web del chat y de los agentes
  "api.tavily.com","s.jina.ai","r.jina.ai","html.duckduckgo.com","api.duckduckgo.com",
  "news.google.com","es.wikipedia.org","en.wikipedia.org"
];

// Rate limit best-effort en memoria (por instancia "caliente")
const RL = new Map();               // ip -> [timestamps]
const RL_WINDOW = 60 * 1000;        // 1 minuto
const RL_MAX = Number(process.env.PROXY_RATE_MAX || 60); // req/min por IP

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers: cors, body: "Method Not Allowed" };

  // (opcional) restringir a orígenes propios: setear env ALLOWED_ORIGINS (coma-separado)
  const allowedOrigins = (process.env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
  if (allowedOrigins.length) {
    const origin = event.headers.origin || event.headers.referer || "";
    if (!allowedOrigins.some(o => origin.startsWith(o))) {
      return { statusCode: 403, headers: cors, body: JSON.stringify({ error: { message: "Origen no autorizado." } }) };
    }
  }

  // rate limit por IP
  const ip = String(event.headers["x-nf-client-connection-ip"] || event.headers["x-forwarded-for"] || "unknown").split(",")[0].trim();
  const now = Date.now();
  const arr = (RL.get(ip) || []).filter(t => now - t < RL_WINDOW);
  if (arr.length >= RL_MAX) {
    return { statusCode: 429, headers: cors, body: JSON.stringify({ error: { message: "Demasiadas peticiones. Esperá un momento." } }) };
  }
  arr.push(now); RL.set(ip, arr);

  try {
    const { url, method, headers, body } = JSON.parse(event.body || "{}");
    if (!url || !/^https?:\/\//i.test(url)) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: { message: "URL inválida." } }) };
    }
    let host;
    try { host = new URL(url).hostname; } catch (e) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: { message: "URL inválida." } }) };
    }
    if (!ALLOWED_HOSTS.includes(host)) {
      return { statusCode: 403, headers: cors, body: JSON.stringify({ error: { message: "Dominio no permitido por el proxy: " + host } }) };
    }
    const resp = await fetch(url, { method: method || "POST", headers: headers || {}, body: body != null ? body : undefined });
    const text = await resp.text();
    return {
      statusCode: resp.status,
      headers: { "Content-Type": resp.headers.get("content-type") || "application/json", "Access-Control-Allow-Origin": "*" },
      body: text,
    };
  } catch (e) {
    return { statusCode: 502, headers: cors, body: JSON.stringify({ error: { message: "Proxy: " + (e && e.message ? e.message : String(e)) } }) };
  }
};
