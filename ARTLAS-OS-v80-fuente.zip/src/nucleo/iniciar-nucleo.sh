#!/bin/sh
# AR.T.L.A.S. OS · Núcleo local (macOS / Linux)
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "Falta Node.js 18 o superior: https://nodejs.org"; exit 1; }
exec node artlas-nucleo.mjs "$@"
